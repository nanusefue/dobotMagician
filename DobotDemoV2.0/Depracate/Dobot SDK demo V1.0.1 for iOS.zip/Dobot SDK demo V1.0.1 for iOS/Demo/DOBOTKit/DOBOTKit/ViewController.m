//
//  ViewController.m
//  DOBOTKit
//
//  Created by Gino on 2017/2/27.
//  Copyright © 2017年 Dobot. All rights reserved.
//

#import "ViewController.h"
//#import "BLEMsgMgr.h"
#import <DOBOTKit/DOBOTKit.h>

@interface ViewController ()
<BLEMsgMgrDelegate,
MsgHandler>

#define TAG_Xplus   100
#define TAG_Xminus  101
#define TAG_Yplus   102
#define TAG_Yminus  103


@property (nonatomic,strong) NSTimer *getCurrentPoseTimer;

@property (nonatomic,strong) NSTimer *changeIODOTimer;

@property (nonatomic,assign) uint8_t address;
@property (nonatomic,assign) BOOL isHightLevel;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    

    
    [self initData];
    
    [self buildUI];
}

-(void)initData
{
    //初始化 开启蓝牙
    [BLEMsgMgr sharedMgr].delegate = self;
    
    
    [[BLEMsgMgr sharedMgr] addMsgHandler:self];
    
    
    _address = 0x01;
    _isHightLevel = YES;
}

-(void)buildUI
{
    
    self.view.backgroundColor = [UIColor darkGrayColor];
    
    [self updateBtnBLEConnect];
    
    
    _btnXplus.tag = TAG_Xplus;
    _btnXminus.tag = TAG_Xminus;
    _btnYplus.tag = TAG_Yplus;
    _btnYminus.tag = TAG_Yminus;
    
    NSArray *btns = [NSArray arrayWithObjects:_btnXplus,_btnXminus,_btnYplus,_btnYminus, nil];
    
    for (UIButton *btn in btns) {
        
        UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressBtnJog:)];
        [btn addGestureRecognizer:longPress];
    }
    
    [self updateJogMode:_jogModeSwitch];
    
    
}
//更新蓝牙连接状态
-(void)updateBtnBLEConnect
{
    
    if ([[BLEMsgMgr sharedMgr] isConnected]) {
        
        //已连接
        
        [_btnBLEConnect setImage:[UIImage imageNamed:@"ble_connected"] forState:UIControlStateNormal];
    }
    else
    {
        //未连接
        
        [_btnBLEConnect setImage:[UIImage imageNamed:@"ble_disconnected"] forState:UIControlStateNormal];
    }
    
    
    
}



-(IBAction)btnBLEConnectTaped:(UIButton *)sender
{
    if ([[BLEMsgMgr sharedMgr] isConnected]) {
        
        //断开连接
        
        [[BLEMsgMgr sharedMgr] disconnect];
    }
    else
    {
        
        [[BLEMsgMgr sharedMgr] scanDevice:30.0f mode:BLESearchMode_FindAndConnectTheFirst];
    }

}

-(IBAction)btnGetPoseTaped:(id)sender
{
    
    Payload *payload = [[Payload alloc] init];
    
    [payload cmdGetPose];
    
    payload.complete = ^(MsgResult result, id msg){
      
        if (result == MsgResult_Ok) {
            
            //解析返回的位置信息
            
            Payload *msgPayload = ((DobotMagicianMsg *)msg).payload;
            
            Pose p;
            
            
            [msgPayload.params getBytes:&p length:sizeof(p)];
            
            
            NSString *text = [NSString stringWithFormat:@"Pose:x:%.0f,y:%.0f,z:%.0f,r:%.0f",p.x,p.y,p.z,p.r];
            
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                _lblLog.text = text;
            });
            
            
        }
        
    };
    
    [[BLEMsgMgr sharedMgr] sendMsg:payload];
}

-(IBAction)btnPTPCmdsTaped:(id)sender
{
    NSMutableArray *ptpCmds = [NSMutableArray arrayWithCapacity:10];
    
    
    PTPCmd p1 = {PTPMode_MoveL,250.0f,20.0f,0.0f,0.0f};

    Payload *point1 = [[Payload alloc] init];
    
    [point1 cmdPTP:p1];
    
    /* 等于  //PTP都是队列命令
    [point1 setProtocolID:ProtocolPTPCmd];
    [point1 setWriteMode];
    [point1 setQueueMode];
    point1.params = [NSData dataWithBytes:&p1 length:sizeof(p1)];
     
     */
    
    
    
    PTPCmd p2 = {PTPMode_MoveL,250.0f,-20.0f,0.0f,0.0f};
    
    Payload *point2 = [[Payload alloc] init];
    
    [point2 cmdPTP:p2];
    
    
    PTPCmd p3 = {PTPMode_MoveL,200.0f,-20.0f,0.0f,0.0f};
    
    Payload *point3 = [[Payload alloc] init];
    
    [point3 cmdPTP:p3];
    
    
    PTPCmd p4 = {PTPMode_MoveL,200.0f,20.0f,0.0f,0.0f};
    
    Payload *point4 = [[Payload alloc] init];
    
    [point4 cmdPTP:p4];
    
    
    int repeatCount = 60;
    
    NSArray *loopCmds = [NSArray arrayWithObjects:point1,point2,point3,point4, nil];
    
    for (int i = 0; i < repeatCount; i++) {
        
        [ptpCmds addObjectsFromArray:loopCmds];
    }
    
    
    
    [self initGetCurrentPoseTimer];
    
    
    for (int i = 0; i < ptpCmds.count; i++) {
        
        Payload *payload = ptpCmds[i];
        
        [[BLEMsgMgr sharedMgr] sendMsg:payload];
    }
}

-(IBAction)btnStopTimerTaped:(id)sender
{
    if ([_getCurrentPoseTimer isValid]) {
        
        [_getCurrentPoseTimer invalidate];
        
        _getCurrentPoseTimer = nil;
    }
}

-(IBAction)btnStartQueueTaped:(id)sender
{
 
    Payload *payload = [[Payload alloc] init];
    
    [payload cmdStartQueue];
    
    [[BLEMsgMgr sharedMgr] sendMsg:payload];
    
    
}

-(IBAction)btnForceStopQueueTaped:(id)sender
{
    
    Payload *payload = [[Payload alloc] init];
    
    [payload cmdStopQueue];
    
    [[BLEMsgMgr sharedMgr] sendMsg:payload];
    
}

-(IBAction)btnClearQueueTaped:(id)sender
{
    Payload *payload = [[Payload alloc] init];
    
    [payload cmdClearQueue];
    
    [[BLEMsgMgr sharedMgr] sendMsg:payload];
}

-(IBAction)switchJogMode:(id)sender
{
    
    UISwitch *modeChange = (UISwitch *)sender;

    [self updateJogMode:modeChange];
    
}

-(IBAction)btnEIOTaped:(id)sender
{
    
    //复用EIO
    //设置地址为_address 的IO口的功能为IODO
    //定时改变IODO的高低电平
    
    
    IOMultiplexing ioMultiplexing = {_address,(uint8_t)IOFunctionDO};
    
    Payload *payload = [[Payload alloc] init];
    
//    [payload cmdGetIOMultiplexing:ioMultiplexing];
    
    [payload cmdSetIOMultiplexing:ioMultiplexing isQueue:NO];
    
    payload.complete = ^(MsgResult result ,id msg){
      
        if (result == MsgResult_Ok) {
            
            Payload *msgPayload = ((DobotMagicianMsg *)msg).payload;
            
            NSLog(@"payload.params = %@",msgPayload.params);
        }
        
    };
    
    [[BLEMsgMgr sharedMgr] sendMsg:payload];
    
    
    [self initChangeIODOTimer];
}

-(IBAction)btnStopEIOTaped:(id)sender
{

    if ([_changeIODOTimer isValid]) {
        
        [_changeIODOTimer invalidate];
        _changeIODOTimer = nil;
    }
    
    
    //设置为未配置状态
    IOMultiplexing ioMultiplexing = {_address,(uint8_t)IOFunctionDummy};
    
    Payload *payload = [[Payload alloc] init];
    
    [payload cmdSetIOMultiplexing:ioMultiplexing isQueue:NO];
    
    payload.complete = ^(MsgResult result ,id msg){
        
        if (result == MsgResult_Ok) {
            
            Payload *msgPayload = ((DobotMagicianMsg *)msg).payload;
            
            NSLog(@"payload.params = %@",msgPayload.params);
        }
        
    };
    
    [[BLEMsgMgr sharedMgr] sendMsg:payload];
    
}

-(IBAction)btnGetEIOTaped:(id)sender
{
    //获取EIO的复用状态
    
    IOMultiplexing ioMultiplexing = {_address,(uint8_t)IOFunctionDummy};
    
    Payload *payload = [[Payload alloc] init];
    
    [payload cmdGetIOMultiplexing:ioMultiplexing];
    
    payload.complete = ^(MsgResult result ,id msg){
        
        if (result == MsgResult_Ok) {
            
            Payload *msgPayload = ((DobotMagicianMsg *)msg).payload;
            
            NSLog(@"payload.params = %@",msgPayload.params);
        }
        
    };
    
    [[BLEMsgMgr sharedMgr] sendMsg:payload];
}


-(void)initChangeIODOTimer
{
    _changeIODOTimer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(changeIODO:) userInfo:nil repeats:YES];
}

-(void)changeIODO:(NSTimer *)timer
{
    _isHightLevel = !_isHightLevel;
    
    uint8_t level = 0x00;
    
    if (_isHightLevel) {
        
        level = 0x01;
    }
    
    IODO ioDo = {_address,level};
    
    Payload *payload = [[Payload alloc] init];
    
    [payload cmdSetIODO:ioDo isQueue:NO];
    
    payload.complete = ^(MsgResult result , id msg){
      
        if (result == MsgResult_Ok) {
            
            Payload *msgPayload = ((DobotMagicianMsg *)msg).payload;
            
            IODO msgIODO;
            
            [msgPayload.params getBytes:&msgIODO length:sizeof(msgIODO)];
            
            NSString *text = [NSString stringWithFormat:@"IODO:address:%d,level:%d",msgIODO.address,msgIODO.level];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                _lblLog.text = text;
            });
        }
    };
    
    
    [[BLEMsgMgr sharedMgr] sendMsg:payload];
}



-(void)updateJogMode:(UISwitch *)sw
{
    if(_jogModeSwitch.isOn)
    {
        //
        NSLog(@"关节点动");
        
        [_btnXplus setTitle:@"J1+" forState:UIControlStateNormal];
        [_btnXminus setTitle:@"J1-" forState:UIControlStateNormal];
        [_btnYplus setTitle:@"J2+" forState:UIControlStateNormal];
        [_btnYminus setTitle:@"J2-" forState:UIControlStateNormal];
        
    }
    else
    {
        NSLog(@"坐标轴点动");
        
        [_btnXplus setTitle:@"X+" forState:UIControlStateNormal];
        [_btnXminus setTitle:@"X-" forState:UIControlStateNormal];
        [_btnYplus setTitle:@"Y+" forState:UIControlStateNormal];
        [_btnYminus setTitle:@"Y-" forState:UIControlStateNormal];
    }
}


-(void)longPressBtnJog:(UIGestureRecognizer *)recognizer
{
    
    JOGCmdMode mode = JOGCmdMode_Joint;
    
    if (!_jogModeSwitch.isOn) {
        
        mode = JOGCmdMode_Coordinate;
    }
    
    
    if (recognizer.state == UIGestureRecognizerStateBegan) {
        
        UIView *view = recognizer.view;
        
        NSInteger tag = view.tag;
        
        JOGCmdCoordinate cmd;
        
        switch (tag) {
            case TAG_Xplus:{
                
                cmd = JOGCmdCoordinate_Xplus;
            }
                break;
            case TAG_Xminus:{
                
                cmd = JOGCmdCoordinate_Xminus;
            }
                break;
            case TAG_Yplus:{
                
                cmd = JOGCmdCoordinate_Yplus;
            }
                break;
            case TAG_Yminus:{
                
                cmd = JOGCmdCoordinate_Yminus;
            }
                break;
                
            default:
                break;
        }
        
        
        JOGCmd jogCmd = {(uint8_t)mode,(uint8_t)cmd};
        
        
        Payload *payload = [[Payload alloc] init];
        
        [payload cmdJog:jogCmd];
        
        [[BLEMsgMgr sharedMgr] sendMsg:payload];
        
        
    }
    else if (recognizer.state == UIGestureRecognizerStateEnded)
    {
        
        JOGCmd jogCmd = {(uint8_t)mode,(uint8_t)JOGCmdCoordinate_Stop};
        
        
        Payload *payload = [[Payload alloc] init];
        
        [payload cmdJog:jogCmd];
        
        [[BLEMsgMgr sharedMgr] sendMsg:payload];
        
    }
    
    
}



-(void)initGetCurrentPoseTimer
{
    
    _getCurrentPoseTimer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(btnGetPoseTaped:) userInfo:nil repeats:YES];
    
}

#pragma mark BLEMsgMgrDelegate

-(void)didConnect
{
    [self updateBtnBLEConnect];
}

-(void)didDisconnect
{
    [self updateBtnBLEConnect];
}


#pragma mark MsgHandler

-(void)handleMsg:(DobotMagicianMsg *)msg
{
    
    Payload *payload = msg.payload;
    
    switch ((int)payload.ID) {
            
        case ProtocolJOGCmd:{
            
        }
            break;
            
        case ProtocolGetPose:{
            
            
//            Pose p;
//            
//            
//            [payload.params getBytes:&p length:sizeof(p)];
//            
//            
//            NSString *text = [NSString stringWithFormat:@"Pose:x:%.0f,y:%.0f,z:%.0f,r:%.0f",p.x,p.y,p.z,p.r];
//            
//            
//            //记录当前pose
//            
//            _lblLog.text = text;
            
            
        }
            break;
        case ProtocolJOGCoordinateParams:{
            
            //
            
            JOGCoordinateParams p;
            
            
            [payload.params getBytes:&p length:sizeof(p)];
            
            
            //            NSString *text = [NSString stringWithFormat:@"JOG:x:%.0f,y:%.0f,z:%.0f,r:%.0f",p.velocity[0],p.velocity[1],p.velocity[2],p.velocity[3]];
            
            
            
            
            
        }
            break;
        case ProtocolPTPCoordinateParams:{
            
            
            PTPCoordinateParams p;
            
            
            [payload.params getBytes:&p length:sizeof(p)];
            
            
            NSString *text = [NSString stringWithFormat:@"PTP:xyzV:%.0f,rV:%.0f,xyzA:%.0f,rA:%.0f",p.xyzVelocity,p.rVelocity,p.xyzAcceleration,p.rAcceleration];
            
            
            
            
        }
            break;
        case ProtocolPTPCmd:{
            
            
        }
            break;
        case ProtocolCPParams:{
            
            CPParams p;
            
            [payload.params getBytes:&p length:sizeof(p)];
            
            
            NSString *text;
            
            if (p.realTimeTrack) {
                
                text = [NSString stringWithFormat:@"CP:planAcc:%.0f,junctionVel:%.0f,period:%.0f,realTimeTrack:%d",p.planAcc,p.junctionVel,p.period,(int)p.realTimeTrack];
            }
            else
            {
                text = [NSString stringWithFormat:@"CP:planAcc:%.0f,junctionVel:%.0f,acc:%.0f,realTimeTrack:%d",p.planAcc,p.junctionVel,p.acc,(int)p.realTimeTrack];
                
            }
            
            
            
        }
            break;
        case ProtocolCPCmd:{
            
            
            
            
        }
            break;
            
        case ProtocolQueuedCmdCurrentIndex:{
            
            uint64_t p;
            
            [payload.params getBytes:&p length:sizeof(p)];
            
      
            
            
        }
            break;
            
        case ProtocolEndEffectorParams:{
            
            EndEffectorParams p;
            
            [payload.params getBytes:&p length:sizeof(p)];
            
            
            
        }
            break;
        case ProtocolEndEffectorLaser:{
            
            
            
        }
            break;
        case ProtocolQueuedCmdStopExec:{
            

        }
            break;
            
        case ProtocolQueuedCmdStartExec:{
            
            
        }
            break;
            
        default:
            break;
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

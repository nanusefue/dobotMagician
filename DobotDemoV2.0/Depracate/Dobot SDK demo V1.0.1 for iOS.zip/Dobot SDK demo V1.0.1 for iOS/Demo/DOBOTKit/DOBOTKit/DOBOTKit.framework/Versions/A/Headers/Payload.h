//
//  PayloadContent.h
//  DoBot
//
//  Created by Gino on 16/8/29.
//
//

#import <Foundation/Foundation.h>

//结构体按照一个字节对齐
#pragma pack(1)
#import "ParamsStruct.h"
#pragma options align=reset

typedef NS_ENUM(NSUInteger, controlTypeIsWrite) {

    controlTypeRead,
    controlTypeWrite,
    
};

typedef NS_ENUM(NSUInteger, controlTypeIsQueue) {
    
    controlTypeNormal,
    controlTypeQueue,
    
};


typedef NS_ENUM(NSUInteger, ProtocolID) {
    
    // Device information
    ProtocolDeviceSN = 0,
    ProtocolDeviceName,
    ProtocolDeviceVersion,
    
    // Pose
    ProtocolGetPose = 10,
    ProtocolResetPose,
    ProtocolGetKinematics,
    
    // Alarm
    ProtocolAlarmsState = 20,
    
    // HOME
    ProtocolHOMEParams = 30,
    ProtocolHOMECmd,
    
    // HHT
    ProtocolHHTTrigMode = 40,
    ProtocolHHTTrigOutputEnabled,
    ProtocolHHTTrigOutput,
    
    // Function-Arm Orientation
    ProtocolArmOrientation = 50,
    
    // End effector
    ProtocolEndEffectorParams = 60,
    ProtocolEndEffectorLaser,
    ProtocolEndEffectorSuctionCup,
    ProtocolEndEffectorGripper,
    
    // Function-JOG
    ProtocolJOGJointParams = 70,
    ProtocolJOGCoordinateParams,
    ProtocolJOGCommonParams,
    ProtocolJOGCmd,
    
    // Function-PTP
    ProtocolPTPJointParams = 80,
    ProtocolPTPCoordinateParams,
    ProtocolPTPJumpParams,
    ProtocolPTPCommonParams,
    ProtocolPTPCmd,
    
    // Function-CP
    ProtocolCPParams = 90,
    ProtocolCPCmd,
    ProtocolCPLECmd,//激光灰度雕刻
    
    // Function-ARC
    ProtocolARCParams = 100,
    ProtocolARCCmd,
    
    // Function-WAIT
    ProtocolWAITCmd = 110,
    
    // Function-TRIG
    ProtocolTRIGCmd = 120,
    
    // Function-EIO
    ProtocolIOMultiplexing = 130,
    ProtocolIODO,
    ProtocolIOPWM,
    ProtocolIODI,
    ProtocolIOADC,
    
    // Function-CAL
    ProtocolAngleSensorStaticError = 140,
    
    // Function-TEST
    ProtocolUserParams = 220,
    
    // Function-ZDF
    ProtocolZDFCalibRequest = 230,
    ProtocolZDFCalibStatus,
    
    // Function-QueuedCmd
    ProtocolQueuedCmdStartExec = 240,
    ProtocolQueuedCmdStopExec,
    ProtocolQueuedCmdForceStopExec,
    ProtocolQueuedCmdStartDownload,
    ProtocolQueuedCmdStopDownload,
    ProtocolQueuedCmdClear,
    ProtocolQueuedCmdCurrentIndex,
    ProtocolQueuedCmdLeftSpace,
    
    ProtocolMax = 256
};

typedef struct  {
    
    unsigned int isWrite:1;
    unsigned int isQueue:1;
    unsigned int :6;
    
}controlTypeCmd;

typedef NS_ENUM(NSUInteger, MsgResult)
{
    MsgResult_Ok,
    MsgResult_TimeOut,
    
};

typedef void(^msgCallBack)(MsgResult result,id msg);

@interface Payload : NSObject
{
    
}
@property (nonatomic,assign) uint8_t ID;
@property (nonatomic,strong) NSData *params;

//默认isWrite = 0，isQueue = 0
@property (nonatomic,assign) controlTypeCmd controlType;
@property (nonatomic,strong) msgCallBack complete;

-(void)setProtocolID:(ProtocolID)protocolID;
-(void)setWriteMode;
-(void)setQueueMode;

-(NSData *)content;
-(id)initWithData:(NSData *)data;
-(void)contentWithData:(NSData *)data;

//读取参数
-(void)cmdGetPose;
-(void)cmdSetPose:( Pose)pose;

-(void)cmdResetPose:(ResetPose)p;


-(void)cmdGetKinematices;

//设置／读取回零参数
-(void)cmdGetHOMEParams;
-(void)cmdSetHOMEParams:(HomeParams)homeParams;

//执行回零操作
-(void)cmdHome;


-(void)cmdGetHHTTrigeMode;
-(void)cmdSetHHTTrigeMode:(HHTTrigMode)mode;


//执行点动
-(void)cmdJog:(JOGCmd)jogCmd;

//执行坐标轴点动
-(void)cmdJOGcoordinate:(JOGCmdCoordinate)cmdCoordinate;

//点动公共参数
-(void)cmdGetJOGCommonParams;
-(void)cmdSetJOGCommonParams:(JOGCommonParams)p;

//获取坐标轴点动参数
-(void)cmdGetJOGCoordinateParams;
-(void)cmdSetJOGCoordinateParams:( JOGCoordinateParams)params;

//PTP坐标轴点位参数
-(void)cmdGetPTPCoordinateParams;
-(void)cmdSetPTPCoordinateParams:( PTPCoordinateParams)params;

//执行PTP
-(void)cmdPTP:(PTPCmd)p;

//获取cp参数
-(void)cmdGetCPParams;
-(void)cmdSetCPParams:(CPParams)p;

//设置末端参数
-(void)cmdSetEndEffectorParams:(EndEffectorParams)p;
-(void)cmdGetEndEffectorParams;

//激光
-(void)cmdSetLaser:(BOOL)isOn isQueue:(BOOL)isQueue;
-(void)cmdGetLaser;

//执行CP
-(void)cmdCP:(CPCmd)p;
-(void)cmdCPLE:(CPCmd)p;

//设置EIO复用
-(void)cmdSetIOMultiplexing:(IOMultiplexing)ioMultiplexing isQueue:(BOOL)isQueue;
-(void)cmdGetIOMultiplexing:(IOMultiplexing)ioMultiplexing;

//设置/读取IO输出电平
-(void)cmdSetIODO:(IODO)ioDO isQueue:(BOOL)isQueue;
-(void)cmdGetIODO:(IODO)ioDO;

//设置/读取IO PWM
-(void)cmdSetIOPWM:(IOPWM)ioPWM isQueue:(BOOL)isQueue;
-(void)cmdGetIOPWM:(IOPWM)ioPWM;

//读取IO 输入电平
-(void)cmdGetIODI:(IODI)ioDI;

//读取IO 模数转换值
-(void)cmdGetIOADC:(IOADC)ioADC;

//队列命令
-(void)cmdClearQueue;
-(void)cmdStartQueue;
-(void)cmdStopQueue;
-(void)cmdForceStopQueue;
-(void)cmdQueueCurrentIndex;
-(void)cmdQueueLeftSpace;


@end

//
//  BLEMsgMgr.h
//  DoBot
//
//  Created by Gino on 16/8/26.
//
//

#import <Foundation/Foundation.h>
#import "BLE.h"
#import "DobotMagicianMsg.h"

@protocol BLEMsgMgrDelegate <NSObject>

@optional

-(void)didConnect;
-(void)didDisconnect;
-(void)didScanDeviceTimeout;
-(void)didFindAvailabePeripheral:(NearbyPeripheralInfo *)nearbyPeripheralInfo;

-(void)didReadRSSI:(NSNumber *) rssi;
-(void)didReceiveData:(unsigned char *) data length:(int) length;

@end

@protocol MsgHandler

-(void)handleMsg:(DobotMagicianMsg*)msg;

@end


@interface BLEMsgMgr : NSObject

//记录落笔点的z轴位置
@property (nonatomic,assign) float penDownZ;

@property (nonatomic,weak) id<BLEMsgMgrDelegate> delegate;


+(instancetype)sharedMgr;


-(void)scanDevice:(float)timeout mode:(BLESearchMode)mode;
-(void)connectToDevice:(CBPeripheral *)peripheral;
-(void)disconnect;
-(BOOL)isConnected;

-(void)sendMsg:(Payload *)payload;

-(void)addMsgHandler:(id<MsgHandler>)handler;
-(void)removeHandler:(id<MsgHandler>)handler;


-(void)pause;
-(void)start;
-(void)clear;



@end

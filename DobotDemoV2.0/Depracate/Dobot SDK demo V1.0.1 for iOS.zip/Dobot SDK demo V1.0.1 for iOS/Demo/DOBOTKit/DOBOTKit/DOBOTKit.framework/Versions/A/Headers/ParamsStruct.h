//
//  ParamsStruct.h
//  DoBot
//
//  Created by Gino on 16/8/31.
//
//

#ifndef ParamsStruct_h
#define ParamsStruct_h

//位姿
typedef struct {
    
    float x;
    float y;
    float z;
    float r;
    float jointAngle[4];
}Pose;


//重设位姿
typedef struct {
    
    uint8_t manual;
    float rearArmAngle;
    float frontArmAngle;
}ResetPose;

//运动学参数

typedef struct {
    
    float velocity;
    float acceleration;
}Kinematics;


//回零参数
typedef struct  {
    
    float x;
    float y;
    float z;
    float r;
}HomeParams;


//触发模式
typedef NS_ENUM(NSUInteger,HHTTrigMode){
    
    TriggeredOnKeyReleased,//按键释放时更新
    TriggeredOnPeriodicInterval,//定时触发
};

//末端参数
typedef struct {
    
    float xBias;
    float yBias;
    float zBias;
}EndEffectorParams;

//末端输出
typedef struct {
    uint8_t isCtrlEnabled;
    uint8_t isOn;

}EndEffectorOutput;

typedef NS_ENUM(NSUInteger,EndEffectorType){
    
    EndEffectorType_Pen,
    EndEffectorType_Laser,
};


//笔
static EndEffectorParams EndEffector_Pen = {
    61.0f,
    0.0f,
    0.0f,
};

//激光
static EndEffectorParams EndEffector_Laser = {
    70.0f,
    0.0f,
    0.0f,
};


//手臂方向
typedef NS_ENUM(NSUInteger,ArmOrientation){
    
    ArmOrientationLeft,
    ArmOrientationRight,
};


//点动公共参数
typedef struct  {
    
    float velocityRatio; //1-100 速度比例
    float accelerationRatio;//1-100 加速度比例
}JOGCommonParams;


//关节点动参数
typedef struct  {
    
    float velocity[4];     //每个关节的最大速度
    float acceleration[4]; //每个关节的最大加速度
}JOGJointParams;

//坐标轴点动参数
typedef struct  {
    
    float velocity[4];      //每个坐标轴方向的最大速度
    float acceleration[4];  //每个坐标轴方向的最大加速度
}JOGCoordinateParams;

//执行点动命令
typedef struct  {
    
    uint8_t isJoint;//1 关节点动  0 坐标轴点动
    uint8_t cmd;//命令 0 停止（按键抬起） 坐标轴点动时：1:X+ 2:X- 3:Y+ 4:Y- 5:Z+ 6:Z- 7:R+ 8:R-
}JOGCmd;

//点动命令 mode（坐标轴／关节）
typedef NS_ENUM(NSUInteger,JOGCmdMode){
    
    JOGCmdMode_Coordinate = 0,//坐标轴
    JOGCmdMode_Joint,         //关节
};

//坐标轴点动命令
typedef NS_ENUM(NSUInteger,JOGCmdCoordinate){
    
    JOGCmdCoordinate_Stop = 0,  //停止
    JOGCmdCoordinate_Xplus,     //x+/J1+
    JOGCmdCoordinate_Xminus,    //x-/J1-
    JOGCmdCoordinate_Yplus,     //y+/J2+
    JOGCmdCoordinate_Yminus,    //y-/J2-
    JOGCmdCoordinate_Zplus,     //z+/J3+
    JOGCmdCoordinate_Zminus,    //z-/J3-
    JOGCmdCoordinate_Rplus,     //r+/J4+
    JOGCmdCoordinate_Rminus,    //r-/J4-
};

//PTP mode
typedef NS_ENUM(uint8_t,PTPMode){
    
    PTPMode_Jump = 0x00,   //门型模式
    PTPMode_MoveJ,      //关节模式
    PTPMode_MoveL,      //直线模式
    
    PTPMode_Jump_Angle,
    PTPMode_MoveJ_Angle,
    PTPMode_MoveL_Angle,
    
    PTPMode_MoveJ_increment,
    PTPMode_MoveL_increment,
    
};


//PTP命令
typedef  struct   {
    
    PTPMode ptpMode;
    float x;
    float y;
    float z;
    float r;
}PTPCmd;

//PTP坐标轴点位参数
typedef struct  {
    
    float xyzVelocity;
    float rVelocity;
    float xyzAcceleration;
    float rAcceleration;
}PTPCoordinateParams;




//CP参数
typedef struct{
    
    float planAcc;
    float junctionVel;
    union{
        float acc; //realTimeTrack = false
        float period; //realTimeTrack = true
    };
    uint8_t realTimeTrack;
    
}CPParams;

//CP命令
typedef struct{
    
    uint8_t cpMode;
    float x;
    float y;
    float z;
    union{
        
        float velocity;
        float power;//0-100
    };
}CPCmd;

typedef NS_ENUM(NSUInteger,CPMode){
 
    CPMode_relative = 0x00,
    CPMode_absolute,
};


//IO复用
typedef struct{
    uint8_t address;//地址 1- 20
    uint8_t multiplex;// IOFunctiion
}IOMultiplexing;


typedef NS_ENUM(NSUInteger,IOFunction){
    
    IOFunctionDummy,//不配置功能
    IOFunctionPWM,
    IOFunctionDO,
    IOFunctionDI,
    IOFunctionADC,
};

//I/O 输出电平
typedef struct{
    uint8_t address;
    uint8_t level;//0:低电平，1:高电平
}IODO;

//I/O PWM输出
typedef struct{
    uint8_t address;
    uint8_t frequency;//频率，10HZ-1MHZ
    uint8_t dutyCycle;//占空比 0-100
}IOPWM;

//I/O 输入电平
typedef struct{
    uint8_t address;
    uint8_t level;
}IODI;

//I/O 模数转换值
typedef struct{
    uint8_t address;
    uint16_t value;
}IOADC;

//扩展电机接口
typedef struct{
    uint8_t index;
    uint8_t isEnable;
    float speed;
}EMotor;



#endif /* ParamsStruct_h */

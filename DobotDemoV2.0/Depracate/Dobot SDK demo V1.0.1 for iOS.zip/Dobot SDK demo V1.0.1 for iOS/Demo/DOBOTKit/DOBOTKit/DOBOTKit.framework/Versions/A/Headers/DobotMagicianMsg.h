//
//  DobotMagicianMsg.h
//  DoBot
//
//  Created by Gino on 16/8/29.
//
//

#import <Foundation/Foundation.h>
#import "Payload.h"

@interface DobotMagicianMsg : NSObject
@property (nonatomic,strong) Payload *payload;

+(int) msgPackageMinLength;
+(int) msgPackageMaxLength;
-(NSData *)msgData;
-(id)initWithData:(NSData *)data;
@end

//
//  AppDelegate.h
//  DOBOTKit
//
//  Created by Gino on 2017/2/27.
//  Copyright © 2017年 Dobot. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


//
//  ViewController.h
//  DOBOTKit
//
//  Created by Gino on 2017/2/27.
//  Copyright © 2017年 Dobot. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController



@property (nonatomic,weak) IBOutlet UIButton *btnBLEConnect;

@property (nonatomic,weak) IBOutlet UILabel *lblLog;

@property (nonatomic,weak) IBOutlet UISwitch *jogModeSwitch;

@property (nonatomic,weak) IBOutlet UIButton *btnXplus;
@property (nonatomic,weak) IBOutlet UIButton *btnXminus;
@property (nonatomic,weak) IBOutlet UIButton *btnYplus;
@property (nonatomic,weak) IBOutlet UIButton *btnYminus;


-(IBAction)btnBLEConnectTaped:(UIButton *)sender;

-(IBAction)btnGetPoseTaped:(id)sender;

-(IBAction)btnPTPCmdsTaped:(id)sender;

-(IBAction)btnStopTimerTaped:(id)sender;

-(IBAction)btnStartQueueTaped:(id)sender;

-(IBAction)btnForceStopQueueTaped:(id)sender;

-(IBAction)btnClearQueueTaped:(id)sender;


-(IBAction)switchJogMode:(id)sender;

-(IBAction)btnEIOTaped:(id)sender;

-(IBAction)btnStopEIOTaped:(id)sender;

-(IBAction)btnGetEIOTaped:(id)sender;


@end


# AVET API

AVET es el servicio de venta de entradas y abonos de la LPF. Este servicio es utilizado obligatoriamente por los clubs de la liga española para gestionar la ocupación de sus estadios.

El servicio está disponible desde las oficinas de cada club, no obstante, también dispone de una API SOAP para canales de venta externos. A nivel de seguridad, la conexión con esta API se debe realizar entre servidores mediante una VPN previamente configurada.

## EL PROYECTO

El proyecto pasa por ofrecer una API REST pública, que simplifique la comunicación de aplicaciones web, como Transfer3D, con AVET. La API permitirá intercambiar objetos con AVET para renovar, dar de baja o dar de alta los abonos de los socios del club.

El proyecto trata de aplicar, en medida de lo posible, los principios SOLID de desarrollo. Teniendo en cuenta estas reglas de calidad en el código, se ha tratado de seguir la metodología de desarrollo DDD.

## EL CÓDIGO

Se ha empleado el micro-framework SlimPHP para implementar una API-REST. El objetivo de los diferentes endpoints de la aplicación es obtener y enviar datos desde la aplicación hasta la API de AVET. Todo el código base está en el path /src. De forma nativa, SlimPHP proporciona los siguientes ficheros, que inicializan y configuran la aplicación:

- settings.php : Variables de configuración
- dependencies.php : Contenedor de dependencias, usadas principalmente en el fichero de rutas.
- middleware.php : Clases que modifican las peticiones antes y después de la ejecución de las rutas
- routes.php : Definición endpoints

Junto a estos ficheros hemos implementado una arquitectura tipo Modelo-Controlador, que separa el desarrollo de la lógica de negocio del desarrollo del modelo de datos. La capa de negocio está implementada en los controladores, ubicados en el fichero /src/Controller. La capa de datos está implementada en la carpeta /src/Model, mediante las clases:

- Entities
- Factories
- Repositories

Los repositorios sirven principalmente para implementar el patrón strategy. Los repositorios implementan una interfaz, de forma que los controladores disponen de una forma  de acceso única a los datos del modelo. Actualmente, a los repositorios se les inyecta un cliente SOAP, con el cual se realizan las peticiones a la API de AVET. Posteriormente, se emplean los factories para devolver la respuesta de la petición como instancia de una entidad.

Finalmente, se han implementado una serie de utilidades ubicadas en la carpeta src/Utils.

## VALIDACIÓN DE DATOS

Uno de los motivos del desarrollo de la aplicación es la validación de datos. AVET no proporciona información detallada respecto a la validación de datos. Las entidades disponen de un método estático que permite validar datos de forma previa al envío de datos a AVET. La validación de datos se realiza mediante la librería Respect\Validation (https://github.com/Respect/Validation).

La librería dispone de una gran colección de validadores de datos (https://github.com/Respect/Validation/blob/1.1/docs/VALIDATORS.md) y proporciona mensajes de error de las validaciones realizadas.

## DEPLOYMENT

La aplicación puede comunicarse con la API de AVET únicamente a través de una conexión VPN. Actualmente, el entorno de desarrollo se encuentra en una instancia EC2 y el código se actualiza mediante rsync. Se puede realizar un deployment del código en pre-producción con el comando:

 	composer deploy_pre

Este comando, además de actualizar el código en el entorno de pre-producción, actualiza la documentación automática generada mediante Swagger.

## TODO

- Preparar entorno de producción y un método de deployment.
- Desacoplar obtención de datos mediante el cliente soap en los repositorios en modelos.

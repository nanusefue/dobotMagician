<?php
/**
 * AreaAvailabilityFactory unit tests
 */

use App\Model\Factories\AreaAvailabilityFactory as AreaAvailabilityFactory;
use App\Utils\Error\ErrorException as ErrorException;

use PHPUnit\Framework\TestCase;

class AreaAvailabilityFactoryTest extends TestCase
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Test createErrorInstance
     * @return void
     */
    public function test_createErrorInstance()
    {
        $errorException = new ErrorException;
        $result = AreaAvailabilityFactory::createErrorInstance($errorException);
        $this->assertInstanceOf("App\Model\Entities\AreaAvailability", $result);
        $this->assertInternalType("boolean", $result->isError());
        $this->assertTrue($result->isError());
    }
}

?>

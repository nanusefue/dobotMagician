<?php
/**
 * PagoFactory unit tests
 */

use App\Model\Factories\PagoFactory as PagoFactory;
use App\Utils\Error\ErrorException as ErrorException;

use PHPUnit\Framework\TestCase;

class PagoFactoryTest extends TestCase
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Test createErrorInstance
     * @return void
     */
    public function test_createErrorInstance()
    {
        $errorException = new ErrorException;
        $result = PagoFactory::createErrorInstance($errorException);
        $this->assertInstanceOf("App\Model\Entities\Pago", $result);
        $this->assertInternalType("boolean", $result->isError());
        $this->assertTrue($result->isError());
    }
}

?>

<?php
/**
 * SeatingAreaFactory unit tests
 */

use App\Model\Factories\SeatingAreaFactory as SeatingAreaFactory;
use App\Utils\Error\ErrorException as ErrorException;

use PHPUnit\Framework\TestCase;

class SeatingAreaFactoryTest extends TestCase
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Test createErrorInstance
     * @return void
     */
    public function test_createErrorInstance()
    {
        $errorException = new ErrorException;
        $result = SeatingAreaFactory::createErrorInstance($errorException);
        $this->assertInstanceOf("App\Model\Entities\SeatingArea", $result);
        $this->assertInternalType("boolean", $result->isError());
        $this->assertTrue($result->isError());
    }
}

?>

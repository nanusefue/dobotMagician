<?php
/**
 * PersonaInfoFactory unit tests
 */

use App\Model\Factories\PersonaInfoFactory as PersonaInfoFactory;
use App\Utils\Error\ErrorException as ErrorException;

use PHPUnit\Framework\TestCase;

class PersonaInfoFactoryTest extends TestCase
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Test createErrorInstance
     * @return void
     */
    public function test_createErrorInstance()
    {
        $errorException = new ErrorException;
        $result = PersonaInfoFactory::createErrorInstance($errorException);
        $this->assertInstanceOf("App\Model\Entities\PersonaInfo", $result);
        $this->assertInternalType("boolean", $result->isError());
        $this->assertTrue($result->isError());
    }
}

?>

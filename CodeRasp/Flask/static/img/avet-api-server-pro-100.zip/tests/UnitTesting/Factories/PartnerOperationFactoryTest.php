<?php
/**
 * PartnerOperationFactory unit tests
 */

use App\Model\Factories\PartnerOperationFactory as PartnerOperationFactory;
use App\Utils\Error\ErrorException as ErrorException;

use PHPUnit\Framework\TestCase;

class PartnerOperationFactoryTest extends TestCase
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Test createErrorInstance
     * @return void
     */
    public function test_createErrorInstance()
    {
        $errorException = new ErrorException;
        $result = PartnerOperationFactory::createErrorInstance($errorException);
        $this->assertInstanceOf("App\Model\Entities\PartnerOperation", $result);
        $this->assertInternalType("boolean", $result->isError());
        $this->assertTrue($result->isError());
    }
}

?>

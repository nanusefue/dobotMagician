<?php
/**
 * PlazoInfoFactory unit tests
 */

use App\Model\Factories\PlazoInfoFactory as PlazoInfoFactory;
use App\Utils\Error\ErrorException as ErrorException;

use PHPUnit\Framework\TestCase;

class PlazoInfoFactoryTest extends TestCase
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Test createErrorInstance
     * @return void
     */
    public function test_createErrorInstance()
    {
        $errorException = new ErrorException;
        $result = PlazoInfoFactory::createErrorInstance($errorException);
        $this->assertInstanceOf("App\Model\Entities\PlazoInfo", $result);
        $this->assertInternalType("boolean", $result->isError());
        $this->assertTrue($result->isError());
    }
}

?>

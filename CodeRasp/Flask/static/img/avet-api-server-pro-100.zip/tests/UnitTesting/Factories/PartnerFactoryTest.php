<?php
/**
 * PartnerFactory unit tests
 */

use App\Model\Factories\PartnerFactory as PartnerFactory;
use App\Utils\Error\ErrorException as ErrorException;

use PHPUnit\Framework\TestCase;

class PartnerFactoryTest extends TestCase
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Test createErrorInstance
     * @return void
     */
    public function test_createErrorInstance()
    {
        $errorException = new ErrorException;
        $result = PartnerFactory::createErrorInstance($errorException);
        $this->assertInstanceOf("App\Model\Entities\Partner", $result);
        $this->assertInternalType("boolean", $result->isError());
        $this->assertTrue($result->isError());
    }
}

?>

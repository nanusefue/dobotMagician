<?php
/**
 * PaymentModeFactory unit tests
 */

use App\Model\Factories\RolPartnerInfoFactory as RolPartnerInfoFactory;
use App\Utils\Error\ErrorException as ErrorException;

use PHPUnit\Framework\TestCase;

class RolPartnerInfoFactoryTest extends TestCase
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Test createErrorInstance
     * @return void
     */
    public function test_createErrorInstance()
    {
        $errorException = new ErrorException;
        $result = RolPartnerInfoFactory::createErrorInstance($errorException);
        $this->assertInstanceOf("App\Model\Entities\RolPartnerInfo", $result);
        $this->assertInternalType("boolean", $result->isError());
        $this->assertTrue($result->isError());
    }
}

?>

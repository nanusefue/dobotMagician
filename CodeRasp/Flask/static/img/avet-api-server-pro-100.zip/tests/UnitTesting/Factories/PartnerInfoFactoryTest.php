<?php
/**
 * PartnerInfoFactory unit tests
 */

use App\Model\Factories\PartnerInfoFactory as PartnerInfoFactory;
use App\Utils\Error\ErrorException as ErrorException;

use PHPUnit\Framework\TestCase;

class PartnerInfoFactoryTest extends TestCase
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Test createErrorInstance
     * @return void
     */
    public function test_createErrorInstance()
    {
        $errorException = new ErrorException;
        $result = PartnerInfoFactory::createErrorInstance($errorException);
        $this->assertInstanceOf("App\Model\Entities\PartnerInfo", $result);
        $this->assertInternalType("boolean", $result->isError());
        $this->assertTrue($result->isError());
    }
}

?>

<?php
/**
 * PaymentModeFactory unit tests
 */

use App\Model\Factories\PaymentModeFactory as PaymentModeFactory;
use App\Utils\Error\ErrorException as ErrorException;

use PHPUnit\Framework\TestCase;

class PaymentModeFactoryTest extends TestCase
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Test createErrorInstance
     * @return void
     */
    public function test_createErrorInstance()
    {
        $errorException = new ErrorException;
        $result = PaymentModeFactory::createErrorInstance($errorException);
        $this->assertInstanceOf("App\Model\Entities\PaymentMode", $result);
        $this->assertInternalType("boolean", $result->isError());
        $this->assertTrue($result->isError());
    }
}

?>

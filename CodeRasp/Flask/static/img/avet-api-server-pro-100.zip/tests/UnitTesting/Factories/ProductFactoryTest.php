<?php
/**
 * ProductFactory unit tests
 */

use App\Model\Factories\ProductFactory as ProductFactory;
use App\Utils\Error\ErrorException as ErrorException;

use PHPUnit\Framework\TestCase;

class ProductFactoryTest extends TestCase
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Test createErrorInstance
     * @return void
     */
    public function test_createErrorInstance()
    {
        $errorException = new ErrorException;
        $result = ProductFactory::createErrorInstance($errorException);
        $this->assertInstanceOf("App\Model\Entities\Product", $result);
        $this->assertInternalType("boolean", $result->isError());
        $this->assertTrue($result->isError());
    }
}

?>

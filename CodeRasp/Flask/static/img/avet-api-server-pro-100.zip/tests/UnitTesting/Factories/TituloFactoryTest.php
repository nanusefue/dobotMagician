<?php
/**
 * PaymentModeFactory unit tests
 */

use App\Model\Factories\TituloFactory as TituloFactory;
use App\Utils\Error\ErrorException as ErrorException;

use PHPUnit\Framework\TestCase;

class TituloFactoryTest extends TestCase
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Test createErrorInstance
     * @return void
     */
    public function test_createErrorInstance()
    {
        $errorException = new ErrorException;
        $result = TituloFactory::createErrorInstance($errorException);
        $this->assertInstanceOf("App\Model\Entities\Titulo", $result);
        $this->assertInternalType("boolean", $result->isError());
        $this->assertTrue($result->isError());
    }
}

?>

<?php
/**
 * PartnerOperation unit tests
 */

use App\Model\Entities\PartnerOperation as PartnerOperation;

use PHPUnit\Framework\TestCase;

class PartnerOperationTest extends TestCase
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Test validate
     * @return void
     */
    public function test_validate()
    {

        // $result = PartnerOperation::validate([]);
        $this->assertEquals(1,1);

    }
}

?>

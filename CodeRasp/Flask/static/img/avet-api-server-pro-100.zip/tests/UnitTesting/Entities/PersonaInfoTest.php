<?php
/**
 * PersonaInfo unit tests
 */

use App\Model\Entities\PersonaInfo as PersonaInfo;

use PHPUnit\Framework\TestCase;

class PersonaInfoTest extends TestCase
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Test validate
     * @return void
     */
    public function test_validate()
    {
        // Empty required fields
        $data = [];
        $result = PersonaInfo::validate($data);
        $this->assertInstanceOf("App\Utils\Error\ErrorException", $result);
        $this->assertTrue($result->isError());
        $expected = [
            'Attribute Apellido1 must be present',
            'Attribute Apellido2 must be present',
            'Attribute Ayuntamiento must be present',
            'Attribute CodigoPostal must be present',
            'Attribute CodProvincia must be present',
            'Attribute Domicilio_Calle must be present',
            'Attribute Domicilio_CodVia must be present',
            'Attribute Domicilio_Escalera must be present',
            'Attribute Domicilio_Numero must be present',
            'Attribute Domicilio_Piso must be present',
            'Attribute DNI must be present',
            'Attribute Email must be present',
            'Attribute Empresa must be present',
            'Attribute FechaNacimiento must be present',
            'Attribute IBAN must be present',
            'Attribute IdProfesion must be present',
            'Attribute LetraNIF must be present',
            'Attribute Localidad must be present',
            'Attribute Nombre must be present',
            'Attribute Observaciones must be present',
            'Attribute Pais must be present',
            'Attribute Santo must be present',
            'Attribute Sexo must be present',
            'Attribute Telefono must be present',
            'Attribute Telefono_Fax must be present',
            'Attribute Telefono_Movil must be present',
            'Attribute Telefono_Oficina must be present'
        ];
        $this->assertEquals($expected, $result->getMessage());

        // Bad required fields
        $data = [
            'Apellido1' => '',
            'Apellido2' => '',
            'Ayuntamiento' => '',
            'CodigoPostal' => '',
            'CodProvincia' => '',
            'Domicilio_Calle' => '',
            'Domicilio_CodVia' => '',
            'Domicilio_Escalera' => '',
            'Domicilio_Numero' => '',
            'Domicilio_Piso' => '',
            'DNI' => '',
            'Email' => '',
            'Empresa' => '',
            'FechaNacimiento' => '',
            'IBAN' => '',
            'IdProfesion' => '',
            'LetraNIF' => '',
            'Localidad' => '',
            'Nombre' => '',
            'Observaciones' => '',
            'Pais' => '',
            'Santo' => '',
            'Sexo' => '',
            'Telefono' => '',
            'Telefono_Fax' => '',
            'Telefono_Movil' => '',
            'Telefono_Oficina' => ''
        ];
        $result = PersonaInfo::validate($data);
        $this->assertInstanceOf("App\Utils\Error\ErrorException", $result);
        $this->assertTrue($result->isError());
        $expected = [
            'These rules must pass for CodigoPostal',
            'CodigoPostal must be an integer number',
            'CodigoPostal must have a length between 1 and 5',
            'These rules must pass for CodProvincia',
            'CodProvincia must be an integer number',
            'CodProvincia must have a length between 1 and 2',
            'Email must be valid email',
            'FechaNacimiento must be a valid date. Sample format: "2005-12-30"',
            'LetraNIF must have a length between 1 and 1',
            'Santo must be a valid date. Sample format: "3012"',
            'Sexo must be in { "H", "M" }'
        ];
        $this->assertEquals($expected, $result->getMessage());

        // Good fields
        $data = [
            'Apellido1' => 'Apellido1',
            'Apellido2' => 'Apellido2',
            'Ayuntamiento' => 'Ayuntamiento',
            'CodigoPostal' => '08850',
            'CodProvincia' => '08',
            'Domicilio_Calle' => 'Domicilio_Calle',
            'Domicilio_CodVia' => 'Domicilio_CodVia',
            'Domicilio_Escalera' => 'Domicilio_Escalera',
            'Domicilio_Numero' => 'Domicilio_Numero',
            'Domicilio_Piso' => 'Domicilio_Piso',
            'DNI' => 'DNI',
            'Email' => 'email@email.com',
            'Empresa' => '',
            'FechaNacimiento' => '1970-01-01',
            'IBAN' => '112312321',
            'IdProfesion' => '0',
            'LetraNIF' => 'A',
            'Localidad' => 'Localidad',
            'Nombre' => 'Nombre',
            'Observaciones' => '',
            'Pais' => 'Pais',
            'Santo' => '3012',
            'Sexo' => 'H',
            'Telefono' => 'Telefono',
            'Telefono_Fax' => 'Telefono_Fax',
            'Telefono_Movil' => 'Telefono_Movil',
            'Telefono_Oficina' => 'Telefono_Oficina'
        ];
        $result = PersonaInfo::validate($data);
        $this->assertInstanceOf("App\Utils\Error\ErrorException", $result);
        $this->assertFalse($result->isError());
    }
}

?>

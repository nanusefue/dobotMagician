<?php
/**
 * PartnerInfo unit tests
 */

use App\Model\Entities\PartnerInfo as PartnerInfo;

use PHPUnit\Framework\TestCase;

class PartnerInfoTest extends TestCase
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Test validate
     * @return void
     */
    public function test_validate()
    {
        // Empty required fields
        $data = [];
        $result = PartnerInfo::validate($data);
        $this->assertInstanceOf("App\Utils\Error\ErrorException", $result);
        $this->assertTrue($result->isError());
        $expected = [
            'Attribute FechaAlta must be present'
        ];
        $this->assertEquals($expected, $result->getMessage());

        // Bad required fields
        $data = [
            "FechaAlta" => "01-01-2018 00:00:00"
        ];
        $result = PartnerInfo::validate($data);
        $this->assertInstanceOf("App\Utils\Error\ErrorException", $result);
        $this->assertTrue($result->isError());
        $expected = [
            'FechaAlta must be a valid date. Sample format: "2005-12-30T01:02:03"'
        ];
        $this->assertEquals($expected, $result->getMessage());

        // Good fields
        $data = [
            "FechaAlta" => "2018-01-01T00:00:00"
        ];
        $result = PartnerInfo::validate($data);
        $this->assertInstanceOf("App\Utils\Error\ErrorException", $result);
        $this->assertFalse($result->isError());
    }
}

?>

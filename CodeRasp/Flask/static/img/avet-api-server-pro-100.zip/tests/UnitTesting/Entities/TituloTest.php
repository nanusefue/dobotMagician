<?php
/**
 * Titulo unit tests
 */

use App\Model\Entities\Titulo as Titulo;

use PHPUnit\Framework\TestCase;

class TituloTest extends TestCase
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Test validate
     * @return void
     */
    public function test_validate()
    {
        // Empty required fields
        $data = [];
        $result = Titulo::validate($data);
        $this->assertInstanceOf("App\Utils\Error\ErrorException", $result);
        $this->assertTrue($result->isError());
        $expected = [
            'Attribute Asiento must be present',
            'Attribute Fila must be present',
            'Attribute IdAforo must be present',
            'Attribute IdAsiento must be present',
            'Attribute IdPeriodicidad must be present',
            'Attribute IdTipoAbono must be present',
            'Attribute IdZona must be present',
            'Attribute Validez must be present'
        ];
        $this->assertEquals($expected, $result->getMessage());

        // Bad required fields
        $data = [
            'Asiento' => 0,
            'Fila' => 0,
            'IdAforo' => '',
            'IdAsiento' => '',
            'IdPeriodicidad' => '',
            'IdTipoAbono' => '',
            'IdZona' => '',
            'Validez' => 0
        ];
        $result = Titulo::validate($data);
        $this->assertInstanceOf("App\Utils\Error\ErrorException", $result);
        $this->assertTrue($result->isError());
        $expected = [
            'Asiento must be a string',
            'Fila must be a string',
            'IdAforo must be of the type integer',
            'IdAsiento must be of the type integer',
            'IdPeriodicidad must be of the type integer',
            'IdTipoAbono must be of the type integer',
            'IdZona must be of the type integer',
            'Validez must be a string'
        ];
        $this->assertEquals($expected, $result->getMessage());

        // Good fields
        $data = [
            'Asiento' => '0000',
            'Fila' => '0000',
            'IdAforo' => 0,
            'IdAsiento' => 0,
            'IdPeriodicidad' => 0,
            'IdTipoAbono' => 0,
            'IdZona' => 0,
            'Validez' => 'A'
        ];
        $result = Titulo::validate($data);
        $this->assertInstanceOf("App\Utils\Error\ErrorException", $result);
        $this->assertFalse($result->isError());
    }
}

?>

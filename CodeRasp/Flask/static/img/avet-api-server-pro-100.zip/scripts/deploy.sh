#!/bin/bash
cp /var/www/html/scripts/avet.conf /etc/httpd/conf.d/avet.conf
sudo rm /var/www/html/docker-compose.yml
sudo rm /var/www/html/phpunit.xml
sudo rm /var/www/html/sonar-project.properties
sudo rm -R /var/www/html/tests
sudo service httpd restart
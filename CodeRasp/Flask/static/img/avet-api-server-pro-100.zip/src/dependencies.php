<?php
/**
 * DIC configuration. All dependencies will be loaded in our dependency container
 * ready to be used in the application, mainly in the router.
 */

use App\Utils\SoapFactory as SoapFactory;
use App\Controller\AforosController as AforosController;
use App\Controller\AreasController as AreasController;
use App\Controller\MotivoEmisionController as MotivoEmisionController;
use App\Controller\PartnerOpController as PartnerOpController;
use App\Controller\PaymentModesController as PaymentModesController;
use App\Controller\ProductsController as ProductsController;
use App\Controller\PlazosController as PlazosController;
use App\Controller\RolesController as RolesController;
use App\Controller\SeatingAreaController as SeatingAreaController;
use App\Controller\SeatStatusController as SeatStatusController;
use App\Controller\PaymentController as PaymentController;
use App\Utils\Cache\RedisClient as RedisClient;
use App\Controller\ClientController as ClientController;

$container = $app->getContainer();

// Redis cache engine
$container['redis'] = function ($c) {
    $config = $c->get('settings')['redis'];
    return new RedisClient($config);
};

// Load soap clients
$container['SubscriberOperation'] = function($c) {
    $config = $c->get('settings')['avet'];
    return SoapFactory::getSubscriberOperations($config);
};

$container['VenueConfiguration'] = function($c) {
    $config = $c->get('settings')['avet'];
    return SoapFactory::getVenueConfiguration($config);
};

// Load controllers
$container["AforosController"] = function($c) {
    $config = $c->get('settings')['avet'];
    $soapclient = SoapFactory::getVenueConfiguration($config);
    return new AforosController($soapclient);
};

$container["AreasController"] = function($c) {
    $config = $c->get('settings')['avet'];
    $soapclient = SoapFactory::getSubscriberOperations($config);
    return new AreasController($soapclient);
};

$container["MotivoEmisionController"] = function($c) {
    $config = $c->get('settings')['avet'];
    $soapclient = SoapFactory::getSubscriberOperations($config);
    return new MotivoEmisionController($soapclient);
};

$container["PartnerOpController"] = function($c) {
    $config = $c->get('settings')['avet'];
    $soapclient = SoapFactory::getSubscriberOperations($config);
    return new PartnerOpController($soapclient, $c->redis);
};

$container["PaymentModesController"] = function($c) {
    $config = $c->get('settings')['avet'];
    $soapclient = SoapFactory::getSubscriberOperations($config);
    return new PaymentModesController($soapclient);
};

$container["PlazosController"] = function($c) {
    $config = $c->get('settings')['avet'];
    $soapclient = SoapFactory::getSubscriberOperations($config);
    return new PlazosController($soapclient);
};

$container["ProductsController"] = function($c) {
    $config = $c->get('settings')['avet'];
    $soapclient = SoapFactory::getSubscriberOperations($config);
    return new ProductsController($soapclient);
};

$container["RolesController"] = function($c) {
    $config = $c->get('settings')['avet'];
    $soapclient = SoapFactory::getSubscriberOperations($config);
    return new RolesController($soapclient);
};

$container["SeatingAreaController"] = function($c) {
    $config = $c->get('settings')['avet'];
    $soapclient = SoapFactory::getVenueConfiguration($config);
    return new SeatingAreaController($soapclient);
};

$container["SeatStatusController"] = function($c) {
    $config = $c->get('settings')['avet'];
    $soapclient = SoapFactory::getSubscriberOperations($config);
    return new SeatStatusController($soapclient);
};

$container["PaymentController"] = function($c) {
    $config = $c->get('settings')['avet'];
    $email_config = $c->get('settings')['email'];
    $payment_config = $c->get('settings')['payment'];
    $s3_config = $c->get('settings')['s3'];
    $po_settings['soap'] = SoapFactory::getSubscriberOperations($config);
    $po_settings['redys'] = $c->redis;

    return new PaymentController($payment_config,$po_settings,$s3_config,$email_config,$config);
};

$container["ClientController"] = function($c) {
    $client = $c->get('settings')['client'];
    $redis = $c->get('settings')['redis'];
    return new ClientController($client,$redis);
};
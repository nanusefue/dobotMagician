<?php
/**
 * @SWG\Info(title="AVET API", version="0.1")
 */
use App\Controller\PartnerOpController as PartnerOpController;
use App\Utils\Error\ErrorHandler as ErrorHandler;

use Slim\Http\Request;
use Slim\Http\Response;

use \PHPMailer\PHPMailer\PHPMailer as PHPMailer;
use \PHPMailer\PHPMailer\Exception as PHPMailerException;

// OPTIONS =====================================================================
/**
 * Proporciona permisos CORS para peticiones Preflighted
 */
$app->options('/{routes:.+}', function ($request, $response, $args) {
    return $response;
});

$app->add(function ($req, $res, $next) {
    $response = $next($req, $res);
    return $response
            ->withHeader('Access-Control-Allow-Origin', '*')
            ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
            ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, PATCH');
});

// DELETE ======================================================================
/**
 *  @SWG\Delete(
 *      path="/partner/{b64_idOperation}",
 *      tags={"Partner management"},
 *      summary="Cancela un partnerOperation (CancelPartner)",
 *      @SWG\Parameter(
 *          name="b64_idOperation",
 *          description="Identificador de partnerOperation codificado en base 64",
 *          in="path",
 *          required=true,
 *          type="string"
 *      ),
 *      @SWG\Response(
 *          response=200,
 *          description="PartnerOperation cancelada",
 *          @SWG\Schema(
 *              type="array",
 *              @SWG\Items(ref="#/definitions/PartnerOperation")
 *          )
 *      )
 *  )
 */
$app->delete('/partner/{b64_idOperation}', function (Request $request, Response $response, array $args) {
    try {
        $idOperation = base64_decode($args["b64_idOperation"]);
        $result = $this->PartnerOpController->delete($idOperation);
        $code = $this->PartnerOpController->getCode();
        $response = $response->withJson($result, $code);
    } catch (\Thowable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

    return $response;
})->add( new HeadersMiddleware() );

// GET =========================================================================
$app->get('/doc', function (Request $request, Response $response, array $args) {

    $file = __DIR__ . '/../public/swagger.json';
    $fh = fopen($file, 'rb');
    $stream = new \Slim\Http\Stream($fh);
    return $response->withBody($stream);

})->add( new HeadersMiddleware() );

$app->get('/check', function (Request $request, Response $response, array $args) {
    return $response->withStatus(200);

})->add( new HeadersMiddleware() );

$app->get('/avet/subscriberoperation', function (Request $request, Response $response, array $args) {
    return $response->withJson($this->SubscriberOperation->__getTypes());
})->add( new HeadersMiddleware() );

$app->get('/avet/venueconfiguration', function (Request $request, Response $response, array $args) {
    return $response->withJson($this->VenueConfiguration->__getTypes());
})->add( new HeadersMiddleware() );

/**
 * @SWG\Get(
 *  path="/aforos/{idAforo}/areas/{idArea}/availability",
 *  tags={"Venue"},
 *  summary="Obtiene la disponibilidad de un area dado un aforo (GetDetailAvailability)",
 *  @SWG\Parameter(
 *      name="idAforo",
 *      description="Identificador único de aforo",
 *      in="path",
 *      required=true,
 *      type="integer"
 *  ),
 *  @SWG\Parameter(
 *      name="idArea",
 *      description="Identificador único de area",
 *      in="path",
 *      required=true,
 *      type="integer"
 *  ),
 *  @SWG\Response(
 *      response=200,
 *      description="Estado de asiento",
 *      @SWG\Schema(
 *          type="array",
 *          @SWG\Items(ref="#/definitions/SeatStatus")
 *      )
 *   )
 * )
 */
$app->get('/aforos/{idAforo}/areas/{idArea}/availability', function (Request $request, Response $response, array $args) {

    try {
        $idAforo = (int)$args["idAforo"];
        $idArea = (int)$args["idArea"];
        $result = $this->SeatStatusController->find($idAforo, $idArea);
        $code = $this->SeatStatusController->getCode();
        $response = $response->withJson($result, $code);
    } catch (\Thowable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

    return $response;

})->add( new HeadersMiddleware() );

/**
 * @SWG\Get(
 *  path="/aforos/{idAforo}/areas/{idArea}",
 *  tags={"Venue"},
 *  summary="Obtiene los asientos de un area dado un aforo (GetSeatingAreaByAforoAndArea-ticketing?)",
 *  @SWG\Parameter(
 *      name="idAforo",
 *      description="Identificador único de aforo",
 *      in="path",
 *      required=true,
 *      type="integer"
 *  ),
 *  @SWG\Parameter(
 *      name="idArea",
 *      description="Identificador único de area",
 *      in="path",
 *      required=true,
 *      type="integer"
 *  ),
 *  @SWG\Response(
 *      response=200,
 *      description="Datos que definen un asiento",
 *      @SWG\Schema(
 *          type="array",
 *          @SWG\Items(ref="#/definitions/SeatingArea")
 *      )
 *   )
 * )
 */
$app->get('/aforos/{idAforo}/areas/{idArea}', function (Request $request, Response $response, array $args) {

    try {
        $idAforo = (int)$args["idAforo"];
        $idArea = (int)$args["idArea"];
        $result = $this->SeatingAreaController->find($idAforo, $idArea);
        $code = $this->SeatingAreaController->getCode();
        $response = $response->withJson($result, $code);
    } catch (\Thowable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

    return $response;

})->add( new HeadersMiddleware() );

/**
 * @SWG\Get(
 *  path="/aforos/{idAforo}/areas",
 *  tags={"Venue"},
 *  summary="Obtiene las areas disponiblies de un aforos (GetAvailability)",
 *  @SWG\Parameter(
 *      name="idAforo",
 *      description="Identificador único de aforo",
 *      in="path",
 *      required=true,
 *      type="integer"
 *  ),
 *  @SWG\Response(
 *      response=200,
 *      description="Lista de areas disponibles para un aforo",
 *      @SWG\Schema(
 *          type="array",
 *          @SWG\Items(ref="#/definitions/AreaAvailability")
 *      )
 *   )
 * )
 */
$app->get('/aforos/{idAforo}/areas', function (Request $request, Response $response, array $args) {

    try {
        $idAforo = (int)$args["idAforo"];
        $result = $this->AreasController->find($idAforo);
        $code = $this->AreasController->getCode();
        $response = $response->withJson($result, $code);
    } catch (\Thowable $e) {

        $response = ErrorHandler::setErrorMessage($e, $response);
    }

    return $response;

})->add( new HeadersMiddleware() );

/**
 * @SWG\Get(
 *  path="/aforos/{idAforo}/products",
 *  tags={"Pricing"},
 *  summary="Obtiene los productos disponibles por zona, tipo de abono, plazo y periodicidad, para un aforo (GetProductsInfo)",
 *  @SWG\Parameter(
 *      name="idAforo",
 *      description="Identificador único de aforo",
 *      in="path",
 *      required=true,
 *      type="integer"
 *  ),
 *  @SWG\Response(
 *      response=200,
 *      description="Lista de productos disponibles por aforo",
 *      @SWG\Schema(
 *          type="array",
 *          @SWG\Items(ref="#/definitions/Product")
 *      )
 *   )
 * )
 */
$app->get('/aforos/{idAforo}/products', function (Request $request, Response $response, array $args) {

    try {
        $idAforo = (int)$args["idAforo"];
        $result = $this->ProductsController->find($idAforo);
        $code = $this->ProductsController->getCode();
        $response = $response->withJson($result, $code);
    } catch (\Thowable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

    return $response;

})->add( new HeadersMiddleware() );

/**
 * @SWG\Get(
 *  path="/aforos/{idAforo}/abonos",
 *  tags={"Pricing"},
 *  summary="Obtiene los tipos de abono disponibles para un aforo (GetRolInfo)",
 *  @SWG\Parameter(
 *      name="idAforo",
 *      description="Identificador único de aforo",
 *      in="path",
 *      required=true,
 *      type="integer"
 *  ),
 *  @SWG\Response(
 *      response=200,
 *      description="Lista de tipos de abono disponibles por aforo",
 *      @SWG\Schema(
 *          type="array",
 *          @SWG\Items(ref="#/definitions/RolPartnerInfo")
 *      )
 *   )
 * )
 */
$app->get('/aforos/{idAforo}/abonos', function (Request $request, Response $response, array $args) {

    try {
        $idAforo = (int)$args["idAforo"];
        $result = $this->RolesController->find($idAforo);
        $code = $this->RolesController->getCode();
        $response = $response->withJson($result, $code);
    } catch (\Thowable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

    return $response;

})->add( new HeadersMiddleware() );

/**
 * @SWG\Get(
 *  path="/aforos",
 *  tags={"Venue"},
 *  summary="Obtiene la lista de aforos (GetAforos-ticketing)",
 *  @SWG\Response(
 *      response=200,
 *      description="Lista de aforos",
 *      @SWG\Schema(
 *          type="array",
 *          @SWG\Items(ref="#/definitions/Aforo")
 *      )
 *   )
 * )
 */
$app->get('/aforos', function (Request $request, Response $response, array $args) {

    try {
        $result = $this->AforosController->find();
        $code = $this->AforosController->getCode();
        $response = $response->withJson($result, $code);
    } catch (\Thowable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

    return $response;

})->add( new HeadersMiddleware() );


/**
 * @SWG\Get(
 *  path="/motivo_emision",
 *  tags={"Pricing"},
 *  summary="Devuelve la lista de los Motivos de Emisión disponibles. (GetMotivoEmision)",
 *  @SWG\Response(
 *      response=200,
 *      description="Lista de motivos de emisión",
 *      @SWG\Schema(
 *          type="array",
 *          @SWG\Items(ref="#/definitions/Aforo")
 *      )
 *   )
 * )
 */
$app->get('/motivo_emision', function (Request $request, Response $response, array $args) {

    try {
        $result = $this->MotivoEmisionController->find();
        $code = $this->MotivoEmisionController->getCode();
        $response = $response->withJson($result, $code);
    } catch (\Thowable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

    return $response;

})->add( new HeadersMiddleware() );


/**
 *  @SWG\Get(
 *      path="/partner/logged",
 *      tags={"Partner management"},
 *      summary="Obtiene los datos del partner logueado",
 *      @SWG\Response(
 *          response=200,
 *          description="Datos de partner y los tokens de autenticacion",
 *          @SWG\Schema(
 *              type="object",
 *              @SWG\Property(property="partnerOperation", ref="#/definitions/PartnerOperation"),
 *              @SWG\Property(property="ttl", type="string")
 *          )
 *      ),
 *      @SWG\Response(
 *          response=400,
 *          description="Mensaje de error",
 *          @SWG\Schema (
 *              @SWG\Property(property="message", type="string"),
 *          )
 *      )
 *  )
 */
$app->get('/partner/logged', function (Request $request, Response $response, array $args) {

    try {
        $return = [
            "PartnerOperation" => json_decode($request->getAttribute("partnerOp")),
            "ttl" => $request->getAttribute("ttl")
        ];
        $response = $response->withJson($return, 200);
    } catch (\Throwable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }
    return $response;

})->add( new HeadersMiddleware() )
->add( new AuthenticationMiddleware($app->getContainer()->redis) );

/**
 * @SWG\Get(
 *  path="/paymentmodes",
 *  tags={"Pricing"},
 *  summary="Devuelve la lista de modos de cobro disponibles en el sistema. (GetPaymentMode)",
 *  @SWG\Response(
 *      response=200,
 *      description="Lista de modos de cobro",
 *      @SWG\Schema(
 *          type="array",
 *          @SWG\Items(ref="#/definitions/PaymentMode")
 *      )
 *   )
 * )
 */
$app->get('/paymentmodes', function (Request $request, Response $response, array $args) {

    try {
        $result = $this->PaymentModesController->find();
        $code = $this->PaymentModesController->getCode();
        $response = $response->withJson($result, $code);
    } catch (\Thowable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

    return $response;

})->add( new HeadersMiddleware() );

/**
 * @SWG\Get(
 *  path="/plazos",
 *  tags={"Pricing"},
 *  summary="Devuelve la relación de periodicidades/plazos configurados en el sistema. (getPlazosInfo)",
 *  @SWG\Response(
 *      response=200,
 *      description="Lista de periodicidades/plazos",
 *      @SWG\Schema(
 *          type="array",
 *          @SWG\Items(ref="#/definitions/PlazoInfo")
 *      )
 *   )
 * )
 */
$app->get('/plazos', function (Request $request, Response $response, array $args) {

    try {
        $result = $this->PlazosController->find();
        $code = $this->PlazosController->getCode();
        $response = $response->withJson($result, $code);
    } catch (\Thowable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

    return $response;

})->add( new HeadersMiddleware() );

// PATCH =======================================================================
/**
 *  @SWG\Patch(
 *      path="/partner/{b64_idOperation}/seat",
 *      tags={"Partner management"},
 *      summary="Modifica el asiento de un partner (ModifySeat)",
 *      @SWG\Parameter(
 *          name="partnerOperation",
 *          in="body",
 *          description="Datos del nuevo asiento disponible. La cuota de socio debería cambiarse previamente si el nuevo asiento así lo requiere mediante la operation PUT /partner/{b64_idOperation}.",
 *          required=true,
 *          @SWG\Schema(
 *              type="array",
 *              @SWG\Items(ref="#/definitions/Titulo")
 *          )
 *      ),
 *      @SWG\Response(
 *          response=200,
 *          description="Objeto partnerOperation",
 *          @SWG\Schema(
 *              type="object",
 *              @SWG\Property(property="partnerOp", ref="#/definitions/PartnerOperation")
 *          )
 *      ),
 *      @SWG\Response(
 *          response=400,
 *          description="Mensaje de error",
 *          @SWG\Schema (
 *              @SWG\Property(property="message", type="string"),
 *          )
 *      )
 *  )
 */
$app->patch('/partner/{b64_idOperation}/seat', function (Request $request, Response $response, array $args) {
    try {
        $idOperation = base64_decode($args["b64_idOperation"]);
        $data = $request->getParsedBody();
        $result = $this->PartnerOpController->editSeat($idOperation, $data);
        $code = $this->PartnerOpController->getCode();
        $response = $response->withJson($result, $code);

    } catch (\Throwable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }
    return $response;

})->add( new HeadersMiddleware() );

// POST ========================================================================

/**
 *  @SWG\Post(
 *      path="/partner/{b64_idOperation}/confirm/{idPaymentMode}",
 *      tags={"Partner management"},
 *      summary="Confirma una transacción partnerOperation",
 *      @SWG\Parameter(
 *          name="b64_idOperation",
 *          description="Identificador de partnerOperation codificado en base 64 (ConfirmPartner)",
 *          in="path",
 *          required=true,
 *          type="string"
 *      ),
 *      @SWG\Parameter(
 *          name="idPaymentMode",
 *          description="Identificador de pago",
 *          in="path",
 *          required=true,
 *          type="string"
 *      ),
 *      @SWG\Response(
 *          response=200,
 *          description="PartnerOperation cancelada",
 *          @SWG\Schema(
 *              type="array",
 *              @SWG\Items(ref="#/definitions/PartnerOperation")
 *          )
 *      ),
 *      @SWG\Response(
 *          response=400,
 *          description="Mensaje de error",
 *          @SWG\Schema (
 *              @SWG\Property(property="message", type="string"),
 *          )
 *      )
 *  )
 */
$app->post('/partner/{b64_idOperation}/confirm/{idPaymentMode}/{idMotivoEmision}', function (Request $request, Response $response, array $args) {
    try {
        $idOperation = base64_decode($args["b64_idOperation"]);
        $idPaymentMode = (int)$args["idPaymentMode"];
        $idMotivoEmision = (int)$args["idMotivoEmision"];
        $result = $this->PartnerOpController->confirm($idOperation, $idPaymentMode, $idMotivoEmision);
        $code = $this->PartnerOpController->getCode();
        $response = $response->withJson($result, $code);
    } catch (\Throwable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }
    return $response;

})->add( new HeadersMiddleware() );

/**
 *  @SWG\Post(
 *      path="/partner/{b64_idOperation}/preconfirm",
 *      tags={"Partner management"},
 *      summary="Preconfirma un partnerOperation",
 *      @SWG\Parameter(
 *          name="b64_idOperation",
 *          description="Identificador de partnerOperation codificado en base 64",
 *          in="path",
 *          required=true,
 *          type="string"
 *      ),
 *      @SWG\Response(
 *          response=200,
 *          description="PartnerOperation preconfirmada",
 *          @SWG\Schema(
 *              type="array",cc67e11e0442c78925d17bb5cd2926fb
 *              @SWG\Items(ref="#/definitions/PartnerOperation")
 *          )
 *      )
 *  )
 */
$app->post('/partner/{b64_idOperation}/preconfirm', function (Request $request, Response $response, array $args) {

    try {
        $idOperation = base64_decode($args["b64_idOperation"]);
        $result = $this->PartnerOpController->preconfirm($idOperation);
        $code = $this->PartnerOpController->getCode();
        $response = $response->withJson($result, $code);
    } catch (\Throwable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }
    return $response;

})->add( new HeadersMiddleware() );

/**
 *  @SWG\Post(
 *      path="/login",
 *      tags={"Partner management"},
 *      summary="Login (GetPartner)",
 *      @SWG\Parameter(
 *          name="login",
 *          in="body",
 *          description="Identificacion de usuario",
 *          required=true,
 *          @SWG\Schema (
 *              required={"idAforo","pin"},
 *              @SWG\Property(property="idAforo", type="integer"),
 *              @SWG\Property(property="idPersona", type="string"),
 *              @SWG\Property(property="numSocio", type="string"),
 *              @SWG\Property(property="pin", type="string")
 *          )
 *      ),
 *      @SWG\Response(
 *          response=200,
 *          description="Datos de partner y los tokens de autenticacion",
 *          @SWG\Schema(
 *              type="object",
 *              @SWG\Property(property="partnerOp", ref="#/definitions/PartnerOperation"),
 *              @SWG\Property(property="token", type="string"),
 *              @SWG\Property(property="refreshToken", type="string"),
 *              @SWG\Property(property="ttl", type="string")
 *          )
 *      ),
 *      @SWG\Response(
 *          response=401,
 *          description="Mensaje de error",
 *          @SWG\Schema (
 *              @SWG\Property(property="message", type="string"),
 *          )
 *      )
 *  )
 */
$app->post('/login', function (Request $request, Response $response, array $args) {

    try {
        $data = $request->getParsedBody();
        $data = $this->ClientController->login($data);
        $result = $this->PartnerOpController->login($data);
        $code = $this->PartnerOpController->getCode();
        $response = $response->withJson($result, $code);

    } catch (\Throwable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

 	// Obtener respuesta
 	return $response;

 })->add( new HeadersMiddleware() );

/**
 *  @SWG\Post(
 *      path="/refreshToken",
 *      tags={"Partner management"},
 *      summary="Obtiene nuevos tokens de credenciales",
 *      @SWG\Parameter(
 *          name="login",
 *          in="body",
 *          description="Refresh token",
 *          required=true,
 *          @SWG\Schema (
 *              required={"refreshToken"},
 *              @SWG\Property(
 *                  property="refreshToken",
 *                  type="string"
 *              )
 *          )
 *      ),
 *      @SWG\Response(
 *          response=200,
 *          description="Datos de partner y los tokens de autenticacion",
 *          @SWG\Schema(
 *              type="object",
 *              @SWG\Property(property="partnerOp", ref="#/definitions/PartnerOperation"),
 *              @SWG\Property(property="token", type="string"),
 *              @SWG\Property(property="refreshToken", type="string"),
 *              @SWG\Property(property="ttl", type="string")
 *          )
 *      ),
 *      @SWG\Response(
 *          response=401,
 *          description="Mensaje de error",
 *          @SWG\Schema (
 *              @SWG\Property(property="message", type="string"),
 *          )
 *      )
 *  )
 */
$app->post('/refreshToken', function (Request $request, Response $response, array $args) {

     try {
         $data = $request->getParsedBody();
         $result = $this->PartnerOpController->refreshCredentials($data["refreshToken"]);
         $code = $this->PartnerOpController->getCode();
         $response = $response->withJson($result, $code);

     } catch (\Throwable $e) {
         $response = ErrorHandler::setErrorMessage($e, $response);
     }

  	// Obtener respuesta
  	return $response;

  })->add( new HeadersMiddleware() );

/**
 *  @SWG\Post(
 *      path="/partner",
 *      tags={"Partner management"},
 *      summary="Crea un nuevo partnerOperation (CreatePartner)",
 *      @SWG\Parameter(
 *          name="partnerOperation",
 *          in="body",
 *          description="Datos personales de usuario, solo es obligatorio completar la propiedad personaInfo",
 *          required=true,
 *          @SWG\Schema(
 *              type="array",
 *              @SWG\Items(ref="#/definitions/Partner")
 *          )
 *      ),
 *      @SWG\Response(
 *          response=200,
 *          description="Objeto partnerOperation",
 *          @SWG\Schema(
 *              type="object",
 *              @SWG\Property(property="partnerOp", ref="#/definitions/PartnerOperation")
 *          )
 *      ),
 *      @SWG\Response(
 *          response=400,
 *          description="Mensaje de error",
 *          @SWG\Schema (
 *              @SWG\Property(property="message", type="string"),
 *          )
 *      )
 *  )
 */
$app->post('/partner', function (Request $request, Response $response, array $args) {

    try {
        $data = $request->getParsedBody();
        $result = $this->PartnerOpController->add($data);
        $code = $this->PartnerOpController->getCode();
        $response = $response->withJson($result, $code);

    } catch (\Throwable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

	// Obtener respuesta
	return $response;

})->add( new HeadersMiddleware() );

/*
 * @SWG\Post(
 *  path="/forgot",
 *  tags={"Partner management"},
 *  summary="Recupera los datos de usuario",
 *  @SWG\Parameter(
 *      name="forgot",
 *      in="body",
 *      description="Dirección de correo electrónico",
 *      required=true,
 *      @SWG\Schema (
 *          required={"email"},
 *          @SWG\Property(
 *              property="email",
 *              type="string"
 *          )
 *      )
 *  ),
 *  @SWG\Response(
 *      response=200,
 *      description="",
 *      @SWG\Schema(ref="#/definitions/Partner")
 *   )
 * )
 */
/*$app->post('/forgot', function (Request $request, Response $response, array $args) {

    try {
        $data = $request->getParsedBody();
        $result = $this->PartnerOpController->forgot($data["email"]);
        $code = $this->PartnerOpController->getCode();
        $response = $response->withJson($result, $code);
    } catch (\Throwable $e) {
        ErrorHandler::setErrorMessage($e, $response);
    }

  	// Obtener respuesta
  	return $response;

})->add( new HeadersMiddleware() );*/

// PUT =========================================================================
/**
 *  @SWG\Put(
 *      path="/partner/{b64_idOperation}",
 *      tags={"Partner management"},
 *      summary="Modifica los datos de un partnerOperation (ModifyPartner)",
 *      @SWG\Parameter(
 *          name="partnerOperation",
 *          in="body",
 *          description="Datos personales de usuario, el objeto debería completarse con datos PartnerInfo y Titulo en caso de alta nueva.",
 *          required=true,
 *          @SWG\Schema(
 *              type="array",
 *              @SWG\Items(ref="#/definitions/Partner")
 *          )
 *      ),
 *      @SWG\Response(
 *          response=200,
 *          description="Objeto partnerOperation",
 *          @SWG\Schema(
 *              type="object",
 *              @SWG\Property(property="partnerOp", ref="#/definitions/PartnerOperation")
 *          )
 *      ),
 *      @SWG\Response(
 *          response=400,
 *          description="Mensaje de error",
 *          @SWG\Schema (
 *              @SWG\Property(property="message", type="string"),
 *          )
 *      )
 *  )
 */
$app->put('/partner/{b64_idOperation}', function (Request $request, Response $response, array $args) {

    try {
        $data = $request->getParsedBody();
        $result = $this->PartnerOpController->edit($data);
        $code = $this->PartnerOpController->getCode();
        $response = $response->withJson($result, $code);

    } catch (\Throwable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

 	// Obtener respuesta
    return $response;

})->add( new HeadersMiddleware() );



$app->post('/payment/neworderconfirm/{order_type}', function (Request $request, Response $response, array $args) {
    try {
        $data = $request->getParsedBody();
        $files = $request->getUploadedFiles();
        $order_type = $args["order_type"];
        $result = $this->PaymentController->neworderconfirm($data,$files,$order_type);
        $code = $this->PaymentController->getCode();
        $response = $response->withJson($result, $code);

    } catch (\Throwable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

    return $response;

})->add( new HeadersMiddleware() );




$app->post('/payment/neworder/{order_type}', function (Request $request, Response $response, array $args) {
    try {
        $data = $request->getParsedBody();
        $order_type = $args["order_type"];
        $result = $this->PaymentController->neworder($data,$order_type);
        $code = $this->PaymentController->getCode();
        $response = $response->withJson($result, $code);

    } catch (\Throwable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

    return $response;

})->add( new HeadersMiddleware() );

$app->post('/payment/tarifas', function (Request $request, Response $response, array $args) {
    try {
        $data = $request->getParsedBody();
        $result = $this->PaymentController->getTarifas($data);
        $code = $this->PaymentController->getCode();
        $response = $response->withJson($result, $code);

    } catch (\Throwable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

    return $response;

})->add( new HeadersMiddleware() );

$app->post('/payment/response/{channel}', function (Request $request, Response $response, array $args) {
    try {
        $data = $request->getParsedBody();
        $channel = $args["channel"];
        $result = $this->PaymentController->responseChannel($channel,$data);
        $code = $this->PaymentController->getCode();
        $response = $response->withJson($result, $code);

    } catch (\Throwable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

    return $response;

})->add( new HeadersMiddleware() );

$app->get('/payment/sendemail', function (Request $request, Response $response, array $args) {
    try {

        $this->PaymentController->sendemail([]);
        $code = $this->PaymentController->getCode();
        $response = $response->withJson($result, $code);

    } catch (\Throwable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

    return $response;

})->add( new HeadersMiddleware() );

$app->get('/payment/sendemailinc/{inc}', function (Request $request, Response $response, array $args) {
    try {
        $inc = $args["inc"];
        $this->PaymentController->sendemailinc([],$inc);
        $code = $this->PaymentController->getCode();
        $response = $response->withJson($result, $code);

    } catch (\Throwable $e) {
        $response = ErrorHandler::setErrorMessage($e, $response);
    }

    return $response;

})->add( new HeadersMiddleware() );
<?php

namespace App\Model\Entities;

use App\Utils\Error\ErrorException as ErrorException;
use App\Model\Entities\Entity as Entity;
use App\Model\Entities\Partner as Partner;
use \Respect\Validation\Validator as Validator;

/**
 * @SWG\Definition(
 *      definition="PartnerOperation",
 *      type="object"
 * )
 */
class PartnerOperation extends Entity
{
    // PROTECTED VARS ==========================================================
    /**
     * @SWG\Property(property="IdOperation", description="Identificador de operacion")
     * @var string $idOperation
     */
    protected $idOperation;

    /**
     * @SWG\Property(property="FxUpdate", description="Fecha de actualizacion")
     * @var string $fxUpdate
     */
    protected $fxUpdate;

    /**
     * @SWG\Property(property="Partner", description="Datos del partner")
     * @var Partner $Partner
     */
    protected $partner;

    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Validate data
     * @param array $data Data to be validated
     * @return bool
     */
    public static function validate(array $data, $validator = null) : ErrorException
    {
        // AVET exige la key Partner en mayuscular para realizar un edit
        if (isset($data["Partner"])) {
            return Partner::validate($data["Partner"]);
        }

        // AVET exige la key partner en minuscula para realizar un add
        return Partner::validate($data["partner"]);
    }

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Get $fxUpdate
     *
     * @return string Fecha de actualizacion
     */
    public function getFxUpdate()
    {
        return $this->fxUpdate;
    }

    /**
     * Get $idOperation
     *
     * @return string Identificador de operacion
     */
    public function getIdOperation()
    {
        return $this->idOperation;
    }

    /**
     * Get $partner
     *
     * @return Partner Datos del partner
     */
    public function getPartner()
    {
        return $this->partner;
    }

    /**
     * Set $fxUpdate
     *
     * @param string $value Fecha de actualizacion
     *
     * @return void
     */
    public function setFxUpdate(string $value)
    {
        $this->fxUpdate = $value;
    }

    /**
     * Set $idOperation
     *
     * @param string $value Identificador de operacion
     *
     * @return void
     */
    public function setIdOperation(string $value)
    {
        $this->idOperation = $value;
    }

    /**
     * Set $partner
     *
     * @param Partner $value Datos del partner
     *
     * @return void
     */
    public function setPartner(Partner $value)
    {
        $this->partner = $value;
    }

    /**
     * Devolver datos de la entidad en formato array
     * @return array Entity data to array
     */
    public function toArray()
    {
        $partner = $this->getPartner();
        return [
            "FxUpdate" => $this->getFxUpdate(),
            "IdOperation" => $this->getIdOperation(),
            "Partner" => $partner->toArray()
        ];
    }
}

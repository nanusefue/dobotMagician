<?php

namespace App\Model\Entities;

use App\Utils\Error\ErrorException as ErrorException;
use App\Model\Entities\Entity as Entity;
use App\Model\Entities\Pago as Pago;
use \Respect\Validation\Validator as Validator;

/**
 * @SWG\Definition(
 *      definition="PartnerInfo",
 *      type="object"
 * )
 */
class PartnerInfo extends Entity
{
    // PUBLIC VARS =============================================================
    /**
     * @SWG\Property(property="Baja", description="Flag que indica si el usuario esta dado de baja")
     * @var boolean $baja
     */
    protected $baja;

    /**
     * @SWG\Property(property="CuotaSocio", description="Importe de la cuota de socio")
     * @var float $cuotaSocio
     */
    protected $cuotaSocio;

    /**
     * @SWG\Property(property="FechaAlta", description="Fecha de alta del usuario")
     * @var \DateTime $fechaAlta
     */
    protected $fechaAlta;

    /**
     * @SWG\Property(property="IdEstadoPagoSocio", description="Identificador del estado del pago de un socio")
     * @var int $idEstadoPagoSocio
     */
    protected $idEstadoPagoSocio;

    /**
     * @SWG\Property(property="IdPeriodicidadSocio", description="Identificador de periodicidad del pago de un socio")
     * @var int $idPeriodicidadSocio
     */
    protected $idPeriodicidadSocio;

    /**
     * @SWG\Property(
     *      property="IdTipoSocio",
     *      description="Identificador de tipo de socio (En teoria se obtiene de la lista SuscriberOperation->GetRolInfo)"
     * )
     * @var int $idTipoSocio
     */
    protected $idTipoSocio;

    /**
     * @SWG\Property(property="IdTitularCuenta ", description="Identificador del titular de la cuenta")
     * @var string $idTitularCuenta
     */
    protected $idTitularCuenta;

    /**
     * @SWG\Property(property="Numero", description="Numero de socio")
     * @var int $numero
     */
    protected $numero;

    /**
     * @SWG\Property(property="NumeroAnterior", description="Numero de socio anterior")
     * @var int $numeroAnterior
     */
    protected $numeroAnterior;

    /**
     * @SWG\Property(
     *      property="Pagos",
     *      description="Array de instancias de pagos",
     *      type="array",
     *      @SWG\Items(ref="#/definitions/Pago")
     * )
     * @var array $pagos
     */
    protected $pagos = [];

    /**
     * @SWG\Property(property="Referencia", description="Referencia")
     * @var string $referencia
     */
    protected $referencia;

    /**
     * @SWG\Property(property="ReferenciaAnterior", description="Referencia anterior")
     * @var string $referenciaAnterior
     */
    protected $referenciaAnterior;

    /**
     * @SWG\Property(property="Sector", description="Nombre de sector")
     * @var string $sector
     */
    protected $sector;

    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Validate data
     * @param array $data Data to be validated
     * @return bool
     */
    public static function validate(array $data, $validator = null) : ErrorException
    {
        /*
        $toReturn = [
            "Baja" => $this->isBaja(),
            "CuotaSocio" => $this->getCuotaSocio(),
            "FechaAlta" => $fechaAlta,
            "IdEstadoPagoSocio" => $this->getIdEstadoPagoSocio(),
            "IdPeriodicidadSocio" => $this->getIdPeriodicidadSocio(),
            "IdTipoSocio" => $this->getIdTipoSocio(),
            "idTitularCuenta" => $this->getIdTitularCuenta(),
            "Numero" => $this->getNumero(),
            "NumeroAnterior" => $this->getNumeroAnterior(),
            "Referencia" => $this->getReferencia(),
            "ReferenciaAnterior" => $this->getReferenciaAnterior(),
            "Sector" => $this->getSector()
        ];
        */

        $validator = Validator::attribute('FechaAlta', Validator::date('Y-m-d\TH:i:s'));
        return parent::validate($data, $validator);
    }

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Adds pago object to array pagos attribute
     * @param Pago $pago
     * @return void
     */
    public function addPago(Pago $pago)
    {
        array_push($this->pagos, $pago);
    }

    /**
     * Get cuotaSocio
     * @return float Importe de la cuota de socio
     */
    public function getCuotaSocio()
    {
        return $this->cuotaSocio;
    }

    /**
     * Get fechaAlta
     * @return \DateTime Fecha de alta del usuario
     */
    public function getFechaAlta()
    {
        return $this->fechaAlta;
    }

    /**
     * Get idEstadoPagoSocio
     * @return int Identificador del estado del pago de un socio
     */
    public function getIdEstadoPagoSocio()
    {
        return $this->idEstadoPagoSocio;
    }

    /**
     * Get idPeriodicidadSocio
     * @return int Identificador de periodicidad ¿¿del pago?? de un socio
     */
    public function getIdPeriodicidadSocio()
    {
        return $this->idPeriodicidadSocio;
    }

    /**
     * Get idTipoSocio
     * @return int Identificador de tipo de socio
     */
    public function getIdTipoSocio()
    {
        return $this->idTipoSocio;
    }

    /**
     * Get idTitularCuenta
     * @return string Identificador del titular de la cuenta
     */
    public function getIdTitularCuenta()
    {
        return $this->idTitularCuenta;
    }

    /**
     * Get numero
     * @return string Numero de socio
     */
    public function getNumero()
    {
        return $this->numero;
    }

    /**
     * Get numeroAnterior
     * @return string Numero de socio anterior
     */
    public function getNumeroAnterior()
    {
        return $this->numeroAnterior;
    }

    /**
     * Get pagos
     * @return array Array de instancias de pagos
     */
    public function getPagos()
    {
        return $this->pagos;
    }

    /**
     * Get referencia
     * @return string Referencia
     */
    public function getReferencia()
    {
        return $this->referencia;
    }

    /**
     * Get referenciaAnterior
     * @return string Referencia anterior
     */
    public function getReferenciaAnterior()
    {
        return $this->referenciaAnterior;
    }

    /**
     * Get sector
     * @return string Sector
     */
    public function getSector()
    {
        return $this->sector;
    }

    /**
     * Get baja
     * @return boolean Flag que indica si el usuario esta dado de baja
     */
    public function isBaja()
    {
        return $this->baja;
    }

    /**
     * Set baja
     * @param boolean $value Flag que indica si el usuario esta dado de baja
     * @return void
     */
    public function setBaja(string $value)
    {
        $this->baja = $value;
    }

    /**
     * Set cuotaSocio
     * @param float $value Importe de la cuota de socio
     * @return void
     */
    public function setCuotaSocio(float $value)
    {
        $this->cuotaSocio = $value;
    }

    /**
     * Set fechaAlta
     * @param \DateTime $value Fecha de alta del usuario
     * @return void
     */
    public function setFechaAlta(\DateTime $value)
    {
        $this->fechaAlta = $value;
    }

    /**
     * Set idEstadoPagoSocio
     * @param int $value Identificador del estado del pago de un socio
     * @return void
     */
    public function setIdEstadoPagoSocio(int $value)
    {
        $this->idEstadoPagoSocio = $value;
    }

    /**
     * Set idPeriodicidadSocio
     * @param int $value Identificador de periodicidad ¿¿del pago?? de un socio
     * @return void
     */
    public function setIdPeriodicidadSocio(int $value)
    {
        $this->idPeriodicidadSocio = $value;
    }

    /**
     * Set idTipoSocio
     * @param int $value Identificador de tipo de socio
     * @return void
     */
    public function setIdTipoSocio(int $value)
    {
        $this->idTipoSocio = $value;
    }

    /**
     * Set idTitularCuenta
     * @param string $value Identificador del titular de la cuenta
     * @return void
     */
    public function setIdTitularCuenta(string $value)
    {
        $this->idTitularCuenta = $value;
    }

    /**
     * Set numero
     * @param string $value Numero de socio
     * @return void
     */
    public function setNumero(string $value)
    {
        $this->numero = $value;
    }

    /**
     * Set numeroAnterior
     * @param string $value Numero de socio anterior
     * @return void
     */
    public function setNumeroAnterior(string $value)
    {
        $this->numeroAnterior = $value;
    }

    /**
     * Set pagos
     * @param array $value Array de instancias de pagos
     * @return void
     */
    public function setPagos(array $value)
    {
        $this->pagos = $value;
    }

    /**
     * Set referencia
     * @param string $value Referencia
     * @return void
     */
    public function setReferencia(string $value)
    {
        $this->referencia = $value;
    }

    /**
     * Set referenciaAnterior
     * @param string $value Referencia anterior
     * @return void
     */
    public function setReferenciaAnterior(string $value)
    {
        $this->referenciaAnterior = $value;
    }

    /**
     * Set sector
     * @param string $value Sector
     * @return void
     */
    public function setSector(string $value)
    {
        $this->sector = $value;
    }

    /**
     * Devolver datos de la entidad en formato array
     * @return array Entity data to array
     */
    public function toArray()
    {
        // FechaAlta
        $fechaAlta = $this->getFechaAlta();
        $fechaAlta = $fechaAlta->format("Y-m-d\TH:i:s");

        // Iniciar salida
        $toReturn = [
            "Baja" => $this->isBaja(),
            "CuotaSocio" => $this->getCuotaSocio(),
            "FechaAlta" => $fechaAlta,
            "IdEstadoPagoSocio" => $this->getIdEstadoPagoSocio(),
            "IdPeriodicidadSocio" => $this->getIdPeriodicidadSocio(),
            "IdTipoSocio" => $this->getIdTipoSocio(),
            "idTitularCuenta" => $this->getIdTitularCuenta(),
            "Numero" => $this->getNumero(),
            "NumeroAnterior" => $this->getNumeroAnterior(),
            "Referencia" => $this->getReferencia(),
            "ReferenciaAnterior" => $this->getReferenciaAnterior(),
            "Sector" => $this->getSector()
        ];

        foreach ($toReturn as $key => $value) {
            if (!isset($value)) {
                $toReturn[$key] = null;
            }
        }

        // Agregar pagos
        $pagos = [];
        $pagosArray = $this->getPagos();
        if (isset($pagosArray) ) {
            foreach ($pagosArray as $pago) {
                $pagos[] = $pago->toArray();
            }
        }

        if (empty($pagos)) {
            $pagos[] = ["Pago" => null];
        }
        $toReturn["Pagos"] = $pagos;

        // Devolver salida
        return $toReturn;
    }
}

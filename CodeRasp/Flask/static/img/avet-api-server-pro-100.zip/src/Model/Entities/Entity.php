<?php

namespace App\Model\Entities;

use \Respect\Validation\Validator as Validator;
use App\Utils\Error\ErrorException as ErrorException;

abstract class Entity
{
    // PROTECTED VARS ==========================================================
    /**
     * Error exception
     * @var ErrorException $errorException
     */
    public $errorException;

    /**
     * Entity validator
     * @var \Respect\Validation\Validator $validator
     */
    protected $validator;

    // PROTECTED FUNCTIONS =====================================================
    /**
     * Devolver datos de la entidad en formato array
     * @return array Entity data to array
     */
    abstract protected function toArray();

    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Check data with a validator initialized in the child class
     * @param array $data
     * @param Validator $validator
     * @return Exception|true Validator exception if is there any problem
     */
    public static function validate(array $data, $validator = null) : ErrorException
    {
        $errorException = new ErrorException();
        if (isset($validator)) {
            try {
                $validator->assert((object)$data); // true
            } catch (\Throwable $e) {
                $errorException->exception = $e;
            }
        }
        return $errorException;
    }

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Get $error
     * @return SoapFault\null
     */
    public function getError()
    {
        return $this->errorException;
    }

    /**
     * Get $error
     * @return Exception\null
     */
    public function getErrorException()
    {
        return $this->errorException;
    }

    /**
     * Devuelve si existe un error comprobando si el objeto $this->error es un
     * SoapFault
     * @return boolean True si existe el SoapFault
     */
    public function isError()
    {
        if (get_class($this->errorException) == "App\Utils\Error\ErrorException") {
            return true;
        }
        return false;
    }

    /**
     * Set error
     * @param int $error
     * @return void
     */
    public function setError(ErrorException $error)
    {
        $this->errorException = $error;
    }

    /**
     * Set variable if value is set
     * @param string $name Attribute name
     * @param anything $value Value
     * @return void
     */
    public function setVariable(string $name, $value)
    {
        if (isset($value)) {
            $funcName = "set" . $name;
            if (method_exists($this, $funcName)) {
                $this->$funcName($value);
            }
        }
    }
}

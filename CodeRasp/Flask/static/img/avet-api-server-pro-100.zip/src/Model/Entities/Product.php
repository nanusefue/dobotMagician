<?php

namespace App\Model\Entities;

use App\Model\Entities\Entity as Entity;

/**
 * @SWG\Definition(
 *      definition="Product",
 *      type="object"
 * )
 */
class Product extends Entity
{
    // PROTECTED VARS ==============================================================
    /**
     * @SWG\Property(property="CuotaPlazo",description="Valor de la cuota del plazo")
     * @var float $cuotaPlazo
     */
    protected $cuotaPlazo;

    /**
     * @SWG\Property(property="IdAforo",description="Identificador de aforo")
     * @var int $idAforo
     */
    protected $idAforo;

    /**
     * @SWG\Property(property="IdPeriodicidad",description="Identificador de periodicidad")
     * @var int $idPeriodicidad
     */
    protected $idPeriodicidad;

    /**
     * @SWG\Property(property="IdPlazo",description="Identificador de plazos")
     * @var int $idPlazo
     */
    protected $idPlazo;

    /**
     * @SWG\Property(property="IdTipoAbono",description="Identificador de tipo de abono")
     * @var int $idTipoAbono
     */
    protected $idTipoAbono;

    /**
     * @SWG\Property(property="IdZona",description="Identificador de zona")
     * @var int $idZona
     */
    protected $idZona;

    // PUBLIC FUNCTIONS ============================================================
    /**
     * Get $cuotaPlazo
     * @return float Valor de la cuota del plazo
     */
    public function getCuotaPlazo()
    {
        return $this->cuotaPlazo;
    }

    /**
     * Get $idAforo
     * @return int Identificador de aforo
     */
    public function getIdAforo()
    {
        return $this->idAforo;
    }

    /**
     * Get $idPeriodicidad
     * @return int Identificador de periodicidad
     */
    public function getIdPeriodicidad()
    {
        return $this->idPeriodicidad;
    }

    /**
     * Get idPlazo
     * @return int Identificador de plazos
     */
    public function getIdPlazo()
    {
        return $this->idPlazo;
    }

    /**
     * Get $idTipoAbono
     * @return int Identificador de tipo de abono
     */
    public function getIdTipoAbono()
    {
        return $this->idTipoAbono;
    }

    /**
     * Get $idZona
     * @return int Identificador de zona
     */
    public function getIdZona()
    {
        return $this->idZona;
    }

    /**
     * Set $cuotaPlazo
     * @param float $value Valor de la cuota del plazo
     * @return void
     */
    public function setCuotaPlazo(float $value)
    {
        $this->cuotaPlazo = $value;
    }

    /**
     * Set $idAforo
     * @param int $value Identificador de aforo
     * @return void
     */
    public function setIdAforo(int $value)
    {
        $this->idAforo = $value;
    }

    /**
     * Set $idPeriodicidad
     * @param int $value Identificador de periodicidad
     * @return void
     */
    public function setIdPeriodicidad(int $value)
    {
        $this->idPeriodicidad = $value;
    }

    /**
     * Set idPlazo
     * @param int $value Identificador de plazos
     * @return void
     */
    public function setIdPlazo(int $value)
    {
        $this->idPlazo = $value;
    }

    /**
     * Set $idTipoAbono
     * @param int $value Identificador de tipo de abono
     * @return void
     */
    public function setIdTipoAbono(int $value)
    {
        $this->idTipoAbono = $value;
    }

    /**
     * Set $idZona
     * @param int $value Identificador de zona
     * @return void
     */
    public function setIdZona(int $value)
    {
        $this->idZona = $value;
    }

    /**
     * Devolver datos de la entidad en formato array
     * @return array Entity data to array
     */
    public function toArray()
    {
        return [
            "CuotaPlazo" => $this->getCuotaPlazo(),
            "IdAforo" => $this->getIdAforo(),
            "IdPeriodicidad" => $this->getIdPeriodicidad(),
            "IdPlazo" => $this->getIdPlazo(),
            "IdTipoAbono" => $this->getIdTipoAbono(),
            "IdZona" => $this->getIdZona()
        ];
    }
}

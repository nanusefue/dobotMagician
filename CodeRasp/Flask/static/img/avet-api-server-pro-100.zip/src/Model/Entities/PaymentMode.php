<?php

namespace App\Model\Entities;

use App\Model\Entities\Entity as Entity;

/**
 * @SWG\Definition(
 *      definition="PaymentMode",
 *      type="object"
 * )
 */
class PaymentMode extends Entity
{
    // PUBLIC VARS =================================================================
    /**
     * @SWG\Property(property="IdModoCobro", description="Identificador de modo de cobro")
     * @var int $idModoCobro
     */
    protected $idModoCobro;

    /**
     * @SWG\Property(property="ModoCobro", description="Nombre del modo de cobro")
     * @var string $modoCobro
     */
    protected $modoCobro;

    // PUBLIC FUNCTIONS ============================================================
    /**
     * Get idModoCobro attribute
     * @return int Identificador de modo de cobro
     */
    public function getIdModoCobro()
    {
        return $this->idModoCobro;
    }

    /**
     * Get modoCobro attribute
     * @return string Nombre del modo de cobro
     */
    public function getModoCobro()
    {
        return $this->modoCobro;
    }

    /**
     * Set idModoCobro
     * @param int $value Identificador de modo de cobro
     * @return void
     */
    public function setIdModoCobro(int $value)
    {
        $this->idModoCobro = $value;
    }

    /**
     * Set modoCobro
     * @param string $value Nombre del modo de cobro
     * @return void
     */
    public function setModoCobro(string $value)
    {
        $this->modoCobro = trim($value);
    }

    /**
     * Devolver datos de la entidad en formato array
     * @return array Entity data to array
     */
    public function toArray()
    {
        return [
            "IdModoCobro" => $this->getIdModoCobro(),
            "ModoCobro" => $this->getModoCobro()
        ];
    }
}

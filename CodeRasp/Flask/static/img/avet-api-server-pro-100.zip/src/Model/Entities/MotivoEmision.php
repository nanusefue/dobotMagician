<?php

namespace App\Model\Entities;

use App\Model\Entities\Entity as Entity;

/**
 * @SWG\Definition(
 *      definition="Aforo",
 *      type="object"
 * )
 */
class MotivoEmision extends Entity
{
    // PROTECTED VARS ==========================================================
    /**
     * @SWG\Property(property="Description",description="Descripción del aforo")
     * @var string $description
     */
    protected $descripcion;

    /**
     * @SWG\Property(property="IdAforo",description="Identificador unico de aforo")
     * @var int $idAforo
     */
    protected $idMotivo;

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Get description
     * @return string Nombre de aforo
     */
    public function getDescripcion()
    {
        return $this->descripcion;
    }

    /**
     * Get idAforo
     * @return int Identificador
     */
    public function getIdMotivo()
    {
        return $this->idMotivo;
    }

    /**
     * Set description
     * @param string $value Nombre de área o zona
     * @return void
     */
    public function setDescripcion(string $value)
    {
        $this->descripcion = $value;
    }

    /**
     * Set idAforo
     * @param int $value Identificador unico
     * @return void
     */
    public function setIdMotivo(int $value)
    {
        $this->idMotivo = $value;
    }

    /**
     * Devolver datos de la entidad en formato array
     * @return array Entity data to array
     */
    public function toArray()
    {
        return [
            "Descripcion" => $this->getDescripcion(),
            "IdMotivo" => $this->getIdMotivo()
        ];
    }
}

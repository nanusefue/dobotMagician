<?php

namespace App\Model\Entities;

use App\Model\Entities\Entity as Entity;

/**
 * @SWG\Definition(
 *      definition="AreaAvailability",
 *      type="object"
 * )
 */
class AreaAvailability extends Entity
{
    // PROTECTED VARS ==============================================================
    /**
     * @SWG\Property(property="IdAforo", description="Identificador de aforo")
     * @var int $idAforo
     */
    protected $idAforo;

    /**
     * @SWG\Property(property="IdArea", description="Identificador de area")
     * @var int $idArea
     */
    protected $idArea;

    /**
     * @SWG\Property(property="NumAsientos", description="Numero de asientos")
     * @var int $numAsientos
     */
    protected $numAsientos;

    // PUBLIC FUNCTIONS ============================================================
    /**
     * Get idAforo
     * @return int Identificador de aforo
     */
    public function getIdAforo()
    {
        return $this->idAforo;
    }

    /**
     * Get idArea
     * @return int Identificador de area
     */
    public function getIdArea()
    {
        return $this->idArea;
    }

    /**
     * Get numAsientos
     * @return int Numero de asientos
     */
    public function getNumAsientos()
    {
        return $this->numAsientos;
    }

    /**
     * Agregar valor al atributo idAforo
     * @param int $value Identificador de aforo
     * @return void
     */
    public function setIdAforo(int $value)
    {
        $this->idAforo = $value;
    }

    /**
     * Agregar valor al atributo idArea
     * @param int $value Identificador de area
     * @return void
     */
    public function setIdArea(int $value)
    {
        $this->idArea = $value;
    }

    /**
     * Agregar valor al atributo numAsientos
     * @param int $value Numero de asientos
     * @return void
     */
    public function setNumAsientos(int $value)
    {
        $this->numAsientos = $value;
    }

    /**
     * Devolver datos de la entidad en formato array
     * @return array Entity data to array
     */
    public function toArray()
    {
        return [
            "IdAforo" => $this->getIdAforo(),
            "IdArea" => $this->getIdArea(),
            "NumAsientos" => $this->getNumAsientos()
        ];
    }
}

<?php

namespace App\Model\Entities;

use App\Model\Entities\Entity as Entity;
use App\Utils\Error\ErrorException as ErrorException;
use Respect\Validation\Validator as Validator;

/**
 * @SWG\Definition(
 *      definition="PersonaInfo",
 *      type="object",
 *      required={
 *          "apellido1","apellido2","codigoPostal","codProvincia","dni",
 *          "domicilioCalle","domicilioCodVia","domicilioNumero","email",
 *          "fechaNacimiento","letraNIF","nombre","pais","telefonoMovil"
 *      }
 * )
 */
class PersonaInfo extends Entity
{
    // PROTECTED VARS ==========================================================
    /**
     * @SWG\Property(property="Apellido1", description="Primer apellido del usuario")
     * @var string $Apellido1
     */
    protected $apellido1;

    /**
     * @SWG\Property(property="Apellido2", description="Segundo apellido del usuario")
     * @var string $Apellido2
     */
    protected $apellido2;

    /**
     * @SWG\Property(property="Ayuntamiento", description="Nombre del ayuntamiento de la localidad")
     * @var string $ayuntamiento
     */
    protected $ayuntamiento;

    /**
     * @SWG\Property(property="BIC", description="BIC del usuario")
     * @var string $BIC
     */
    protected $BIC;

    /**
     * @SWG\Property(property="CodigoPostal", description="Codigo postal de la localidad")
     * @var string $codigoPostal
     */
    protected $codigoPostal;

    /**
     * @SWG\Property(property="CodProvincia", description="Codigo de provincia")
     * @var string $CodProvincia
     */
    protected $codProvincia;

    /**
     * @SWG\Property(property="DNI", description="Documento de identidad")
     * @var string $DNI
     */
    protected $dni;

    /**
     * @SWG\Property(property="Domicilio_Calle", description="Nombre de la calle del domicilio")
     * @var string $domicilioCalle
     */
    protected $domicilioCalle;

    /**
     * @SWG\Property(property="Domicilio_CodVia", description="Código de la via de la calle del domicilio")
     * @var string $domicilioCodVia
     */
    protected $domicilioCodVia;

    /**
     * @SWG\Property(property="Domicilio_Escalera", description="Escalera del domicilio")
     * @var string $domicilioEscalera
     */
    protected $domicilioEscalera;

    /**
     * @SWG\Property(property="Domicilio_Numero", description="Número del domicilio")
     * @var string $domicilioNumero
     */
    protected $domicilioNumero;

    /**
     * @SWG\Property(property="Domicilio_Piso", description="Piso del domicilio")
     * @var string $domicilioPiso
     */
    protected $domicilioPiso;

    /**
     * @SWG\Property(property="Email", description="Correo electronico de la persona")
     * @var string $Email
     */
    protected $email;

    /**
     * @SWG\Property(property="Empresa", description="Nombre de la empresa donde trabaja el usuario")
     * @var string $Empresa
     */
    protected $empresa;

    /**
     * @SWG\Property(property="FechaFirma", description="Fecha de la firma del usuario")
     * @var string $FechaFirma
     */
    protected $FechaFirma;

    /**
     * @SWG\Property(property="FechaNacimiento", description="Fecha de nacimiento del usuario")
     * @var string $FechaNacimiento
     */
    protected $fechaNacimiento;

    /**
     * @SWG\Property(property="IBAN", description="Número de cuenta bancaria del usuario")
     * @var string $IBAN
     */
    protected $iban;

    /**
     * @SWG\Property(property="IdProfesion", description="Identificador de profesion")
     * @var string $IdProfesion
     */
    protected $idProfesion;

    /**
     * @SWG\Property(property="IdPersona", description="Identificador de persona")
     * @var string $IdPersona
     */
    protected $idPersona;

    /**
     * @SWG\Property(property="LetraNIF", description="Letra del documento de identidad del usuario")
     * @var string $LetraNIF
     */
    protected $letraNIF;

    /**
     * @SWG\Property(property="Localidad", description="Localidad de residencia del usuario")
     * @var string $Localidad
     */
    protected $localidad;

    /**
     * @SWG\Property(property="Nombre", description="Nombre del usuario")
     * @var string $Nombre
     */
    protected $nombre;

    /**
     * @SWG\Property(property="Observaciones", description="Campo de observaciones")
     * @var string $Observaciones
     */
    protected $observaciones;

    /**
     * @SWG\Property(property="Pais", description="Pais de residencia del usuario")
     * @var string $Pais
     */
    protected $pais;

    /**
     * @SWG\Property(property="Santo", description="Fecha del santo del usuario")
     * @var string $Santo
     */
    protected $santo;

    /**
     * @SWG\Property(property="Sexo", description="Género del usuario")
     * @var string $Sexo
     */
    protected $sexo;

    /**
     * @SWG\Property(property="Telefono", description="Numero de telefono fijo del usuario")
     * @var string $Telefono
     */
    protected $telefono;

    /**
     * @SWG\Property(property="Telefono_Fax", description="Número de fax del usuario")
     * @var string $Telefono_Fax
     */
    protected $telefonoFax;

    /**
     * @SWG\Property(property="Telefono_Movil", description="Numero de telefono movil del usuario")
     * @var string $Telefono_Movil
     */
    protected $telefonoMovil;

    /**
     * @SWG\Property(property="Telefono_Oficina", description="Número de telefono de la oficina del usuario")
     * @var string $Telefono_Oficina
     */
    protected $telefonoOficina;

    // PUBLIC STATIC FUNCTIONS =================================================

    /**
     * Validate data
     * @param array $data Data to be validated
     * @return bool
     */
    public static function validate(array $data, $validator = null): ErrorException
    {
        $validator = Validator::attribute('Apellido1', Validator::stringType())
            ->attribute('Apellido2', Validator::stringType())
            ->attribute('Ayuntamiento', Validator::optional(Validator::stringType()))
            ->attribute('BIC', Validator::optional(Validator::stringType()))
            ->attribute('CodigoPostal', Validator::intVal()->stringType()->length(1, 5))
            ->attribute('CodProvincia', Validator::intVal()->stringType()->length(1, 2))
            ->attribute('Domicilio_Calle', Validator::stringType())
            ->attribute('Domicilio_CodVia', Validator::stringType())
            ->attribute('Domicilio_Escalera', Validator::optional(Validator::stringType()))
            ->attribute('Domicilio_Numero', Validator::stringType())
            ->attribute('Domicilio_Piso', Validator::optional(Validator::stringType()))
            ->attribute('DNI', Validator::stringType())
            ->attribute('Email', Validator::email())
            ->attribute('Empresa', Validator::optional(Validator::stringType()))
            /*->attribute('FechaNacimiento', Validator::oneOf(
                                                        Validator::date('Y-m-d'),
                                                        Validator::date('d/m/Y'),
                                                        Validator::date())
                                                        )*/

            ->attribute('FechaNacimiento', Validator::stringType()) //different date formats for espanyol

            /*->attribute('FechaFirma', Validator::optional(Validator::oneOf(
                                                        Validator::date('Y-m-d'),
                                                        Validator::date('d/m/Y'),
                                                        Validator::date())
                                                    ))*/
            ->attribute('FechaFirma',Validator::optional(Validator::stringType())) //different date formats
            ->attribute('IBAN', Validator::optional(Validator::stringType()))
            ->attribute('IdProfesion', Validator::optional(Validator::stringType()))
            ->attribute('LetraNIF', Validator::stringType()->length(1, 1))
            ->attribute('Localidad', Validator::stringType())
            ->attribute('Nombre', Validator::stringType())
            ->attribute('Observaciones', Validator::optional(Validator::stringType()))
            ->attribute('Pais', Validator::stringType())
            ->attribute('Santo', Validator::optional(Validator::date('dm')))
            ->attribute('Sexo', Validator::stringType())
            ->attribute('Telefono', Validator::stringType())
            ->attribute('Telefono_Fax', Validator::optional(Validator::stringType()))
            ->attribute('Telefono_Movil', Validator::stringType())
            ->attribute('Telefono_Oficina', Validator::optional(Validator::stringType()));
        return parent::validate($data, $validator);
    }

    // PUBLIC FUNCTIONS ========================================================

    /**
     * Get Primer apellido del usuario
     * @return string Valor atributo apellido1
     */
    public function getApellido1()
    {
        return $this->apellido1;
    }

    /**
     * Get Segundo apellido del usuario
     * @return string Valor atributo apellido2
     */
    public function getApellido2()
    {
        return $this->apellido2;
    }

    /**
     * Get Nombre del ayuntamiento de la localidad
     * @return string Valor atributo ayuntamiento
     */
    public function getAyuntamiento()
    {
        return $this->ayuntamiento;
    }

    /**
     * Get bic del usuario
     * @return string Valor atributo bic
     */
    public function getBIC()
    {
        return $this->bic;
    }

    /**
     * Get Codigo postal de la localidad
     * @return string Valor atributo codigoPostal
     */
    public function getCodigoPostal()
    {
        return $this->codigoPostal;
    }

    /**
     * Get Codigo de provincia
     * @return string Valor atributo codProvincia
     */
    public function getCodProvincia()
    {
        return $this->codProvincia;
    }

    /**
     * Get Documento de identidad
     * @return string Valor atributo dni
     */
    public function getDNI()
    {
        return $this->dni;
    }

    /**
     * Get Nombre de la calle del domicilio
     * @return string Valor atributo domicilioCalle
     */
    public function getDomicilioCalle()
    {
        return $this->domicilioCalle;
    }

    /**
     * Get Código de la via de la calle del domicilio
     * @return string Valor atributo domicilioCodVia
     */
    public function getDomicilioCodVia()
    {
        return $this->domicilioCodVia;
    }

    /**
     * Get Escalera del domicilio
     * @return string Valor atributo domicilioEscalera
     */
    public function getDomicilioEscalera()
    {
        return $this->domicilioEscalera;
    }

    /**
     * Get Número del domicilio
     * @return string Valor atributo domicilioNumero
     */
    public function getDomicilioNumero()
    {
        return $this->domicilioNumero;
    }

    /**
     * Get Piso del domicilio
     * @return string Valor atributo domicilioPiso
     */
    public function getDomicilioPiso()
    {
        return $this->domicilioPiso;
    }

    /**
     * Get Correo electronico de la persona
     * @return string Valor atributo email
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Get Nombre de la empresa donde trabaja el usuario
     * @return string Valor atributo empresa
     */
    public function getEmpresa()
    {
        return $this->empresa;
    }

    /**
     * Get fecha de la firma del usuario
     * @return string Valor atributo fechaFirma
     */
    public function getFechaFirma()
    {
        return $this->fechaFirma;
    }

    /**
     * Get Fecha de nacimiento del usuario
     * @return string Valor atributo fechaNacimiento
     */
    public function getFechaNacimiento()
    {
        return $this->fechaNacimiento;
    }

    /**
     * Get Número de cuenta bancaria del usuario
     * @return string Valor atributo iban
     */
    public function getIBAN()
    {
        return $this->iban;
    }

    /**
     * Get Identificador de profesion
     * @return string Valor atributo idProfesion
     */
    public function getIdProfesion()
    {
        return $this->idProfesion;
    }

    /**
     * Get Identificador de persona
     * @return string Valor atributo idPersona
     */
    public function getIdPersona()
    {
        return $this->idPersona;
    }

    /**
     * Get Letra del documento de identidad del usuario
     * @return string Valor atributo letraNIF
     */
    public function getLetraNIF()
    {
        return $this->letraNIF;
    }

    /**
     * Get Localidad de residencia del usuario
     * @return string Valor atributo localidad
     */
    public function getLocalidad()
    {
        return $this->localidad;
    }

    /**
     * Get Nombre del usuario
     * @return string Valor atributo nombre
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * Get Campo de observaciones
     * @return string Valor atributo observaciones
     */
    public function getObservaciones()
    {
        return $this->observaciones;
    }

    /**
     * Get Pais de residencia del usuario
     * @return string Valor atributo pais
     */
    public function getPais()
    {
        return $this->pais;
    }

    /**
     * Get Fecha del santo del usuario
     * @return string Valor atributo santo
     */
    public function getSanto()
    {
        return $this->santo;
    }

    /**
     * Get Género del usuario
     * @return string Valor atributo sexo
     */
    public function getSexo()
    {
        return $this->sexo;
    }

    /**
     * Get Numero de telefono fijo del usuario
     * @return string Valor atributo telefono
     */
    public function getTelefono()
    {
        return $this->telefono;
    }

    /**
     * Get Numero de fax del usuario
     * @return string Valor atributo telefonoFax
     */
    public function getTelefonoFax()
    {
        return $this->telefonoFax;
    }

    /**
     * Get Numero de telefono movil del usuario
     * @return string Valor atributo telefonoMovil
     */
    public function getTelefonoMovil()
    {
        return $this->telefonoMovil;
    }

    /**
     * Get numero de telefono oficina del usuario
     * @return string Valor atributo telefonoOficina
     */
    public function getTelefonoOficina()
    {
        return $this->telefonoOficina;
    }

    /**
     * Set Primer apellido del usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setApellido1(string $value)
    {
        $this->apellido1 = trim($value);
    }

    /**
     * Set Segundo apellido del usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setApellido2(string $value)
    {
        $this->apellido2 = trim($value);
    }

    /**
     * Set Nombre del ayuntamiento de la localidad
     * @param string $value Valor a modificar
     * @return void
     */
    public function setAyuntamiento(string $value)
    {
        $this->ayuntamiento = trim($value);
    }

    /**
     * Set BIC del usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setBIC(string $value)
    {
        $this->bic = trim($value);
    }

    /**
     * Set Codigo postal de la localidad
     * @param string $value Valor a modificar
     * @return void
     */


    public function setCodigoPostal(string $value)
    {
        $this->codigoPostal = trim($value);
    }

    /**
     * Set Codigo de provincia
     * @param string $value Valor a modificar
     * @return void
     */
    public function setCodProvincia(string $value)
    {
        $this->codProvincia = trim($value);
    }

    /**
     * Set Documento de identidad
     * @param string $value Valor a modificar
     * @return void
     */
    public function setDNI(string $value)
    {
        $this->dni = trim($value);
    }

    /**
     * Set Nombre de la calle del domicilio
     * @param string $value Valor a modificar
     * @return void
     */
    public function setDomicilioCalle(string $value)
    {
        $this->domicilioCalle = trim($value);
    }

    /**
     * Set Código de la via de la calle del domicilio
     * @param string $value Valor a modificar
     * @return void
     */
    public function setDomicilioCodVia(string $value)
    {
        $this->domicilioCodVia = trim($value);
    }

    /**
     * Set Escalera del domicilio
     * @param string $value Valor a modificar
     * @return void
     */
    public function setDomicilioEscalera(string $value)
    {
        $this->domicilioEscalera = trim($value);
    }

    /**
     * Set Número del domicilio
     * @param string $value Valor a modificar
     * @return void
     */
    public function setDomicilioNumero(string $value)
    {
        $this->domicilioNumero = trim($value);
    }

    /**
     * Set Piso del domicilio
     * @param string $value Valor a modificar
     * @return void
     */
    public function setDomicilioPiso(string $value)
    {
        $this->domicilioPiso = trim($value);
    }

    /**
     * Set Correo electronico de la persona
     * @param string $value Valor a modificar
     * @return void
     */
    public function setEmail(string $value)
    {
        $this->email = trim($value);
    }

    /**
     * Set Nombre de la empresa donde trabaja el usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setEmpresa(string $value)
    {
        $this->empresa = trim($value);
    }

    /**
     * Set fecha de la firma del usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setFechaFirma(string $value)
    {
        $this->fechaFirma = trim($value);
    }

    /**
     * Set Fecha de nacimiento del usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setFechaNacimiento(string $value)
    {
        $this->fechaNacimiento = trim($value);
    }

    /**
     * Set Número de cuenta bancaria del usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setIBAN(string $value)
    {
        $this->iban = trim($value);
    }

    /**
     * Set Identificador de profesion
     * @param string $value Valor a modificar
     * @return void
     */
    public function setIdProfesion(string $value)
    {
        $this->idProfesion = trim($value);
    }

    /**
     * Set Identificador de persona
     * @param string $value Valor a modificar
     * @return void
     */
    public function setIdPersona(string $value)
    {
        $this->idPersona = trim($value);
    }

    /**
     * Set Letra del documento de identidad del usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setLetraNIF(string $value)
    {
        $this->letraNIF = trim($value);
    }

    /**
     * Set Localidad de residencia del usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setLocalidad(string $value)
    {
        $this->localidad = trim($value);
    }

    /**
     * Set Nombre del usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setNombre(string $value)
    {
        $this->nombre = trim($value);
    }

    /**
     * Set Campo de observaciones
     * @param string $value Valor a modificar
     * @return void
     */
    public function setObservaciones(string $value)
    {
        $this->observaciones = trim($value);
    }

    /**
     * Set Pais de residencia del usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setPais(string $value)
    {
        $this->pais = trim($value);
    }

    /**
     * Set Fecha del santo del usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setSanto(string $value)
    {
        $this->santo = trim($value);
    }

    /**
     * Set Género del usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setSexo(string $value)
    {
        $this->sexo = trim($value);
    }

    /**
     * Set Numero de telefono fijo del usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setTelefono(string $value)
    {
        $this->telefono = trim($value);
    }

    /**
     * Set Numero de fax del usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setTelefonoFax(string $value)
    {
        $this->telefonoFax = trim($value);
    }

    /**
     * Set Numero de telefono movil del usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setTelefonoMovil(string $value)
    {
        $this->telefonoMovil = trim($value);
    }

    /**
     * Set numero de telefono oficina del usuario
     * @param string $value Valor a modificar
     * @return void
     */
    public function setTelefonoOficina(string $value)
    {
        $this->telefonoOficina = trim($value);
    }

    /**
     * Devolver datos de la entidad en formato array
     * @return array Entity data to array
     */
    public function toArray()
    {
        return [
            "Apellido1" => $this->getApellido1(),
            "Apellido2" => $this->getApellido2(),
            "Ayuntamiento" => $this->getAyuntamiento(),
            "BIC" => $this->getBIC(),
            "CodigoPostal" => $this->getCodigoPostal(),
            "CodProvincia" => $this->getCodProvincia(),
            "DNI" => $this->getDNI(),
            "Domicilio_Calle" => $this->getDomicilioCalle(),
            "Domicilio_CodVia" => $this->getDomicilioCodVia(),
            "Domicilio_Escalera" => $this->getDomicilioEscalera(),
            "Domicilio_Numero" => $this->getDomicilioNumero(),
            "Domicilio_Piso" => $this->getDomicilioPiso(),
            "Email" => $this->getEmail(),
            "Empresa" => $this->getEmpresa(),
            "FechaFirma" => $this->getFechaFirma(),
            "FechaNacimiento" => $this->getFechaNacimiento(),
            "IBAN" => $this->getIBAN(),
            "IdPersona" => $this->getIdPersona(),
            "IdProfesion" => $this->getIdProfesion(),
            "LetraNIF" => $this->getLetraNIF(),
            "Localidad" => $this->getLocalidad(),
            "Nombre" => $this->getNombre(),
            "Observaciones" => $this->getObservaciones(),
            "Pais" => $this->getPais(),
            "Santo" => $this->getSanto(),
            "Sexo" => $this->getSexo(),
            "Telefono" => $this->getTelefono(),
            "Telefono_Fax" => $this->getTelefonoFax(),
            "Telefono_Movil" => $this->getTelefonoMovil(),
            "Telefono_Oficina" => $this->getTelefonoOficina()
        ];
    }
}

<?php

namespace App\Model\Entities;

use App\Model\Entities\Entity as Entity;

/**
 * @SWG\Definition(
 *      definition="SeatStatus",
 *      type="object"
 * )
 */
class SeatStatus extends Entity
{
    // PROTECTED VARS ==========================================================
    /**
     * @SWG\Property(property="Estado",description="Estado de asiento (N = No disponible, D = Disponible)")
     * @var string $estado
     */
    protected $estado;

    /**
     * @SWG\Property(property="IdSeat",description="Identificador unico de asiento")
     * @var int $idSeat Identificador unico de asiento
     */
    protected $idSeat;

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Get estado
     * @return string Nombre de estado
     */
    public function getEstado()
    {
        return $this->estado;
    }

    /**
     * Get idSeat
     * @return int Identificador de asiento
     */
    public function getIdSeat()
    {
        return $this->idSeat;
    }

    /**
     * Check if the seat is available
     * @return boolean True if estado attribute has "D" value.
     */
    public function isAvailable()
    {
        if ($this->getEstado() === "D") {
            return true;
        }

        return false;
    }

    /**
     * Set estado
     * @param string $value Nombre de área o zona
     * @return void
     */
    public function setEstado(string $value)
    {
        $this->estado = $value;
    }

    /**
     * Set idSeat
     * @param int $value Identificador
     * @return void
     */
    public function setIdSeat(int $value)
    {
        $this->idSeat = $value;
    }

    /**
     * Devolver datos de la entidad en formato array
     * @return array Entity data to array
     */
    public function toArray()
    {
        return [
            "Estado" => $this->getEstado(),
            "IdSeat" => $this->getIdSeat()
        ];
    }
}

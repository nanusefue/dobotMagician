<?php

namespace App\Model\Entities;

use App\Model\Entities\Entity as Entity;

/**
 * @SWG\Definition(
 *      definition="PlazoInfo",
 *      type="object"
 * )
 */
class PlazoInfo extends Entity
{
    // PROTECTED VARS ==========================================================
    /**
     * @SWG\Property(property="Fecha",description="Fecha")
     * @var \DateTime $fecha
     */
    protected $fecha;

    /**
     * @SWG\Property(property="IdPeriodicidad",description="Identificador de periodicidad")
     * @var int $idPeriodicidad
     */
    protected $idPeriodicidad;

    /**
     * @SWG\Property(property="IdPlazo",description="Identificador de plazo")
     * @var int $idPlazo
     */
    protected $idPlazo;

    /**
     * @SWG\Property(property="Periodicidad",description="Descripcion de la periodicidad")
     * @var string $periodicidad
     */
    protected $periodicidad;

    /**
     * @SWG\Property(property="Plazo",description="Descripcion del plazo")
     * @var string $plazo
     */
    protected $plazo;

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Get fecha
     * @return \DateTime Fecha
     */
    public function getFecha()
    {
        return $this->fecha;
    }

    /**
     * Get idPeriodicidad
     * @return int Identificador de periodicidad
     */
    public function getIdPeriodicidad()
    {
        return $this->idPeriodicidad;
    }

    /**
     * Get idPlazo
     * @return int Identificador de plazo
     */
    public function getIdPlazo()
    {
        return $this->idPlazo;
    }

    /**
     * Get periodicidad
     * @return string Descripcion de la periodicidad
     */
    public function getPeriodicidad()
    {
        return $this->periodicidad;
    }

    /**
     * Get plazo
     * @return string Descripcion del plazo
     */
    public function getPlazo()
    {
        return $this->plazo;
    }

    /**
     * Set fecha
     * @param \DateTime $value Fecha
     * @return void
     */
    public function setFecha(\DateTime $value)
    {
        $this->fecha = $value;
    }

    /**
     * Set idPeriodicidad
     * @param int $value Identificador de periodicidad
     * @return void
     */
    public function setIdPeriodicidad(int $value)
    {
        $this->idPeriodicidad = $value;
    }

    /**
     * Set idPlazo
     * @param int $value Identificador de periodicidad
     * @return void
     */
    public function setIdPlazo(int $value)
    {
        $this->idPlazo = $value;
    }

    /**
     * Set periodicidad
     * @param string $value Identificador de periodicidad
     * @return void
     */
    public function setPeriodicidad(string $value)
    {
        $this->periodicidad = trim($value);
    }

    /**
     * Set plazo
     * @param string $value Identificador de plazo
     * @return void
     */
    public function setPlazo(string $value)
    {
        $this->plazo = trim($value);
    }

    /**
     * Devolver datos de la entidad en formato array
     * @return array Entity data to array
     */
    public function toArray()
    {
        return [
            "Fecha" => $this->getFecha()->format("Y-m-d\TH:i:s"),
            "IdPeriodicidad" => $this->getIdPeriodicidad(),
            "IdPlazo" => $this->getIdPlazo(),
            "Periodicidad" => $this->getPeriodicidad(),
            "Plazo" => $this->getPlazo()
        ];
    }
}

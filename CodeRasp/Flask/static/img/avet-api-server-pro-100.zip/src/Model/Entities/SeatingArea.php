<?php

namespace App\Model\Entities;

use App\Model\Entities\Entity as Entity;

/**
 * @SWG\Definition(
 *      definition="SeatingArea",
 *      type="object"
 * )
 */
class SeatingArea extends Entity
{
    // PUBLIC VARS =================================================================
    /**
     * @SWG\Property(property="Gate",description="Nombre de puerta para acceder al asiento")
     * @var string $gate
     */
    protected $gate;

    /**
     * @SWG\Property(property="IdArea",description="Identificador de area")
     * @var int $idArea
     */
    protected $idArea;

    /**
     * @SWG\Property(property="IdSeat",description="Identificador de asiento")
     * @var int $idSeat
     */
    protected $idSeat;

    /**
     * @SWG\Property(property="PosRow",description="Posicion de la fila del asiento")
     * @var int $posRow
     */
    protected $posRow;

    /**
     * @SWG\Property(property="PosSeat",description="Posicion del asiento")
     * @var int $posSeat
     */
    protected $posSeat;

    /**
     * @SWG\Property(property="Row",description="Nombre de la fila del asiento")
     * @var string $row
     */
    protected $row;

    /**
     * @SWG\Property(property="Seat",description="Nombre del asiento")
     * @var string $seat
     */
    protected $seat;

    /**
     * @SWG\Property(property="Vomitorio", description="Nombre del vomitorio para acceder al asiento")
     * @var string $vomitorio
     */
    protected $vomitorio;

    // PUBLIC FUNCTIONS ============================================================
    /**
     * Get gate
     *
     * @return string Nombre de la puerta de entrada
     */
    public function getGate()
    {
        return $this->gate;
    }

    /**
     * Get idArea
     *
     * @return int Identificador de area
     */
    public function getIdArea()
    {
        return $this->idArea;
    }

    /**
     * Get idSeat
     *
     * @return int Identificador de asiento
     */
    public function getIdSeat()
    {
        return $this->idSeat;
    }

    /**
     * Get posRow
     *
     * @return int Posicion de la fila del asiento
     */
    public function getPosRow()
    {
        return $this->posRow;
    }

    /**
     * Get posSeat
     *
     * @return int Posicion del asiento
     */
    public function getPosSeat()
    {
        return $this->posSeat;
    }

    /**
     * Get row
     *
     * @return string Nombre de la fila del asiento
     */
    public function getRow()
    {
        return $this->row;
    }

    /**
     * Get seat
     *
     * @return string Nombre del asiento
     */
    public function getSeat()
    {
        return $this->seat;
    }

    /**
     * Get vomitorio
     *
     * @return string Nombre del vomitorio para acceder al asiento
     */
    public function getVomitorio()
    {
        return $this->vomitorio;
    }

    /**
     * Set gate
     *
     * @param string $value Nombre de la puerta de entrada
     *
     * @return void
     */
    public function setGate(string $value)
    {
        $this->gate = $value;
    }

    /**
     * Set idArea
     *
     * @param int $value Identificador de area
     *
     * @return void
     */
    public function setIdArea(int $value)
    {
        $this->idArea = $value;
    }

    /**
     * Set idSeat
     *
     * @param int $value Identificador de asiento
     *
     * @return void
     */
    public function setIdSeat(int $value)
    {
        $this->idSeat = $value;
    }

    /**
     * Set posRow
     *
     * @param int $value Posicion de la fila del asiento
     *
     * @return void
     */
    public function setPosRow(int $value)
    {
        $this->posRow = $value;
    }

    /**
     * Set posSeat
     *
     * @param int $value Posicion del asiento
     *
     * @return void
     */
    public function setPosSeat(int $value)
    {
        $this->posSeat = $value;
    }

    /**
     * Set row
     *
     * @param string $value Nombre de la fila del asiento
     *
     * @return void
     */
    public function setRow(string $value)
    {
        $this->row = $value;
    }

    /**
     * Set seat
     *
     * @param string $value Nombre del asiento
     *
     * @return void
     */
    public function setSeat(string $value)
    {
        $this->seat = $value;
    }

    /**
     * Set vomitorio
     *
     * @param string $value Nombre del vomitorio para acceder al asiento
     *
     * @return void
     */
    public function setVomitorio(string $value)
    {
        $this->vomitorio = $value;
    }

    /**
     * Devolver datos de la entidad en formato array
     * @return array Entity data to array
     */
    public function toArray()
    {
        return [
            "Gate" => $this->getGate(),
            "IdArea" => $this->getIdArea(),
            "IdSeat" => $this->getIdSeat(),
            "PosRow" => $this->getPosRow(),
            "PosSeat" => $this->getPosSeat(),
            "Row" => $this->getRow(),
            "Seat" => $this->getSeat(),
            "Vomitorio" => $this->getVomitorio()
        ];
    }
}

<?php

namespace App\Model\Entities;

use App\Utils\Error\ErrorException as ErrorException;
use App\Model\Entities\Entity as Entity;
use App\Model\Entities\PartnerInfo as PartnerInfo;
use App\Model\Entities\PersonaInfo as PersonaInfo;
use App\Model\Entities\Titulo as Titulo;
use \Respect\Validation\Validator as Validator;

/**
 * @SWG\Definition(
 *      definition="Partner",
 *      type="object"
 * )
 */
class Partner extends Entity
{
    // PROTECTED VARS ==========================================================
    /**
     * @SWG\Property(property="PartnerInfo", description="Datos operativos del usuario")
     * @var PartnerInfo $partnerInfo
     */
    protected $partnerInfo;

    /**
     * @SWG\Property(property="PersonaInfo", description="Datos personales del usuario")
     * @var PersonaInfo $personaInfo
     */
    protected $personaInfo;

    /**
     * @SWG\Property(property="Titulo", description="Asiento del usuario")
     * @var Titulo $titulo
     */
    protected $titulo;

    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Validate data
     * @param array $data Data to be validated
     * @return bool
     */
    public static function validate(array $data, $validator = null) : ErrorException
    {
        // Validates PartnerInfo if it exists
        if (isset($data["PartnerInfo"])) {
            $validation = PartnerInfo::validate($data["PartnerInfo"]);
            if ($validation->isError()) {
                return $validation;
            }
        }

        // Validates PartnerInfo if it exists
        if (isset($data["PersonaInfo"])) {
            $validation = PersonaInfo::validate($data["PersonaInfo"]);
            if ($validation->isError()) {
                return $validation;
            }
        }

        // Validates Titulo if it exists
        if (isset($data["Titulo"])) {
            $validation = Titulo::validate($data["Titulo"]);
            if ($validation->isError()) {
                return $validation;
            }
        }

        // Validates PersonaInfo
        return parent::validate($data);
    }

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Get $partnerInfo
     * @return PartnerInfo Datos operativos del usuario
     */
    public function getPartnerInfo()
    {
        return $this->partnerInfo;
    }

    /**
     * Get $personaInfo
     * @return PersonaInfo Datos personales del usuario
     */
    public function getPersonaInfo()
    {
        return $this->personaInfo;
    }

    /**
     * Get $titulo
     * @return Titulo Asiento del usuario
     */
    public function getTitulo()
    {
        return $this->titulo;
    }

    /**
     * Set $partnerInfo
     * @param PartnerInfo $value Datos operativos del usuario
     * @return void
     */
    public function setPartnerInfo(PartnerInfo $value)
    {
        $this->partnerInfo = $value;
    }

    /**
     * Set $personaInfo
     * @param PersonaInfo $value Datos personales del usuario
     * @return void
     */
    public function setPersonaInfo(PersonaInfo $value)
    {
        $this->personaInfo = $value;
    }

    /**
     * Set $titulo
     * @param Titulo $value Asiento del usuario
     * @return void
     */
    public function setTitulo(Titulo $value)
    {
        $this->titulo = $value;
    }

    /**
     * Devolver datos de la entidad en formato array
     * @return array Entity data to array
     */
    public function toArray()
    {
        $toReturn = [];

        // Get partnerInfo
        $partnerInfo = $this->getPartnerInfo();
        if (isset($partnerInfo) ) {
            $toReturn["PartnerInfo"] = $partnerInfo->toArray();
        }

        // Get personaInfo
        $personaInfo = $this->getPersonaInfo();
        if (isset($personaInfo) ) {
            $toReturn["PersonaInfo"] = $personaInfo->toArray();
        }

        // Get titulo
        $titulo = $this->getTitulo();
        if (isset($titulo) ) {
            $toReturn["Titulo"] = $titulo->toArray();
        }

        // Devolver datos
        return $toReturn;
    }
}

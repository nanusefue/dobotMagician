<?php

namespace App\Model\Entities;

use App\Model\Entities\Entity as Entity;

/**
 * @SWG\Definition(
 *      definition="RolPartnerInfo",
 *      type="object"
 * )
 */
class RolPartnerInfo extends Entity
{
    // PROTECTED VARS ==========================================================
    /**
     * @SWG\Property(property="Nombre",description="Descripcion del rol")
     * @var string $description
     */
    protected $nombre;

    /**
     * @SWG\Property(property="IdTipo",description="Identificador unico de rol")
     * @var int $idTipo
     */
    protected $idTipo;

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Get nombre
     * @return string Nombre de abono
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * Get idTipo
     * @return int Identificador
     */
    public function getIdTipo()
    {
        return $this->idTipo;
    }

    /**
     * Set nombre
     * @param string $value Nombre de área o zona
     * @return void
     */
    public function setNombre(string $value)
    {
        $this->nombre = trim($value);
    }

    /**
     * Set idTipo
     * @param int $value Identificador unico
     * @return void
     */
    public function setIdTipo(int $value)
    {
        $this->idTipo = $value;
    }

    /**
     * Devolver datos de la entidad en formato array
     * @return array Entity data to array
     */
    public function toArray()
    {
        return [
            "IdTipo" => $this->getIdTipo(),
            "Nombre" => $this->getNombre()
        ];
    }
}

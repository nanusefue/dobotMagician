<?php

namespace App\Model\Entities;

use App\Model\Entities\Entity as Entity;

/**
 * @SWG\Definition(
 *      definition="Pago",
 *      type="object"
 * )
 */
class Pago extends Entity
{
    // PROTECTED VARS ==============================================================
    /**
     * @SWG\Property(property="Cantidad",description="Cantidad realizada en el pago")
     * @var float $cantidad
     */
    protected $cantidad;

    /**
     * @SWG\Property(property="Descuento", description="Cantidad para realizar el descuento")
     * @var float $descuento
     */
    protected $descuento;

    /**
     * @SWG\Property(property="DtoPromos", description="Cantidad a descontar por promociones")
     * @var float $dtoPromos
     */
    protected $dtoPromos;

    /**
     * @SWG\Property(property="FechaPago", description="Fecha pagos")
     * @var \DateTime $fechaPago
     */
    protected $fechaPago;

    /**
     * @SWG\Property(property="IdAforo", description="Identificador de aforo")
     * @var int $idAforo
     */
    protected $idAforo;

    /**
     * @SWG\Property(property="IdPago", description="Identificador de pago")
     * @var int $idPago
     */
    protected $idPago;

    /**
     * @SWG\Property(property="IdPlazo", description="Identificador de plazo")
     * @var int $idPlazo
     */
    protected $idPlazo;

    /**
     * @SWG\Property(property="Pagado", description="Flag que indica si el pago se ha realizado")
     * @var int $pagado
     */
    protected $pagado;

    /**
     * @SWG\Property(property="Temporada", description="Temporada del pago")
     * @var string $temporada
     */
    protected $temporada;

    /**
     * @SWG\Property(property="Tipo", description="Tipo de pago")
     * @var int $tipo
     */
    protected $tipo;

    /**
     * @SWG\Property(property="Zona", description="Identificador de zona")
     * @var int $zona
     */
    protected $zona;

    // PUBLIC FUNCTIONS ============================================================
    /**
     * Get cantidad
     * @return float Cantidad realizada en el pago
     */
    public function getCantidad()
    {
        return $this->cantidad;
    }

    /**
     * Get descuento
     * @return float Cantidad para realizar el descuento
     */
    public function getDescuento()
    {
        return $this->descuento;
    }

    /**
     * Get dtoPromos
     * @return float Cantidad a descontar por promociones
     */
    public function getDtoPromos()
    {
        return $this->dtoPromos;
    }

    /**
     * Get fechaPago
     * @return \DateTime Fecha pagos
     */
    public function getFechaPago()
    {
        return $this->fechaPago;
    }

    /**
     * Get idAforo
     * @return int Identificador de aforo
     */
    public function getIdAforo()
    {
        return $this->idAforo;
    }

    /**
     * Get idPago
     * @return int Identificador de pago
     */
    public function getIdPago()
    {
        return $this->idPago;
    }

    /**
     * Get idPlazo
     * @return int Identificador de plazo
     */
    public function getIdPlazo()
    {
        return $this->idPlazo;
    }

    /**
     * Get pagado
     * @return int Flag que indica si es pagado
     */
    public function getPagado()
    {
        return $this->pagado;
    }

    /**
     * Get temporada
     * @return string Temporada del pago
     */
    public function getTemporada()
    {
        return $this->temporada;
    }

    /**
     * Get tipo
     * @return int Identificador de tipo
     */
    public function getTipo()
    {
        return $this->tipo;
    }

    /**
     * Get zona
     * @return int Identificador de zona
     */
    public function getZona()
    {
        return $this->zona;
    }

    /**
     * Set $cantidad
     * @param float $value Cantidad realizada en el pago
     * @return void
     */
    public function setCantidad(float $value)
    {
        $this->cantidad = $value;
    }

    /**
     * Set $descuento
     * @param float $value Cantidad realizada en el pago
     * @return void
     */
    public function setDescuento(float $value)
    {
        $this->descuento = $value;
    }

    /**
     * Set $dtoPromos
     * @param float $value Cantidad realizada en el pago
     * @return void
     */
    public function setDtoPromos(float $value)
    {
        $this->dtoPromos = $value;
    }

    /**
     * Set $fechaPago
     * @param \DateTime $value Cantidad realizada en el pago
     * @return void
     */
    public function setFechaPago(\DateTime $value)
    {
        $this->fechaPago = $value;
    }

    /**
     * Set $idAforo
     * @param int $value Identificador de aforo
     * @return void
     */
    public function setIdAforo(int $value)
    {
        $this->idAforo = $value;
    }

    /**
     * Set $idPago
     * @param int $value Identificador de pago
     * @return void
     */
    public function setIdPago(int $value)
    {
        $this->idPago = $value;
    }

    /**
     * Set $idPlazo
     * @param int $value Identificador de plazo
     * @return void
     */
    public function setIdPlazo(int $value)
    {
        $this->idPlazo = $value;
    }

    /**
     * Set $pagado
     * @param int $value Flag que indica si es pagado
     * @return void
     */
    public function setPagado(int $value)
    {
        $this->pagado = $value;
    }

    /**
     * Set $temporada
     * @param string $value Temporada del pago
     * @return void
     */
    public function setTemporada(string $value)
    {
        $this->temporada = $value;
    }

    /**
     * Set $tipo
     * @param int $value Tipo de pago
     * @return void
     */
    public function setTipo(int $value)
    {
        $this->tipo = $value;
    }

    /**
     * Set $zona
     * @param int $value Identificador de zona
     * @return void
     */
    public function setZona(int $value)
    {
        $this->zona = $value;
    }

    public function toArray()
    {
        // Get fecha pago
        $fechaPago = $this->getFechaPago()->format("Y-m-d\TH:i:s");

        // Return
        return [
            "Cantidad" => $this->getCantidad(),
            "Descuento" => $this->getDescuento(),
            "DtoPromos" => $this->getDtoPromos(),
            "FechaPago" => $fechaPago,
            "IdAforo" => $this->getIdAforo(),
            "IdPlazo" => $this->getIdPlazo(),
            "Pagado" => $this->getPagado(),
            "Temporada" => $this->getTemporada(),
            "Tipo" => $this->getTipo(),
            "Zona" => $this->getZona()
        ];
    }
}

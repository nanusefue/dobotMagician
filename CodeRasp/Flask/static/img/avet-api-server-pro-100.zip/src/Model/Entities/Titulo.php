<?php

namespace App\Model\Entities;

use App\Utils\Error\ErrorException as ErrorException;
use App\Model\Entities\Entity as Entity;
use \Respect\Validation\Validator as Validator;
/**
 * @SWG\Definition(
 *      definition="Titulo",
 *      type="object"
 * )
 */
class Titulo extends Entity
{
    // PUBLIC VARS =============================================================
    /**
     * @SWG\Property(property="Asiento",description="Nombre del asiento")
     * @var string $asiento
     */
    protected $asiento;

    /**
     * @SWG\Property(property="Fila",description="Nombre de la fila")
     * @var string $fila
     */
    protected $fila;

    /**
     * @SWG\Property(property="IdAforo",description="Identificador de aforo")
     * @var int $idAforo
     */
    protected $idAforo;

    /**
     * @SWG\Property(property="IdAsiento",description="Identificador de asiento")
     * @var int $idAsiento
     */
    protected $idAsiento;

    /**
     * @SWG\Property(property="IdPeriodicidad",description="Identificador de periodicidad")
     * @var int $idPeriodicidad
     */
    protected $idPeriodicidad;

    /**
     * @SWG\Property(property="IdTipoAbono",description="Identificador de tipo de abono")
     * @var int $idTipoAbono
     */
    protected $idTipoAbono;

    /**
     * @SWG\Property(property="IdZona",description="Identificador de zona")
     * @var int $idZona
     */
    protected $idZona;

    /**
     * @SWG\Property(property="Validez",description="Validez del titulo")
     * @var string $validez
     */
    protected $validez;

    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Validate data
     * @param array $data Data to be validated
     * @return bool
     */
    public static function validate(array $data, $validator = null) : ErrorException
    {
        $validator = Validator::attribute('Asiento', Validator::stringType())
                                ->attribute('Fila', Validator::stringType())
                                ->attribute('IdAforo', Validator::intType())
                                ->attribute('IdAsiento', Validator::oneOf(
                                    Validator::intType(),
                                    Validator::stringType())
                                )
                                ->attribute('IdPeriodicidad', Validator::intType())
                                ->attribute('IdTipoAbono', Validator::intType())
                                ->attribute('IdZona', Validator::intType())
                                ->attribute('Validez', Validator::stringType(), false);
        return parent::validate($data, $validator);
    }

    // PUBLIC FUNCTIONS ============================================================
    /**
     * Get asiento
     * @return string Nombre del asiento
     */
    public function getAsiento()
    {
        return $this->asiento;
    }

    /**
     * Get fila
     * @return string Nombre del fila
     */
    public function getFila()
    {
        return $this->fila;
    }

    /**
     * Get idAforo
     * @return int Identificador de aforo
     */
    public function getIdAforo()
    {
        return $this->idAforo;
    }

    /**
     * Get idAsiento
     * @return int Identificador de asiento
     */
    public function getIdAsiento()
    {
        return $this->idAsiento;
    }

    /**
     * Get idPeriodicidad
     * @return int Identificador de periodicidad
     */
    public function getIdPeriodicidad()
    {
        return $this->idPeriodicidad;
    }

    /**
     * Get idTipoAbono
     * @return int Identificador de tipo de abono
     */
    public function getIdTipoAbono()
    {
        return $this->idTipoAbono;
    }

    /**
     * Get idZona
     * @return int Identificador de zona
     */
    public function getIdZona()
    {
        return $this->idZona;
    }

    /**
     * Get validez
     * @return string Validez del titulo
     */
    public function getValidez()
    {
        return $this->validez;
    }

    /**
     * Set asiento
     * @param string $value Nombre del asiento
     * @return void
     */
    public function setAsiento(string $value)
    {
        $this->asiento = $value;
    }

    /**
     * Set fila
     * @param string $value Nombre de la fila
     * @return void
     */
    public function setFila(string $value)
    {
        $this->fila = $value;
    }

    /**
     * Set idAforo
     * @param int $value Identificador de aforo
     * @return void
     */
    public function setIdAforo(int $value)
    {
        $this->idAforo = $value;
    }

    /**
     * Set idAsiento
     * @param int $value Identificador de asiento
     * @return void
     */
    public function setIdAsiento($value)
    {
        $this->idAsiento = $value;
    }

    /**
     * Set idPeriodicidad
     * @param int $value Identificador de periodicidad
     * @return void
     */
    public function setIdPeriodicidad(int $value)
    {
        $this->idPeriodicidad = $value;
    }

    /**
     * Set idTipoAbono
     * @param int $value Identificador de tipo de abono
     * @return void
     */
    public function setIdTipoAbono(int $value)
    {
        $this->idTipoAbono = $value;
    }

    /**
     * Set idZona
     * @param int $value Identificador de zona
     * @return void
     */
    public function setIdZona(int $value)
    {
        $this->idZona = $value;
    }

    /**
     * Set validez
     * @param string $value Validez del titulo
     * @return void
     */
    public function setValidez(string $value)
    {
        $this->validez = $value;
    }

    /**
     * Devolver datos de la entidad en formato array
     * @return array Entity data to array
     */
    public function toArray()
    {
        return [
            "Asiento" => $this->getAsiento(),
            "Fila" => $this->getFila(),
            "IdAforo" => $this->getIdAforo(),
            "IdAsiento" => $this->getIdAsiento(),
            "IdPeriodicidad" => $this->getIdPeriodicidad(),
            "IdTipoAbono" => $this->getIdTipoAbono(),
            "IdZona" => $this->getIdZona(),
            "Validez" => $this->getValidez()
        ];
    }
}

<?php
/**
 * Repository interface. Helps implementing the strategy pattern
 */
namespace App\Model\Repositories;

interface RepositoryInterface
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Get list
     * @param array $opt Find options
     * @return array Items list
     */
    public function find(array $opt) : array;
}

?>

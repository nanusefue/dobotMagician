<?php
/**
 * Repository mother class
 */
namespace App\Model\Repositories;

class Repository
{
    // PUBLIC VARS =============================================================
    /**
     * SOAP client
     * @var \SoapClient $soapclient
     */
    public $soapclient;

    // MAGIC FUNCTIONS =========================================================
    /**
     * Class constructor
     * @param \SoapClient $soapclient SOAP client
     * @return void
     */
    public function __construct(\SoapClient $soapclient)
    {
        $this->soapclient = $soapclient;
    }
    /*Beauty Debug*/
    public function debug($var){
        return highlight_string("<?php\n\$data =\n" . var_export($var, true) . ";\n?>");
    }
}

?>

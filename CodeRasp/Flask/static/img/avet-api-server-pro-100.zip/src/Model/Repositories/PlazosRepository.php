<?php

namespace App\Model\Repositories;

use App\Model\Repositories\Repository as Repository;
use App\Model\Repositories\RepositoryInterface as RepositoryInterface;
use App\Model\Factories\PlazoInfoFactory as PlazoInfoFactory;

class PlazosRepository extends Repository implements RepositoryInterface
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Get list
     * @param array $opt Find options
     * @return array Items list
     */
    public function find(array $opt) : array
    {
        // Llamada a la API
        $result = $this->soapclient->GetPlazosInfo($opt);

        // Formatear datos
        $ret = [];
        foreach ($result->GetPlazosInfoResult->PlazoInfo as $stdObj) {
            // Crear instancia a traves del factory
            $ret[] = PlazoInfoFactory::newFromAvet($stdObj);
        }

        // Return array
        return $ret;
    }
}


?>

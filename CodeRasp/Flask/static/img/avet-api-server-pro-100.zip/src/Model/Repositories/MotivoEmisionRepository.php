<?php

namespace App\Model\Repositories;

use App\Model\Repositories\Repository as Repository;
use App\Model\Repositories\RepositoryInterface as RepositoryInterface;
use App\Model\Factories\MotivoEmisionFactory as MotivoEmisionFactory;

class MotivoEmisionRepository extends Repository implements RepositoryInterface
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Get list
     * @param array $opt Find options
     * @return array Items list
     */
    public function find(array $opt) : array
    {
        // Llamada a la API
        $result = $this->soapclient->GetMotivoEmision($opt);

        // Formatear datos
        $ret = [];
        foreach ($result->GetMotivoEmisionResult->MotivoEmision as $stdObj) {
            // Crear instancia a traves del factory
            $ret[] = MotivoEmisionFactory::newFromAvet($stdObj);
        }

        // Return array
        return $ret;
    }
}


?>

<?php

namespace App\Model\Repositories;

use App\Model\Repositories\Repository as Repository;
use App\Model\Entities\PartnerOperation as PartnerOp;
use App\Model\Factories\PartnerOperationFactory as PartnerOpFactory;

use App\Utils\Error\ErrorException as ErrorException;

class PartnerOpRepository extends Repository
{
    // PUBLIC FUNCTIONS ========================================================
    /**
     * Creates a new partnerOperation
     * @param array $data Customer data in personaInfo format
     * @return PartnerOperation Entidad PartnerOp
     */
    public function add(array $data)
    {
        // Validate
        $result = PartnerOp::validate($data);

        if (!$result->isError()) {
            // Try to create partner
            $partnerOp = $this->soapclient->CreatePartner($data);
            if ( !is_soap_fault($partnerOp) ) {
                return PartnerOpFactory::newFromAvet($partnerOp->CreatePartnerResult);
            }
            // Create error exception
            $result = new ErrorException();
            $result->exception = $partnerOp;
        }
        // Return error instance
        return PartnerOpFactory::createErrorInstance($result);
    }

    /**
     * Confirms a PartnerOperation
     * @param array $opt PartnerOperation options
     * @return PartnerOperation Entidad PartnerOp
     */
    public function confirm(array $opt)
    {
        $partnerOp = $this->soapclient->ConfirmPartner($opt);
        if ( is_soap_fault($partnerOp) ) {
            $error = new ErrorException();
            $error->exception = $partnerOp;
            return PartnerOpFactory::createErrorInstance($error);
        }
        // Devolver PartnerOp
        return PartnerOpFactory::newFromAvet($partnerOp->ConfirmPartnerResult);
    }

    /**
     * PreConfirms a PartnerOperation
     * @param array $opt PartnerOperation options
     * @return PartnerOperation Entidad PartnerOp
     */
    public function preconfirm(array $opt)
    {
        $partnerOp = $this->soapclient->PreConfirmOperation($opt);
        if ( is_soap_fault($partnerOp) ) {
            $error = new ErrorException();
            $error->exception = $partnerOp;
            return PartnerOpFactory::createErrorInstance($error);
        }
        // Devolver PartnerOp
        return $partnerOp->PreConfirmOperationResult;
    }

    /**
     * Cancels an unconfirmed PartnerOperation
     * @param array $opt Cancel options
     * @return PartnerOperation Entidad PartnerOp
     */
    public function delete(array $opt)
    {
        $partnerOp = $this->soapclient->CancelPartner($opt);
        if ( is_soap_fault($partnerOp) ) {
            $error = new ErrorException();
            $error->exception = $partnerOp;
            return PartnerOpFactory::createErrorInstance($error);
        }
        // Devolver PartnerOp
        return PartnerOpFactory::newFromAvet($partnerOp->CancelPartnerResult);
    }

    /**
     * Modifies the complete content of a partnerOperation
     * @param array $data
     * @return PartnerOperation Entidad PartnerOp
     */
    public function edit(array $data)
    {
        // Validate
        $result = PartnerOp::validate($data["partnerOperation"]);
        if (!$result->isError()) {
            // Try to edit data
            $partnerOp = $this->soapclient->ModifyPartner($data);
            if ( !is_soap_fault($partnerOp) ) {
                return PartnerOpFactory::newFromAvet($partnerOp->ModifyPartnerResult);
            }
            $result = new ErrorException();
            $result->exception = $partnerOp;
        }
        // Return error instance
        return PartnerOpFactory::createErrorInstance($result);
    }

    /**
     * Modifies the current seat of the partner in the transaction partnerOperation
     * @param array $data
     * @return PartnerOperation Entidad PartnerOp
     */
    public function editSeat(array $data)
    {
        // Validate
        $validate["Partner"]["Titulo"] = $data["titulo"];
        $result = PartnerOp::validate($validate);
        if (!$result->isError()) {
            // Try to modify seat
            $partnerOp = $this->soapclient->ModifySeat($data);
            if ( !is_soap_fault($partnerOp) ) {
                return PartnerOpFactory::newFromAvet($partnerOp->ModifySeatResult);
            }
            $result = new ErrorException();
            $result->exception = $partnerOp;

        }
        // Return error instance
        return PartnerOpFactory::createErrorInstance($result);
    }

    /**
     * Buscar partnerOp
     * @param array $opt Opciones de busqueda
     * @return PartnerOperation Entidad PartnerOp
     */
    public function find(array $opt)
    {
        // Obtener resultado de la API
        $partner = $this->soapclient->GetPartner($opt);

        // Formar objeto a retornar
        if ( is_soap_fault($partner) ) {
            $error = new ErrorException();
            $error->exception = $partner;
            return PartnerOpFactory::createErrorInstance($error);
        }
        // Devolver PartnerOp
        return PartnerOpFactory::newFromAvet($partner->GetPartnerResult);
    }

    /*public function findByEmail(array $opt)
    {
        $partner = $this->soapclient->GetAttributes($opt);
    }*/

    /**
     * Prefconfirms a PartnerOperation
     * @param array $opt PartnerOperation options
     * @return PartnerOperation
     */
    /* public function preconfirm(array $opt)
    {
        $partnerOp = $this->soapclient->PreConfirmOperation($opt);
        if ( is_soap_fault($partnerOp) ) {
            return PartnerOpFactory::createErrorInstance($partnerOp);
        }
        // Devolver PartnerOp
        return PartnerOpFactory::newFromAvet($partnerOp->CancelPartnerResult);
    } */
}


?>

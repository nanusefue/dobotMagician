<?php

namespace App\Model\Factories;

use App\Model\Entities\Pago as Pago;
use App\Model\Factories\FactoryInterface as FactoryInterface;
use App\Utils\Error\ErrorException as ErrorException;

class PagoFactory implements FactoryInterface
{
    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Creates a class instance adding the SoapFault exception result as entity error
     * @param ErrorException $fault Exception
     * @return Pago Class instance with error
     */
    public static function createErrorInstance(ErrorException $fault)
    {
        // Create instance
        $instance = new Pago();
        $instance->setError($fault);

        // Return
        return $instance;
    }

    /**
     * Creates new Pago instance from \stdClass AVET object
     * @param \stdClass $obj AVET data object
     * @return Pago Class instance
     */
    public static function newFromAvet(\stdClass $obj)
    {
        $instance = new Pago();
        $instance->setCantidad($obj->Cantidad);
        $instance->setDescuento($obj->Descuento);
        $instance->setDtoPromos($obj->DtoPromos);
        $instance->setIdAforo($obj->IdAforo);
        $instance->setIdPlazo($obj->IdPlazo);
        $instance->setPagado($obj->Pagado);
        $instance->setTipo($obj->Tipo);
        $instance->setZona($obj->Zona);

        $dtm = new \DateTime($obj->FechaPago);
        $instance->setFechaPago($dtm);

        if ( isset($obj->Temporada) ) {
            $instance->setTemporada($obj->Temporada);
        }

        if (isset($obj->IdPago)) {
            $instance->setIdPago($obj->IdPago);
        }

        return $instance;
    }
}

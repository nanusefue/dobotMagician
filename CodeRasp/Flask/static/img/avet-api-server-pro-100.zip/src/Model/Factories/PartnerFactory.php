<?php

namespace App\Model\Factories;

use App\Model\Entities\Partner as Partner;
use App\Model\Factories\FactoryInterface as FactoryInterface;
use App\Model\Factories\PartnerInfoFactory as PartnerInfoFactory;
use App\Model\Factories\PersonaInfoFactory as PersonaInfoFactory;
use App\Model\Factories\TituloFactory as TituloFactory;
use App\Utils\Error\ErrorException as ErrorException;

class PartnerFactory implements FactoryInterface
{
    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Metodo factory que crea un objeto con un error
     * @param ErrorException $fault Exception
     * @return Partner Instancia de la clase con error
     */
    public static function createErrorInstance(ErrorException $fault)
    {
        // Create instance
        $instance = new Partner();
        $instance->setError($fault);

        // Return
        return $instance;
    }

    /**
     * Metodo que crea el objeto Partner desde un objeto de tipo respuesta
     * @param \stdClass $obj Objeto generico con los datos del Partner
     * @return Partner Instancia de la clase
     */
    public static function newFromAvet(\stdClass $obj)
    {
        // Crear instancia
        $instance = new Partner();

        // Crear PersonaInfo
        if (isset($obj->PersonaInfo) ) {
            $personaInfo = PersonaInfoFactory::newFromAvet($obj->PersonaInfo);
            $instance->setPersonaInfo($personaInfo);
        }

        // Crear PartnerInfo
        if (isset($obj->PartnerInfo) ) {
            $partnerInfo = PartnerInfoFactory::newFromAvet($obj->PartnerInfo);
            $instance->setPartnerInfo($partnerInfo);
        }

        // Titulo
        if (isset($obj->Titulo) ) {
            $titulo = TituloFactory::newFromAvet($obj->Titulo);
            $instance->setTitulo($titulo);
        }

        // Return instance
        return $instance;
    }
}

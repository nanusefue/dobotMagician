<?php

namespace App\Model\Factories;

use App\Model\Entities\Product as Product;
use App\Model\Factories\FactoryInterface as FactoryInterface;
use App\Utils\Error\ErrorException as ErrorException;

class ProductFactory implements FactoryInterface
{
    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Metodo factory que crea un objeto con un error
     * @param ErrorException $fault Exception
     * @return Product Instancia de la clase con error
     */
    public static function createErrorInstance(ErrorException $fault)
    {
        // Create instance
        $instance = new Product();
        $instance->setError($fault);

        // Return
        return $instance;
    }

    /**
     * Metodo que crea el objeto Product desde un objeto de tipo respuesta
     * @param \stdClass $obj Objeto generico con los datos del SeatStatus
     * @return Product Instancia de la clase
     */
    public static function newFromAvet(\stdClass $obj)
    {
        // Crear instancia
        $instance = new Product();

        // Iniciar atributos
        $instance->setCuotaPlazo($obj->CuotaPlazo);
        $instance->setIdAforo($obj->IdAforo);
        $instance->setIdPeriodicidad($obj->IdPeriodicidad);
        $instance->setIdPlazo($obj->IdPlazo);
        $instance->setIdTipoAbono($obj->IdTipoAbono);
        $instance->setIdZona($obj->IdZona);

        // Retornar instancia
        return $instance;
    }
}

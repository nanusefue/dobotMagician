<?php

namespace App\Model\Factories;

use App\Model\Entities\AreaAvailability as AreaAvailability;
use App\Model\Factories\FactoryInterface as FactoryInterface;
use App\Utils\Error\ErrorException as ErrorException;

class AreaAvailabilityFactory implements FactoryInterface
{
    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Metodo factory que crea un objeto con un error
     * @param ErrorException $fault Exception
     * @return AreaAvailability Instancia de la clase con error
     */
    public static function createErrorInstance(ErrorException $fault)
    {
        // Create instance
        $partnerOp = new AreaAvailability();
        $partnerOp->setError($fault);

        // Return
        return $partnerOp;
    }
    /**
     * Metodo que crea el objeto AreaAvailability desde un objeto de tipo respuesta
     * @param \stdClass $obj Objeto generico con los datos de la instancia
     * @return AreaAvailability Instancia de la clase
     */
    public static function newFromAvet(\stdClass $obj)
    {
        // Crear AreaAvailability
        $instance = new AreaAvailability();

        // Iniciar atributos
        $instance->setIdAforo($obj->IdAforo);
        $instance->setIdArea($obj->IdArea);
        $instance->setNumAsientos($obj->NumAsientos);

        return $instance;
    }
}

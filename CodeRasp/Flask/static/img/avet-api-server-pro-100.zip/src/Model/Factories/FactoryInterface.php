<?php

namespace App\Model\Factories;

use App\Utils\Error\ErrorException as ErrorException;

interface FactoryInterface
{
    // PUBLIC FUNCTIONS ==========================================================
    /**
     * Metodo factory que crea un objeto con un error
     * @param ErrorException $fault Custom exception
     * @return Entity Instancia de la clase con error
     */
    public static function createErrorInstance(ErrorException $fault);

    /**
     * Metodo que crea una instancia desde un objeto de AVET
     * @param \stdClass $obj Objeto generico con los datos de la instancia
     * @return Entity Instancia de la clase
     */
    public static function newFromAvet(\stdClass $obj);
}

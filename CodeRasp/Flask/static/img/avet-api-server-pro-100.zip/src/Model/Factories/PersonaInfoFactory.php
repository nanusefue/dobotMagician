<?php

namespace App\Model\Factories;

use App\Model\Entities\PersonaInfo as PersonaInfo;
use App\Model\Factories\FactoryInterface as FactoryInterface;
use App\Utils\Error\ErrorException as ErrorException;

class PersonaInfoFactory implements FactoryInterface
{
    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Metodo factory que crea un objeto con un error
     * @param ErrorException $fault Exception
     * @return PersonaInfo Instancia de la clase con error
     */
    public static function createErrorInstance(ErrorException $fault)
    {
        // Create instance
        $instance = new PersonaInfo();
        $instance->setError($fault);

        // Return
        return $instance;
    }

    /**
     * Metodo que crea el objeto PersonaInfo desde un objeto de tipo respuesta
     * @param \stdClass $obj Objeto generico con los datos de la instancia
     * @return PersonaInfo Instancia de la clase
     */
    public static function newFromAvet(\stdClass $obj)
    {
        $instance = new PersonaInfo();

        $instance->setVariable("Apellido1", $obj->Apellido1);
        $instance->setVariable("Apellido2", $obj->Apellido2);
        $instance->setVariable("Ayuntamiento", $obj->Ayuntamiento);
        $instance->setVariable("BIC", $obj->BIC);
        $instance->setVariable("CodigoPostal", $obj->CodigoPostal);
        $instance->setVariable("CodProvincia", $obj->CodProvincia);
        $instance->setVariable("DNI", $obj->DNI);
        $instance->setVariable("DomicilioCalle", $obj->Domicilio_Calle);
        $instance->setVariable("DomicilioCodVia", $obj->Domicilio_CodVia);
        $instance->setVariable("DomicilioEscalera", $obj->Domicilio_Escalera);
        $instance->setVariable("DomicilioNumero", $obj->Domicilio_Numero);
        $instance->setVariable("DomicilioPiso", $obj->Domicilio_Piso);
        $instance->setVariable("Email", $obj->Email);
        $instance->setVariable("Empresa", $obj->Empresa);
        $instance->setVariable("FechaFirma", $obj->FechaFirma);
        $instance->setVariable("FechaNacimiento", $obj->FechaNacimiento);
        $instance->setVariable("IBAN", $obj->IBAN);
        $instance->setVariable("IdPersona", $obj->IdPersona);
        $instance->setVariable("IdProfesion", $obj->IdProfesion);
        $instance->setVariable("LetraNIF", $obj->LetraNIF);
        $instance->setVariable("Localidad", $obj->Localidad);
        $instance->setVariable("Nombre", $obj->Nombre);
        $instance->setVariable("Observaciones", $obj->Observaciones);
        $instance->setVariable("Pais", $obj->Pais);
        $instance->setVariable("Santo", $obj->Santo);
        $instance->setVariable("Sexo", $obj->Sexo);
        $instance->setVariable("Telefono", $obj->Telefono);
        $instance->setVariable("TelefonoFax", $obj->Telefono_Fax);
        $instance->setVariable("TelefonoMovil", $obj->Telefono_Movil);
        $instance->setVariable("TelefonoOficina", $obj->Telefono_Oficina);
        return $instance;
    }
}

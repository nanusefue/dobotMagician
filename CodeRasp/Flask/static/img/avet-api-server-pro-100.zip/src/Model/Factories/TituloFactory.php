<?php

namespace App\Model\Factories;

use App\Model\Entities\Titulo as Titulo;
use App\Model\Factories\FactoryInterface as FactoryInterface;
use App\Utils\Error\ErrorException as ErrorException;

class TituloFactory implements FactoryInterface
{
    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Metodo factory que crea un objeto con un error
     * @param ErrorException $fault Exception
     * @return Titulo Instancia de la clase con error
     */
    public static function createErrorInstance(ErrorException $fault)
    {
        // Create instance
        $instance = new Titulo();
        $instance->setError($fault);

        // Return
        return $instance;
    }

    /**
     * Metodo que crea el objeto SeatStatus desde un objeto de tipo respuesta
     * @param \stdClass $obj Objeto generico con los datos del SeatStatus
     * @return Titulo Instancia de la clase
     */
    public static function newFromAvet(\stdClass $obj)
    {
        // Crear instancia
        $instance = new Titulo();

        // Iniciar atributos
        $instance->setAsiento($obj->Asiento);
        $instance->setFila($obj->Fila);
        $instance->setIdAforo($obj->IdAforo);
        $instance->setIdAsiento($obj->IdAsiento);
        $instance->setIdPeriodicidad($obj->IdPeriodicidad);
        $instance->setIdTipoAbono($obj->IdTipoAbono);
        $instance->setIdZona($obj->IdZona);

        // Set validez
        if (isset($obj->Validez)) {
            $instance->setValidez($obj->Validez);
        }

        // Retornar instancia
        return $instance;
    }
}

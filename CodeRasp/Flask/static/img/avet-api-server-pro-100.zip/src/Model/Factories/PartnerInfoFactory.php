<?php

namespace App\Model\Factories;

use App\Model\Entities\PartnerInfo as PartnerInfo;
use App\Model\Factories\PagoFactory as PagoFactory;
use App\Model\Factories\FactoryInterface as FactoryInterface;
use App\Utils\Error\ErrorException as ErrorException;

class PartnerInfoFactory implements FactoryInterface
{
    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Metodo factory que crea un objeto con un error
     * @param ErrorException $fault Exception
     * @return PartnerInfo Instancia de la clase con error
     */
    public static function createErrorInstance(ErrorException $fault)
    {
        // Create instance
        $instance = new PartnerInfo();
        $instance->setError($fault);

        // Return
        return $instance;
    }

    /**
     * Metodo que crea el objeto PartnerInfo desde un objeto de tipo respuesta
     * @param \stdClass $obj Objeto generico con los datos de la instancia
     * @return PartnerInfo Instancia de la clase
     */
    public static function newFromAvet(\stdClass $obj)
    {
        $instance = new PartnerInfo();

        // Set datos
        $instance->setBaja($obj->Baja);
        $instance->setCuotaSocio($obj->CuotaSocio);
        $instance->setIdEstadoPagoSocio($obj->IdEstadoPagoSocio);
        $instance->setIdPeriodicidadSocio($obj->IdPeriodicidadSocio);
        $instance->setIdTipoSocio($obj->IdTipoSocio);

        $instance->setNumero($obj->Numero);
        $instance->setNumeroAnterior($obj->NumeroAnterior);

        // Set FechaAlta
        $dtm = new \DateTime($obj->FechaAlta);
        $instance->setFechaAlta($dtm);

        // Array de pagos
        if ( !empty($obj->Pagos) ) {

            if ( is_array($obj->Pagos->Pago) ) {
                foreach ($obj->Pagos->Pago as $pago) {
                    $instance->addPago( PagoFactory::newFromAvet($pago) );
                }
            } else if ( get_class($obj->Pagos->Pago) == "stdClass" ) {
                $instance->addPago(PagoFactory::newFromAvet($obj->Pagos->Pago));
            }
        }

        // Set idTitularCuenta
        if (!isset($obj->idTitularCuenta)) {
            $obj->idTitularCuenta = 0;
        }
        $instance->setIdTitularCuenta($obj->idTitularCuenta);

        // Set Referencia
        if (isset($obj->Referencia)) {
            $instance->setReferencia($obj->Referencia);
        }

        // Set ReferenciaAnterior
        if (isset($obj->ReferenciaAnterior)) {
            $instance->setReferenciaAnterior($obj->ReferenciaAnterior);
        }

        // Set Sector
        if (isset($obj->Sector)) {
            $instance->setSector($obj->Sector);
        }

        // Devolver instancia
        return $instance;
    }
}

<?php

namespace App\Model\Factories;

use App\Model\Entities\SeatingArea as SeatingArea;
use App\Model\Factories\FactoryInterface as FactoryInterface;
use App\Utils\Error\ErrorException as ErrorException;

class SeatingAreaFactory implements FactoryInterface
{
    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Metodo factory que crea un objeto con un error
     * @param ErrorException $fault Exception
     * @return SeatingArea Instancia de la clase con error
     */
    public static function createErrorInstance(ErrorException $fault)
    {
        // Create instance
        $seatStatus = new SeatingArea();
        $seatStatus->setError($fault);

        // Return
        return $seatStatus;
    }

    /**
     * Metodo que crea el objeto SeatStatus desde un objeto de tipo respuesta
     * @param \stdClass $obj Objeto generico con los datos del SeatStatus
     * @return SeatingArea Instancia de la clase
     */
    public static function newFromAvet(\stdClass $obj)
    {
        // Crear instancia
        $instance = new SeatingArea();

        // Iniciar atributos
        $instance->setGate($obj->Gate);
        $instance->setIdArea($obj->IdArea);
        $instance->setIdSeat($obj->IdSeat);
        $instance->setPosRow($obj->PosRow);
        $instance->setPosSeat($obj->PosSeat);
        $instance->setRow($obj->Row);
        $instance->setSeat($obj->Seat);
        $instance->setVomitorio($obj->Vomitorio);

        // Retornar instancia
        return $instance;
    }
}

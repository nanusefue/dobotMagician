<?php

namespace App\Model\Factories;

use App\Model\Entities\RolPartnerInfo as RolPartnerInfo;
use App\Model\Factories\FactoryInterface as FactoryInterface;
use App\Utils\Error\ErrorException as ErrorException;

class RolPartnerInfoFactory implements FactoryInterface
{
    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Metodo factory que crea un objeto con un error
     * @param ErrorException $fault Exception
     * @return RolPartnerInfo Instancia de la clase con error
     */
    public static function createErrorInstance(ErrorException $fault)
    {
        // Create instance
        $instance = new RolPartnerInfo();
        $instance->setError($fault);

        // Return
        return $instance;
    }

    /**
     * Metodo que crea el objeto RolPartnerInfo desde un objeto de tipo respuesta
     * @param stdClass $obj Objeto generico con los datos de la instancia
     * @return RolPartnerInfo Instancia de la clase
     */
    public static function newFromAvet(\stdClass $obj)
    {
        // Crear instancia
        $instance = new RolPartnerInfo();

        // Iniciar atributos
        $instance->setIdTipo($obj->IdTipo);
        $instance->setNombre($obj->Nombre);

        // Retornar instancia
        return $instance;
    }
}

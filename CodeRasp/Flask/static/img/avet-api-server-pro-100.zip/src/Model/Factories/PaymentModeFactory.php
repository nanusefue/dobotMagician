<?php

namespace App\Model\Factories;

use App\Model\Entities\PaymentMode as PaymentMode;
use App\Model\Factories\FactoryInterface as FactoryInterface;
use App\Utils\Error\ErrorException as ErrorException;

class PaymentModeFactory implements FactoryInterface
{
    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Metodo factory que crea un objeto con un error
     * @param ErrorException $fault Exception
     * @return PaymentMode Instancia de la clase con error
     */
    public static function createErrorInstance(ErrorException $fault)
    {
        $instance = new PaymentMode();
        $instance->setError($fault);
        return $instance;
    }

    /**
     * Metodo que crea el objeto PaymentMode desde un objeto de tipo respuesta
     * @param \stdClass $obj Objeto generico con los datos de la instancia
     * @return PaymentMode Instancia de la clase
     */
    public static function newFromAvet(\stdClass $obj)
    {
        // Crear instancia
        $instance = new PaymentMode();

        // Iniciar atributos
        $instance->setIdModoCobro($obj->IdModoCobro);
        $instance->setModoCobro($obj->ModoCobro);

        // Retornar instancia
        return $instance;
    }
}

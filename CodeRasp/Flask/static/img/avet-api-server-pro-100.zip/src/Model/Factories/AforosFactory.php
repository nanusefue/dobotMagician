<?php

namespace App\Model\Factories;

use App\Model\Entities\Aforo as Aforo;
use App\Model\Factories\FactoryInterface as FactoryInterface;
use App\Utils\Error\ErrorException as ErrorException;

class AforosFactory implements FactoryInterface
{
    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Metodo factory que crea un objeto con un error
     * @param ErrorException $fault Exception
     * @return Aforo Instancia de la clase con error
     */
    public static function createErrorInstance(ErrorException $fault)
    {
        // Create instance
        $instance = new Aforo();
        $instance->setError($fault);

        // Return
        return $instance;
    }

    /**
     * Metodo que crea una instancia desde un objeto de AVET
     * @param \stdClass $obj Objeto generico con los datos de la instancia
     * @return Aforo Instancia de la clase
     */
    public static function newFromAvet(\stdClass $obj)
    {
        // Crear AreaAvailability
        $instance = new Aforo();

        // Iniciar atributos
        $instance->setDescription($obj->Description);
        $instance->setIdAforo($obj->IdAforo);

        // Retornar instancia
        return $instance;
    }
}

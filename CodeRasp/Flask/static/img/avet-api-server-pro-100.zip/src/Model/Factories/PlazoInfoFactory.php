<?php

namespace App\Model\Factories;

use App\Model\Entities\PlazoInfo as PlazoInfo;
use App\Model\Factories\FactoryInterface as FactoryInterface;
use App\Utils\Error\ErrorException as ErrorException;

class PlazoInfoFactory implements FactoryInterface
{
    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Metodo factory que crea un objeto con un error
     * @param ErrorException $fault Exception
     * @return PlazoInfo Instancia de la clase con error
     */
    public static function createErrorInstance(ErrorException $fault)
    {
        // Create instance
        $instance = new PlazoInfo();
        $instance->setError($fault);

        // Return
        return $instance;
    }

    /**
     * Metodo que crea el objeto PlazoInfo desde un objeto de tipo respuesta
     * @param \stdClass $obj Objeto generico con los datos de la instancia
     * @return PlazoInfo Instancia de la clase
     */
    public static function newFromAvet(\stdClass $obj)
    {
        // Crear AreaAvailability
        $instance = new PlazoInfo();

        // Iniciar atributos
        $instance->setIdPeriodicidad($obj->IdPeriodicidad);
        $instance->setIdPlazo($obj->IdPlazo);
        $instance->setPeriodicidad($obj->Periodicidad);
        $instance->setPlazo($obj->Plazo);

        // DateUpdate a DateTime
        $dtm = new \DateTime($obj->Fecha);
        $instance->setFecha($dtm);

        // Retornar instancia
        return $instance;
    }
}

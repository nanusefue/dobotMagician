<?php

namespace App\Model\Factories;

use App\Model\Entities\MotivoEmision as MotivoEmision;
use App\Model\Factories\FactoryInterface as FactoryInterface;
use App\Utils\Error\ErrorException as ErrorException;

class MotivoEmisionFactory implements FactoryInterface
{
    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Metodo factory que crea un objeto con un error
     * @param ErrorException $fault Exception
     * @return MotivoEmision Instancia de la clase con error
     */
    public static function createErrorInstance(ErrorException $fault)
    {
        // Create instance
        $instance = new MotivoEmision();
        $instance->setError($fault);

        // Return
        return $instance;
    }

    /**
     * Metodo que crea una instancia desde un objeto de AVET
     * @param \stdClass $obj Objeto generico con los datos de la instancia
     * @return MotivoEmision Instancia de la clase
     */
    public static function newFromAvet(\stdClass $obj)
    {
        // Crear AreaAvailability
        $instance = new MotivoEmision();

        // Iniciar atributos
        $instance->setDescripcion($obj->Descripcion);
        $instance->setIdMotivo($obj->IdMotivo);

        // Retornar instancia
        return $instance;
    }
}

<?php

namespace App\Model\Factories;

use App\Model\Entities\PartnerOperation as PartnerOperation;
use App\Model\Factories\PartnerFactory as PartnerFactory;
use App\Model\Factories\FactoryInterface as FactoryInterface;
use App\Utils\Error\ErrorException as ErrorException;

class PartnerOperationFactory implements FactoryInterface
{
    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Metodo factory que crea un objeto con un error
     * @param ErrorException $fault Exception
     * @return PartnerOperation Instancia de la clase con error
     */
    public static function createErrorInstance(ErrorException $fault)
    {
        // Create instance
        $partnerOp = new PartnerOperation();
        $partnerOp->setError($fault);

        // Return
        return $partnerOp;
    }

    /**
     * Metodo factory que crea el objeto a traves de un CreatePartnerResult
     * @param \stdClass $obj Resultado de la operacion de creacion de usuario
     * @return PartnerOperation Instancia de la clase
     */
    public static function newFromAvet(\stdClass $obj)
    {
        // Create instance
        $partnerOp = new PartnerOperation();

        // Init attributes
        $partnerOp->setIdOperation($obj->IdOperation);
        $partnerOp->setFxUpdate($obj->FxUpdate);

        // Init partner
        $partner = PartnerFactory::newFromAvet($obj->Partner);
        $partnerOp->setPartner($partner);

        // Return
        return $partnerOp;
    }
}

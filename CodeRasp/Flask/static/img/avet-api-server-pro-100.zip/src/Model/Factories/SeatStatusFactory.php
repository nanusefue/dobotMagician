<?php

namespace App\Model\Factories;

use App\Model\Entities\SeatStatus as SeatStatus;
use App\Model\Factories\FactoryInterface as FactoryInterface;
use App\Utils\Error\ErrorException as ErrorException;

class SeatStatusFactory implements FactoryInterface
{
    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Metodo factory que crea un objeto con un error
     * @param ErrorException $fault Exception
     * @return SeatStatus Instancia de la clase con error
     */
    public static function createErrorInstance(ErrorException $fault)
    {
        // Create instance
        $seatStatus = new SeatStatus();
        $seatStatus->setError($fault);

        // Return
        return $seatStatus;
    }

    /**
     * Metodo que crea el objeto SeatStatus desde un objeto de tipo respuesta
     *
     * @param \stdClass $obj Objeto generico con los datos de la instancia
     *
     * @return SeatStatus Instancia de la clase
     */
    public static function newFromAvet(\stdClass $obj)
    {
        // Crear instancia
        $instance = new SeatStatus();

        // Iniciar atributos
        $instance->setEstado($obj->Estado);
        $instance->setIdSeat($obj->IdSeat);

        // Retornar instancia
        return $instance;
    }
}

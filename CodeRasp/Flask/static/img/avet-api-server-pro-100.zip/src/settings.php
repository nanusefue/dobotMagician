<?php
return [
    'deploy' => [
        'url' => '10.9.201.5', //todo change url
        'subscriber_prefix' => '/WCF'
    ],

    'settings' => [
        'displayErrorDetails' => true, // set to false in production
        'addContentLengthHeader' => false, // Allow the web server to send the content-length header

        // Redis cache settings
        'redis' => [
            'scheme' => 'tcp',
            'host' => 'avet-eu-west-1.4sxnz6.0001.euw1.cache.amazonaws.com',
            'port' => 6379,
            'token_ttl' => 420,
            'refresh_ttl' => 840
        ],
        'payment'=>[
            'caixafin'=>[
                //FINANCIACIÓN
                'establecimiento' => "46672002",
                'key' => "5gz5m5bd7pzkswfsa6nzrgucg452v8zmpyfz",
                'formURL' => "https://finonline.caixabankconsumer.com/finonline/espanyol/solicitud-alta",
                'tarsURL' => "https://finonline.caixabankconsumer.com/finonline-calculadora/calculartarifa"
            ],
            'redsys'=>[
                //TPV
                'fuc' => '072366958',
                'terminal' => '001',
                'moneda' => '978',
                'trans' => '0',
                'version' => "HMAC_SHA256_V1",
                'kc' => "8yiZRkJduO2SWeLQ10mwBASqNeglgHUo",
                'formURL' => "https://sis.redsys.es/sis/realizarPago",
                "responseURL"=>"http://" . $_SERVER['HTTP_HOST'] . "/payment/response/redsystpv",
                "okURL"=>"http://3ddigitalvenue.com/ok",
                "koURL"=>"http://3ddigitalvenue.com/ko"
            ]
        ],
        's3'=>[
            "bucket"=>"pro-avetstatic-eu-west-1",
            "bucket_client"=>"rcde"
        ],
        'avet' => [
            'protocol' => 'http://',
            'uri' => '10.9.201.5',
            'port' => '60000',
            'subscriberPrefix' => '',
            'services' => [
                'SubscriberOperations' => '/SubscriberOperations/SubscriberOperationsService.svc?wsdl',
                'VenueConfiguration' => '/VenueConfiguration/VenueConfigurationService.svc?wsdl'
            ],
            'idPaymentMode'=>[
                'fin'=>18,
                'tarjeta'=>2
            ],
            'IdMotivoEmision'=>[
                'alta'=>7,
                'renovacion'=>32
            ]
        ],
        'email'=>[
            'smtpdebug' => 0,
            'host' => 'smtp.gmail.com',
            'username' => 'abonamentsrcdespanyol@gmail.com',
            'password' => 'RCD3SP4NY0L',
            'smtpauth' => true,
            'smtpsecure' => 'tls',
            'port' => 587,
            'clubto' => ["altes@rcdespanyol.com"],
            'mmc'=>["gabriel@mobilemediacontent.com","isidro@mobilemediacontent.com"],
            'from' => "abonaments@rcdespanyol.com",
            'fromname' => "Confirmación de abono"
        ],
        'client'=>[
            'slug'=>'RCDE'
        ]
    ]
];

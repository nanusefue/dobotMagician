<?php

namespace App\Controller;

use App\Controller\Controller as Controller;
use App\Utils\Cache\RedisClient as RedisClient;

class ClientController extends Controller
{
    // MAGIC FUNCTIONS =========================================================
    public $access;
    public $redis;
    public $slug;

    /**
     * Class constructor
     * @param \SoapClient $soapclient SOAP client
     * @return void
     */
    public function __construct(Array $clientsettings, Array $redissettings)
    {
    	$slug = $clientsettings['slug'];
        $this->redis = new RedisClient($redissettings);
        //$this->redis->del('access');
        $this->access = json_decode($this->redis->getData('access'));
        if(!$this->access){
        	$this->redis->setDataPerm('access',file_get_contents(__DIR__ . '/../Utils/Client/'.$slug.'/files/access.json'));
	        $this->access = json_decode($this->redis->getData('access'));
        }
    }

    private function getByKey($key){
    	$access = json_decode($this->access,true);
    	if (isset($access[$key])){
    		return $access[$key];
    	}
    }

    //return data to send avet login
    public function login($data){

        if(strlen($data['pin'])==4){
            //remove this if
            /*if (isset($data['numSocio'])){
                $data['idPersona']=$data['numSocio'];
                unset($data['numSocio']);
            }*/
            return $data;
        }

    	$key_input = $data['idPersona'];
    	$data_input = $data['pin'];
    	$d = $this->getByKey($data['idPersona']);
    	if($d['Fecha Nacimiento']==$data_input && $key_input == $d['Clave Unica']){
    		$res = ['idPersona'=>$key_input,"pin"=>$d['PIN']];
    		return $res;
    	}

    	return $data;
    }
}
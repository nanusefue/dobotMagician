<?php

namespace App\Controller;

use App\Utils\Cache\RedisClient as RedisClient;
use App\Controller\Controller as Controller;
use App\Controller\PartnerController as PartnerController;
use App\Model\Repositories\PartnerOpRepository as PartnerOpRepository;
use tasr\redsys\RedsysAPI;

class PartnerOpController extends Controller
{
    // PUBLIC VARS =============================================================
    /**
     * Redis client
     * @var PredisClient $redis
     */
    public $redis;

    public $S3;

    // MAGIC FUNCTIONS =========================================================
    /**
     * Class constructor
     * @param \SoapClient $soapclient SOAP client
     * @param PredisClient $redis Redis client
     * @return void
     */
    public function __construct(\SoapClient $soapclient, RedisClient $redis)
    {
        $this->PartnerOp = new PartnerOpRepository($soapclient);
        $this->redis = $redis;
    }

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Creates a new partnerOperation
     * @param array $data Partner data, only personaInfo data
     * @return array
     */
    public function add(array $data) : array
    {
        $opt = [
            "partner" => $data,
            "fxChannel" => $this->now()
        ];
        $partnerOp = $this->PartnerOp->add($opt);
        if ($partnerOp->isError()) {
            $this->setCode(400);
            return ["message" => $partnerOp->getErrorException()->getMessage()];
        }

        return $partnerOp->toArray();
    }

    /**
     * Confirm a partnerOperation
     * @param string $idOperation PartnerOperation identifier
     * @param int $idPaymentMode PaymentMode identifier
     * @param int $idMotivoEmision MotivoEmision identifier
     * @return array
     */
    public function confirm(string $idOperation, int $idPayment, int $idMotivoEmision) : array
    {
        $opt = [
            "idOperation" => $idOperation,
            "idPaymentMode" => $idPayment,
            "idMotivoEmision" => $idMotivoEmision,
            "fxChannel" => $this->now()
        ];
        $partnerOp = $this->PartnerOp->confirm($opt);
        if ($partnerOp->isError()) {
            $this->setCode(400);
            return ["message" => $partnerOp->getError()->getMessage()];
        }

        return $partnerOp->toArray();
    }

    /**
     * PreConfirm a partnerOperation
     * @param string $idOperation PartnerOperation identifier
     * @return array
     */
    public function preconfirm(string $idOperation)
    {
        $opt = [
            "idOperation" => $idOperation,
            "fxChannel" => $this->now()
        ];

        $partnerOp = $this->PartnerOp->preconfirm($opt);
        /*if ($partnerOp->isError()) {
            $this->setCode(400);
            return ["message" => $partnerOp->getError()->getMessage()];
        }*/

        return $partnerOp;
    }

    /**
     * Cancels a partnerOperation
     * @param string $idOperation PartnerOperation identifier
     * @return array
     */
    public function delete(string $idOperation) : array
    {
        $opt = [
            "idOperation" => $idOperation,
            "fxChannel" => $this->now()
        ];
        $partnerOp = $this->PartnerOp->delete($opt);
        if ($partnerOp->isError()) {
            $this->setCode(400);
            return ["message" => $partnerOp->getError()->getMessage()];
        }

        return $partnerOp->toArray();
    }

    /**
     * Edits a partnerOperation
     * @param string $data PartnerOperation in array format
     * @return array PartnerOperation in array format
     */
    public function edit(array $data) : array
    {
        $opt = [
            "fxChannel" => $this->now(),
            "partnerOperation" => $data
        ];
        $partnerOp = $this->PartnerOp->edit($opt);
        if ($partnerOp->isError()) {
            $this->setCode(400);
            return ["message" => $partnerOp->getError()->getMessage()];
        }
        return $partnerOp->toArray();
    }

    /**
     * Edits the titulo of the partner in the transaction partnerOperation
     * @param string $data Titulo in array format
     * @return array PartnerOperation in array format
     */
    public function editSeat(string $idOperation, array $data) : array
    {
        $opt = [
            "fxChannel" => $this->now(),
            "idOperation" => $idOperation,
            "titulo" => $data
        ];
        $partnerOp = $this->PartnerOp->editSeat($opt);
        if ($partnerOp->isError()) {
            $this->setCode(400);
            return ["message" => $partnerOp->getError()->getMessage()];
        }
        return $partnerOp->toArray();
    }

    /**
     * Login partner
     * @param array $opt Login options
     * @return array Logged partnerOperation or error message
     */
    public function login($opt) : array
    {
        // Get partner
        $opt["fxChannel"] = $this->now();
        $partnerOp = $this->PartnerOp->find($opt);

        if ($partnerOp->isError()) {
            $this->setCode(401);
            return ["message" => $partnerOp->getError()->getMessage()];
        }

        // Prepare data
        $poArray = $partnerOp->toArray();

        // Return array
        return [
            "PartnerOperation" => $poArray,
            "token" => $this->redis->token($poArray),
            "refreshToken" => $this->redis->refresh($poArray),
            "ttl" => $this->redis->tokenTtl
        ];
    }

    public function forgot(string $email)
    {
        $opt = [
            "eMail" => $email,
            "fxChannel" => $this->now()
        ];
        return $this->PartnerOp->findByEmail($opt);
    }

    /**
     * Get new token credentials
     * @param string $refreshToken
     * @return array
     */
    public function refreshCredentials(string $refreshToken)
    {
        $partnerString = $this->redis->get($refreshToken);

        if (!$partnerString) {
            $this->setCode(401);
            return [ "message" => "Expired token" ];
        }

        // Prepare data
        $poArray = json_decode($partnerString, true);

        // Mount result
        $partnerOp = [
            "PartnerOperation" => $poArray,
            "token" => $this->redis->token($poArray),
            "refreshToken" => $this->redis->refresh($poArray),
            "ttl" => $this->redis->tokenTtl
        ];

        return $partnerOp;
    }


    


}

?>

<?php

namespace App\Controller;

use App\Controller\Controller as Controller;
use App\Model\Repositories\ProductsRepository as ProductsRepository;

class ProductsController extends Controller
{
    // MAGIC FUNCTIONS =========================================================
    /**
     * Class constructor
     * @param \SoapClient $soapclient SOAP client
     * @return void
     */
    public function __construct(\SoapClient $soapclient)
    {
        $this->Products = new ProductsRepository($soapclient);
    }

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Finds products
     * @param int $idAforo Aforo unique identifier
     * @return array Products list
     */
    public function find(int $idAforo) : array
    {
        $opt = [ "idAforo" => $idAforo ];
        $collection = $this->Products->find($opt);
        return $this->collectionToArray($collection);
    }
}

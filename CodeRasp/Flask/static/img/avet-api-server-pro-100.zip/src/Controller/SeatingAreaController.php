<?php

namespace App\Controller;

use App\Controller\Controller as Controller;
use App\Model\Repositories\SeatingAreaRepository as SeatingAreaRepository;

class SeatingAreaController extends Controller
{
    // MAGIC FUNCTIONS =========================================================
    /**
     * Class constructor
     * @param \SoapClient $soapclient SOAP client
     * @return void
     */
    public function __construct(\SoapClient $soapclient)
    {
        $this->SeatingArea = new SeatingAreaRepository($soapclient);
    }

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Get seats by aforo and area
     * @param int $idAforo Aforo unique identifier
     * @param int $idArea Area unique identifier
     * @return array SeatingAreas list
     */
    public function find(int $idAforo, int $idArea) : array
    {
        $opt = [
            "idAforo" => $idAforo,
            "id_area" => $idArea,
            "fxChannel" => $this->now()
        ];
        $collection = $this->SeatingArea->find($opt);
        return $this->collectionToArray($collection);
    }
}

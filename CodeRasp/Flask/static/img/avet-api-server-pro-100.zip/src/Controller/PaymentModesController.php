<?php

namespace App\Controller;

use App\Controller\Controller as Controller;
use App\Model\Repositories\PaymentModesRepository as PaymentModesRepository;

class PaymentModesController extends Controller
{
    // MAGIC FUNCTIONS =========================================================
    /**
     * Class constructor
     * @param \SoapClient $soapclient SOAP client
     * @return void
     */
    public function __construct(\SoapClient $soapclient)
    {
        $this->PaymentModes = new PaymentModesRepository($soapclient);
    }

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Finds payment modes
     * @return array PaymentModes list
     */
    public function find() : array
    {
        $collection = $this->PaymentModes->find([]);
        return $this->collectionToArray($collection);
    }
}

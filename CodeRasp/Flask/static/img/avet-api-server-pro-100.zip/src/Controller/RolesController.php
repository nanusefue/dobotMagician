<?php

namespace App\Controller;

use App\Controller\Controller as Controller;
use App\Model\Repositories\RolesRepository as RolesRepository;

class RolesController extends Controller
{
    // MAGIC FUNCTIONS =========================================================
    /**
     * Class constructor
     * @param \SoapClient $soapclient SOAP client
     * @return void
     */
    public function __construct(\SoapClient $soapclient)
    {
        $this->Roles = new RolesRepository($soapclient);
    }

    // PUBLIC FUNCTIONS ============================================================
    /**
     * Finds roles
     * @param int $idAforo Aforo unique identifier
     * @return array Roles list
     */
    public function find(int $idAforo) : array
    {
        $opt = [ "idAforo" => $idAforo ];
        $collection = $this->Roles->find($opt);
        return $this->collectionToArray($collection);
    }
}

<?php

namespace App\Controller;

use App\Controller\Controller as Controller;
use App\Model\Repositories\PlazosRepository as PlazosRepository;

class PlazosController extends Controller
{
    // MAGIC FUNCTIONS =========================================================
    /**
     * Class constructor
     * @param \SoapClient $soapclient SOAP client
     * @return void
     */
    public function __construct(\SoapClient $soapclient)
    {
        $this->Plazos =  new PlazosRepository($soapclient);
    }

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Finds plazos
     * @return array Plazos list
     */
    public function find() : array
    {
        $collection = $this->Plazos->find([]);
        return $this->collectionToArray($collection);
    }
}

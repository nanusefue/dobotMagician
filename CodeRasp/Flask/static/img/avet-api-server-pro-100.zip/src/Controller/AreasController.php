<?php

namespace App\Controller;

use App\Controller\Controller as Controller;
use App\Model\Repositories\AreaAvailabilitiesRepository as AreaAvailabilitiesRepository;

class AreasController extends Controller
{
    // MAGIC FUNCTIONS =========================================================
    /**
     * Class constructor
     * @param \SoapClient $soapclient SOAP client
     * @return void
     */
    public function __construct(\SoapClient $soapclient)
    {
        $this->AreaAvailabilities = new AreaAvailabilitiesRepository($soapclient);
    }

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Finds areas by Aforo
     * @return array Areas list
     */
    public function find(int $idAforo) : array
    {
        $opt = [
            "idAforo" => $idAforo,
            "fxChannel" => $this->now()
        ];
        $collection = $this->AreaAvailabilities->find($opt);
        return $this->collectionToArray($collection);
    }
}

<?php

namespace App\Controller;

use App\Controller\Controller as Controller;
use App\Model\Repositories\SeatStatusRepository as SeatStatusRepository;

class SeatStatusController extends Controller
{
    // MAGIC FUNCTIONS =========================================================
    /**
     * Class constructor
     * @param \SoapClient $soapclient SOAP client
     * @return void
     */
    public function __construct(\SoapClient $soapclient)
    {
        $this->SeatStatus =  new SeatStatusRepository($soapclient);
    }

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Get seat availability by aforo and area
     * @param int $idAforo Aforo unique identifier
     * @param int $idArea Area unique identifier
     * @return array SeatStatus list
     */
    public function find(int $idAforo, int $idArea) : array
    {
        $opt = [
            "idAforo" => $idAforo,
            "idArea" => $idArea,
            "fxChannel" => $this->now()
        ];
        $collection = $this->SeatStatus->find($opt);
        return $this->collectionToArray($collection);
    }
}

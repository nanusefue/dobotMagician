<?php

namespace App\Controller;

use App\Controller\Controller as Controller;
use App\Controller\PartnerOpController as PartnerOpController;

use tasr\redsys\RedsysAPI;
use App\Utils\AWS\S3 as S3;
use App\Utils\Mailer as Mailer;

class PaymentController extends Controller
{

    // MAGIC FUNCTIONS =========================================================
    public $redsys;
    //S3
    public $S3;
    public $s3_client; //primera carpeta de dentro del bucket de s3

    public $mailer;
    public $mailer_to;
    public $mailer_mmcsupport;

    //Financiación    
    public $fin_establecimiento;
    public $fin_key;
    public $fin_formURL;
    public $fin_tarsURL;
    //TPV
    public $tpv_fuc;
    public $tpv_terminal;
    public $tpv_moneda;
    public $tpv_trans;
    public $tpv_responseURL;
    public $tpv_okURL;
    public $tpv_koURL;
    public $tpv_version;
    public $tpv_kc;
    public $tpv_formURL;
    
    //AVET
    public $PartnerOp;
    public $avet_finid;
    public $avet_tarjid;
    public $avet_altaid;
    public $avet_renid;

    /**
     * Class constructor
     * @param \SoapClient $soapclient SOAP client
     * @param PredisClient $redis Redis client
     * @return void
     */
    public function __construct(Array $paymentsettings, Array $posettings, Array $s3settings, Array $emailsettings, Array $avetsettings ){
        //S3
        $this->S3 = new S3($s3settings);
        $this->s3_client = $s3settings['bucket_client'];
        //PHPMailer
        $this->mailer = new Mailer($emailsettings);
        $this->mailer_to = $emailsettings['clubto'];
        $this->mailer_mmcsupport = $emailsettings['mmc'];

        //FINANCIACIÓN
        $this->fin_establecimiento = $paymentsettings['caixafin']['establecimiento'];
        $this->fin_key = $paymentsettings['caixafin']['key'];
        $this->fin_formURL = $paymentsettings['caixafin']['formURL'];
        $this->fin_tarsURL = $paymentsettings['caixafin']['tarsURL'];

        //TPV
        $this->redsys = new RedsysAPI;
        $this->tpv_fuc = $paymentsettings['redsys']['fuc'];
        $this->tpv_terminal = $paymentsettings['redsys']['terminal'];
        $this->tpv_moneda = $paymentsettings['redsys']['moneda'];
        $this->tpv_trans = $paymentsettings['redsys']['trans'];
        $this->tpv_version = $paymentsettings['redsys']['version'];
        $this->tpv_kc = $paymentsettings['redsys']['kc'];
        $this->tpv_formURL = $paymentsettings['redsys']['formURL'];
        $this->tpv_responseURL = $paymentsettings['redsys']['responseURL'];
        $this->tpv_okURL = $paymentsettings['redsys']['okURL'];
        $this->tpv_koURL = $paymentsettings['redsys']['koURL'];

        $this->PartnerOp = new PartnerOpController($posettings['soap'],$posettings['redys']);

        $this->avet_finid = $avetsettings['idPaymentMode']['fin'];
        $this->avet_tarjid = $avetsettings['idPaymentMode']['tarjeta'];
        $this->avet_altaid = $avetsettings['IdMotivoEmision']['alta'];
        $this->avet_renid = $avetsettings['IdMotivoEmision']['renovacion'];

    }


    private function amountSet($amount){
        if(isset($amount)){
            $amount = str_replace(",",".",$amount);
            $amount = intval(floatval($amount) * 100);
        }
        return $amount;
    }

    private function AvetConfirm($order){
        $id_payment = intval($order['data']['idPaymentMode']);
        $id_motivo = intval($order['data']['IdMotivoEmision']);
        $pop = $order['data']['partneroperation'];
        $npops = count($order['data']['partneroperation']);
        $err = 0;
        foreach($pop as $p){
            $c = $this->PartnerOp->confirm($p,$id_payment,$id_motivo);
            if(isset($c['message'])){
                $err ++;
                $this->createInc($order,$c['message']);
            }
        }
        return $err;
    }

    private function AvetCancel($order){
        $pop = $order['data']['partneroperation'];
        $err = [];
        foreach($pop as $p){
            $err[] = $this->PartnerOp->delete($p);
        }
        return $err;
    }
    private function amountCheck($amount){
        $minamount  = 60*100;
        if($amount<$minamount || strlen($amount)>6){
            return false;
        }
        return true;
    }

    private function cleanData($data){
        $clean  = $data;
        if(isset($data['numdoc'])){
            $clean['numdoc'] = str_replace(' ', '', $clean['numdoc']);
            $clean['numdoc'] = str_replace('-', '', $clean['numdoc']);
        }
        return $clean;
    }


    private function createLocalFile($filepath,$data){
        $fp = fopen($filepath, 'w');
        fwrite($fp, json_encode($data));
        fclose($fp);
        return true;
    }

    private function createLocalImage($filepath,$data){
        $fp = fopen($filepath, 'w');
        fwrite($fp,$data);
        fclose($fp);
        
        return true;
    }

    private function createInc($data,$error_message){
        $type = $data['type'];
        $dni = $data['dni'];

        $local_file = '/tmp/inc-'.$this->getToken(4)."-".$dni."-".date("Y-m-d_h:i:s").'.json';
        $data['error_msg']=$error_message;
        $this->createLocalFile($local_file,$data);

        $keyname = $this->s3_client."/".date("Y")."/".$type."/".$dni."/errors/".$this->getToken(4)."_".date("Y-m-d_h:i:s").".json";
        $this->S3->putObject($keyname, $local_file,'application/json');
        return true;
    }

    private function createLog($data){
        //Create DATA JSON
        $filename = "error.json";
        $local_file = '/tmp/error-'.$this->getToken(4)."-".date("Y-m-d_h:i:s").'.json';
        $this->createLocalFile($local_file,$data);

        $keyname = $this->s3_client."/".date("Y")."/logs/error-".$this->getToken(6)."_".date("Y-m-d_h:i:s").".json";
        $this->S3->putObject($keyname, $local_file,'application/json');
    }

    private function createOrder($data,$type){
        $dni = $data['numdoc'];
        $dnicut = substr($dni, -4); 
        $order_id = $this->getToken(5)."-".$dnicut;

        $year = date("Y");
        $url = $this->s3_client."/".$year."/".$type."/".$dni."/orders/".$order_id.".json";

        $order = array(
            "id"=>$order_id,
            "date"=>[
                'created'=>date("Y-m-d h:i:s"),
                'modified'=>date("Y-m-d h:i:s")],
            "status"=>"pending",
            'type'=>$type,
            'dni'=>$data['numdoc'],
            'data'=>array_change_key_case($data['abono']),
            'url'=>$url);

        $filename = $order_id.'.json';
        $local_file = '/tmp/'.$filename;
        $this->createLocalFile($local_file,$order);

        $path = $this->getAWSPath($type,$dni,'orders').$filename;
        $this->S3->putObject($path, $local_file,'application/json',true);
        $sql_path = $this->s3_client."/".date("Y")."/sql/orders/".$order_id.".json";
        $this->S3->putObject($sql_path, $local_file,'application/json');

        return $order;
    }

    private function crypto_rand_secure($min, $max)
    {
        $range = $max - $min;
        if ($range < 1) return $min; // not so random...
        $log = ceil(log($range, 2));
        $bytes = (int) ($log / 8) + 1; // length in bytes
        $bits = (int) $log + 1; // length in bits
        $filter = (int) (1 << $bits) - 1; // set all lower bits to 1
        do {
            $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
            $rnd = $rnd & $filter; // discard irrelevant bits
        } while ($rnd > $range);
        return $min + $rnd;
    }

    private function getAWSPath($order_type=null,$dni=null,$detail=null){

        $paths = array("alta"=>"/alta/","renovacion"=>"/renovacion/");

        if(isset($paths[$order_type]) && isset($dni)){
            $path = $this->s3_client."/".date("Y").$paths[$order_type].$dni."/";
            if(isset($detail)){
                $path = $path.$detail."/";
            }
            return $path;
        }
        return null;
    }

    private function getEmailClubBody($user,$order){

        $extras = [];
        if (isset($order['data']['femenino'])) $extras[]="Femenino";
        if (isset($order['data']['parking'])) $extras[]="Parking";

        switch($order['data']['method']){
            case 1 :
                $order['data']['method'] = 'Financiación';
                break;
            default:
                $order['data']['method'] = 'Tarjeta de crédito / débito';
                break;
        }
        //RSC
        $logo = "https://www.rcdespanyol.com/img/common/large/rcde_img_logotip.png";
        //CSS
        $td_css = "font-family: Arial, sans-serif; font-size: 14pt; line-height: 20px; padding: 7px 5px;";
        $dark = 'color:#5FA1BF;';
        $gray = 'color:#666;';
        $light = 'color:#343580;';
        $b_bottom_css = "border-bottom: 1px solid #ccc;";
        $b_top_css = "border-top: 1px solid #ccc;";
        $l_font = "font-size:10pt;";
        $m_font = "font-size:12pt;";
        $b_font = "font-size:18pt;";
        $upper = "text-transform:uppercase;";
        $cap = "text-transform:capitalize;";
        $bold = "font-weight:bold;";
        $m_line_h = 'line-height:14pt;';

        $first_l_td_css = $dark.$td_css.$b_bottom_css.$b_top_css.$l_font.$upper;
        $first_r_td_css = $light.$td_css.$b_bottom_css.$b_top_css.$m_font.$bold;
        $left_td_css = $dark.$td_css.$b_bottom_css.$l_font.$upper;
        $right_td_css = $light.$td_css.$b_bottom_css.$m_font.$bold;

        $footer = $light.$td_css.$l_font.$gray.$m_line_h;
        $body = "<table cellpadding='0' cellspacing='0' width='100%'>
            <tr>
            <td>
                <table cellpadding='0' cellspacing='0' width='600' style='color:#343580'>
                    <tr>
                        <td style='padding: 10px; background-color:#002543' align='center'>
                            <div style='float:left'>
                                <img src='".$logo."' style='height:50px' alt='logo'/>
                            </div>
                            <div style='float:right'>
                                <span style='color:#fff; font-family: Arial, sans-serif;  font-size: 10pt; font-weight: bold;margin-top:25px;display: block;'>CAMPAÑA DE ABONADOS 18/19</span>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style='padding: 10px;'>
                            <table cellpadding='0' cellspacing='0' width='100%'>
                                <tr>
                                    <td style='".$light.$td_css.$b_font.$bold."' align='center'>
                                        NUEVA CONFIRMACIÓN DE ABONO<br><br>
                                    </td>
                                </tr>
                                <tr>
                                    <td style='".$td_css.$light.$m_font.$upper."' align='left'>
                                        Datos del socio confirmado
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table cellpadding='0' cellspacing='0' width='100%'>

                                            <tr>
                                                <td style='".$first_l_td_css."' align='right'>
                                                   ID de pedido:
                                                </td>
                                                <td style='".$first_r_td_css."' align='left'>
                                                    <span>".$order['id']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                   Fecha:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['date']['modified']."</span>
                                                </td>
                                            </tr>
                                            <tr >
                                                <td style='".$left_td_css."' align='right'>
                                                    Tipo de usuario:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span style='".$cap."'>".$order['type']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    DNI:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$user['numdoc'].$user['numdocl']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Nombre completo:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$user['nombre']." ".$user['apellido1']." ".$user['apellido2']."</span>
                                                </td>
                                            </tr>
                                            <tr >
                                                <td style='".$left_td_css."' align='right'>
                                                    Tipo de abono:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['data']['tipo']."</span>
                                                </td>
                                            </tr>

                                            <tr>
                                               <td style='".$left_td_css."' align='right'>
                                                    Asiento seleccionado
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>
                                                        Sector: ".$order['data']['block']."<br>
                                                        Fila : ".$order['data']['row']."<br>
                                                        Asiento : ".$order['data']['seat']."
                                                    </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Envío del abono:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span style='".$cap."'>".$order['data']['envio']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Extras:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    ";
                                                    if(!count($extras)){

                                                        $body.= "No seleccionado<br>";
                                                    }
                                                    for($i=1;$i<count($extras);$i++){
                                                        $body.= $extras[$i]."<br>";
                                                    }

                                                    $body.="</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Pagado:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['data']['amount']." &euro;</span>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Método de pago:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['data']['method']."</span>
                                                </td>
                                            </tr>

                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style='".$light.$td_css.$l_font.$upper."' align='center'>
                                        Imágenes subidas por el usuario para la verificación de datos adjuntas
                                    </td>
                                </tr>";
                                if($user['email']=='noemail@rcdespanyol.com'){
                                    $body.="
                                <tr>
                                    <td style='".$light.$td_css.$l_font.$upper."' align='center'>
                                        Este socio no dispone de un correo válido.
                                    </td>
                                </tr>
                                    ";
                                }
                                $body.="
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        </table>";
        return $body;
    }
    private function getEmailIncBody($user,$order){
        $extras = [];
        if (isset($order['data']['femenino'])) $extras[]="Femenino";
        if (isset($order['data']['parking'])) $extras[]="Parking";

        switch($order['data']['method']){
            case 1 :
                $order['data']['method'] = 'Financiación';
                break;
            default:
                $order['data']['method'] = 'Tarjeta de crédito / débito';
                break;
        }
        //RSC
        $logo = "https://www.rcdespanyol.com/img/common/large/rcde_img_logotip.png";
        //CSS
        $td_css = "font-family: Arial, sans-serif; font-size: 14pt; line-height: 20px; padding: 7px 5px;";
        $dark = 'color:#5FA1BF;';
        $gray = 'color:#666;';
        $light = 'color:#343580;';
        $b_bottom_css = "border-bottom: 1px solid #ccc;";
        $b_top_css = "border-top: 1px solid #ccc;";
        $l_font = "font-size:10pt;";
        $m_font = "font-size:12pt;";
        $b_font = "font-size:18pt;";
        $upper = "text-transform:uppercase;";
        $cap = "text-transform:capitalize;";
        $bold = "font-weight:bold;";
        $m_line_h = 'line-height:14pt;';

        $first_l_td_css = $dark.$td_css.$b_bottom_css.$b_top_css.$l_font.$upper;
        $first_r_td_css = $light.$td_css.$b_bottom_css.$b_top_css.$m_font.$bold;
        $left_td_css = $dark.$td_css.$b_bottom_css.$l_font.$upper;
        $right_td_css = $light.$td_css.$b_bottom_css.$m_font.$bold;

        $footer = $light.$td_css.$l_font.$gray.$m_line_h;
        $body = "<table cellpadding='0' cellspacing='0' width='100%'>
            <tr>
            <td>
                <table cellpadding='0' cellspacing='0' width='600' style='color:#343580'>
                    <tr>
                        <td style='padding: 10px; background-color:#002543' align='center'>
                            <div style='float:left'>
                                <img src='".$logo."' style='height:50px' alt='logo'/>
                            </div>
                            <div style='float:right'>
                                <span style='color:#fff; font-family: Arial, sans-serif;  font-size: 10pt; font-weight: bold;margin-top:25px;display: block;'>CAMPAÑA DE ABONADOS 18/19</span>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style='padding: 10px;'>
                            <table cellpadding='0' cellspacing='0' width='100%'>
                                <tr>
                                    <td style='".$light.$td_css.$b_font.$bold."' align='center'>
                                        NO SE PUDO CONFIRMAR EN AVET<br><br>
                                    </td>
                                </tr>
                                <tr>
                                    <td style='".$td_css.$light.$m_font.$upper."' align='left'>
                                        Datos del pedido
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table cellpadding='0' cellspacing='0' width='100%'>

                                            <tr>
                                                <td style='".$first_l_td_css."' align='right'>
                                                   ID de pedido:
                                                </td>
                                                <td style='".$first_r_td_css."' align='left'>
                                                    <span>".$order['id']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                   Fecha:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['date']['modified']."</span>
                                                </td>
                                            </tr>
                                            <tr >
                                                <td style='".$left_td_css."' align='right'>
                                                    Tipo de usuario:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span style='".$cap."'>".$order['type']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    DNI:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$user['numdoc'].$user['numdocl']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Nombre completo:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$user['nombre']." ".$user['apellido1']." ".$user['apellido2']."</span>
                                                </td>
                                            </tr>
                                            <tr >
                                                <td style='".$left_td_css."' align='right'>
                                                    Tipo de abono:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['data']['tipo']."</span>
                                                </td>
                                            </tr>

                                            <tr>
                                               <td style='".$left_td_css."' align='right'>
                                                    Asiento seleccionado
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>
                                                        Sector: ".$order['data']['block']."<br>
                                                        Fila : ".$order['data']['row']."<br>
                                                        Asiento : ".$order['data']['seat']."
                                                    </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Envío del abono:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span style='".$cap."'>".$order['data']['envio']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Extras:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    ";
                                                    if(!count($extras)){

                                                        $body.= "No seleccionado<br>";
                                                    }
                                                    for($i=1;$i<count($extras);$i++){
                                                        $body.= $extras[$i]."<br>";
                                                    }

                                                    $body.="</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Pagado:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['data']['amount']." &euro;</span>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Método de pago:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['data']['method']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    PartnerOperation:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                ";
                                                foreach($order['data']['partneroperation'] as $po){

                                                $body.="<span>".$po."</span><br>";

                                                }
                                                $body.="
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>";
                                if($user['email']=='noemail@rcdespanyol.com'){
                                    $body.="
                                <tr>
                                    <td style='".$light.$td_css.$l_font.$upper."' align='center'>
                                        Este socio no dispone de un correo válido.
                                    </td>
                                </tr>
                                    ";
                                }
                                $body.="
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        </table>";
        return $body;
    }
    private function getEmailUserAltaBody($user,$order){

        $extras = [];
        if (isset($order['data']['femenino'])) $extras[]="Femenino";
        if (isset($order['data']['parking'])) $extras[]="Parking";

        switch($order['data']['method']){
            case 1 :
                $order['data']['method'] = 'Financiación';
                break;
            default:
                $order['data']['method'] = 'Tarjeta de crédito / débito';
                break;
        }

        //RSC
        $logo = "https://www.rcdespanyol.com/img/common/large/rcde_img_logotip.png";
        //CSS
        $td_css = "font-family: Arial, sans-serif; font-size: 14pt; line-height: 20px; padding: 7px 5px;";
        $dark = 'color:#5FA1BF;';
        $light = 'color:#343580;';
        $gray  = 'color: #666;';
        $b_bottom_css = "border-bottom: 1px solid #ccc;";
        $b_top_css = "border-top: 1px solid #ccc;";
        $l_font = "font-size:10pt;";
        $m_font = "font-size:12pt;";
        $b_font = "font-size:18pt;";
        $upper = "text-transform:uppercase;";
        $bold = "font-weight:bold;";
        $m_line_h = 'line-height:14pt;';
        
        $first_l_td_css = $dark.$td_css.$b_bottom_css.$b_top_css.$l_font.$upper;
        $first_r_td_css = $light.$td_css.$b_bottom_css.$b_top_css.$m_font.$bold;
        $left_td_css = $dark.$td_css.$b_bottom_css.$l_font.$upper;
        $right_td_css = $light.$td_css.$b_bottom_css.$m_font.$bold;
        $footer = $light.$td_css.$l_font.$gray.$m_line_h;

        $body = "<table cellpadding='0' cellspacing='0' width='100%'>
        <tr>
            <td>
                <table cellpadding='0' cellspacing='0' width='600' style='color:#343580'>
                    <tr>
                        <td style='padding: 10px; background-color:#002543' align='center'>
                            <div style='float:left'>
                                <img src='".$logo."' style='height:50px' alt='logo'/>
                            </div>
                            <div style='float:right'>
                                <span style='color:#fff; font-family: Arial, sans-serif;  font-size: 10pt; font-weight: bold;margin-top:25px;display: block;'>CAMPAÑA DE ABONADOS 18/19</span>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style='padding: 10px;'>
                            <table cellpadding='0' cellspacing='0' width='100%'>
                                <tr>
                                    <td style='".$light.$td_css.$b_font.$bold."' align='center'>
                                        CONFIRMACIÓN DE ABONO<br><br>
                                    </td>
                                </tr>
                                <tr>
                                    <td style='".$td_css.$light.$m_font.$upper."' align='left'>
                                        Datos de socio
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table cellpadding='0' cellspacing='0' width='100%'>
                                            <tr>
                                                <td style='".$first_l_td_css."' align='right'>
                                                   ID de pedido:
                                                </td>
                                                <td style='".$first_r_td_css."' align='left'>
                                                    <span>".$order['id']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                   Fecha:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['date']['modified']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    DNI:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$user['numdoc'].$user['numdocl']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Nombre completo:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$user['nombre']." ".$user['apellido1']." ".$user['apellido2']."</span>
                                                </td>
                                            </tr>
                                            <tr >
                                                <td style='".$left_td_css."' align='right'>
                                                    Tipo de abono:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['data']['tipo']."</span>
                                                </td>
                                            </tr>

                                            <tr>
                                               <td style='".$left_td_css."' align='right'>
                                                    Asiento seleccionado
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>
                                                        Sector: ".$order['data']['block']."<br>
                                                        Fila : ".$order['data']['row']."<br>
                                                        Asiento : ".$order['data']['seat']."
                                                    </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Envío del abono:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['data']['envio']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Extras:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    ";
                                                    if(!count($extras)){
                                                        $body.= "No seleccionado<br>";
                                                    }else{

                                                        for($i=1;$i<count($extras);$i++){
                                                            $body.= $extras[$i]."<br>";
                                                        }
                                                    }

                                                    $body.="</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Pagado:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['data']['amount']." &euro;</span>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Método de pago:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['data']['method']."</span>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style='".$bold.$td_css.$m_font.$upper."' align='left'>
                                        El club debe validar tus datos, nos pondremos en contacto contigo una vez verificado.
                                    </td>
                                </tr>
                                <tr>
                                    <td style='".$footer."' align='center'>
                                        <br>
                                        SI TIENES CUALQUIER CONSULTA NO DUDES EN ESCRIBIR A: abonaments@rcdespanyol.com
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        </table>";
        return $body;
    }
    private function getEmailUserRenBody($user,$order){


        switch($order['data']['method']){
            case 1 :
                $order['data']['method'] = 'Financiación';
                break;
            default:
                $order['data']['method'] = 'Tarjeta de crédito / débito';
                break;
        }

        //RSC
        $logo = "https://www.rcdespanyol.com/img/common/large/rcde_img_logotip.png";
        //CSS
        $td_css = "font-family: Arial, sans-serif; font-size: 14pt; line-height: 20px; padding: 7px 5px;";
        $dark = 'color:#5FA1BF;';
        $light = 'color:#343580;';
        $gray  = 'color: #666;';
        $b_bottom_css = "border-bottom: 1px solid #ccc;";
        $b_top_css = "border-top: 1px solid #ccc;";
        $l_font = "font-size:10pt;";
        $m_font = "font-size:12pt;";
        $b_font = "font-size:18pt;";
        $upper = "text-transform:uppercase;";
        $bold = "font-weight:bold;";
        $m_line_h = 'line-height:14pt;';
        
        $first_l_td_css = $dark.$td_css.$b_bottom_css.$b_top_css.$l_font.$upper;
        $first_r_td_css = $light.$td_css.$b_bottom_css.$b_top_css.$m_font.$bold;
        $left_td_css = $dark.$td_css.$b_bottom_css.$l_font.$upper;
        $right_td_css = $light.$td_css.$b_bottom_css.$m_font.$bold;
        $footer = $light.$td_css.$l_font.$gray.$m_line_h;

        $body = "<table cellpadding='0' cellspacing='0' width='100%'>
        <tr>
            <td>
                <table cellpadding='0' cellspacing='0' width='600' style='color:#343580'>
                    <tr>
                        <td style='padding: 10px; background-color:#002543' align='center'>
                            <div style='float:left'>
                                <img src='".$logo."' style='height:50px' alt='logo'/>
                            </div>
                            <div style='float:right'>
                                <span style='color:#fff; font-family: Arial, sans-serif;  font-size: 10pt; font-weight: bold;margin-top:25px;display: block;'>CAMPAÑA DE ABONADOS 18/19</span>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style='padding: 10px;'>
                            <table cellpadding='0' cellspacing='0' width='100%'>
                                <tr>
                                    <td style='".$light.$td_css.$b_font.$bold."' align='center'>
                                        CONFIRMACIÓN DE ABONO<br><br>
                                    </td>
                                </tr>
                                <tr>
                                    <td style='".$td_css.$light.$m_font.$upper."' align='left'>
                                        Datos de socio
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table cellpadding='0' cellspacing='0' width='100%'>
                                              <tr>
                                                <td style='".$first_l_td_css."' align='right'>
                                                   ID de pedido:
                                                </td>
                                                <td style='".$first_r_td_css."' align='left'>
                                                    <span>".$order['id']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                   Fecha:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['date']['modified']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    DNI:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$user['numdoc'].$user['numdocl']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Nombre completo:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$user['nombre']." ".$user['apellido1']." ".$user['apellido2']."</span>
                                                </td>
                                            </tr>
                                            <tr >
                                                <td style='".$left_td_css."' align='right'>
                                                    Tipo de abono:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['data']['tipo']."</span>
                                                </td>
                                            </tr>

                                            <tr>
                                               <td style='".$left_td_css."' align='right'>
                                                    Asiento seleccionado
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>
                                                        Sector: ".$order['data']['block']."<br>
                                                        Fila : ".$order['data']['row']."<br>
                                                        Asiento : ".$order['data']['seat']."
                                                    </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Envío del abono:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['data']['envio']."</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Pagado:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['data']['amount']." &euro;</span>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td style='".$left_td_css."' align='right'>
                                                    Método de pago:
                                                </td>
                                                <td style='".$right_td_css."' align='left'>
                                                    <span>".$order['data']['method']."</span>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style='".$light.$td_css.$l_font.$upper."' align='left'>
                                        Gracias por renovar un año más!
                                    </td>
                                </tr>
                                <tr>
                                    <td style='".$footer."' align='center'>
                                        <br>
                                        SI TIENES CUALQUIER CONSULTA NO DUDES EN ESCRIBIR A: abonaments@rcdespanyol.com
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        </table>";
        return $body;
    }


    private function getToken($length)
    {
        $token = "";
        /*$codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $codeAlphabet.= "abcdefghijklmnopqrstuvwxyz";*/
        $codeAlphabet = "0123456789";
        $max = strlen($codeAlphabet); // edited

        for ($i=0; $i < $length; $i++) {
            $token .= $codeAlphabet[$this->crypto_rand_secure(0, $max-1)];
        }

        return $token;
    }


    private function getHash($amount){
        return hash('sha256', $this->fin_establecimiento . $amount . $this->fin_key);
    }



    private function getUserFromOrder($order){
        $type = $order['type'];
        $dni = $order['dni'];
        $user_s3path = $this->getAWSPath($type,$dni);

        $user_file = $dni."-data.json";
        $keyname = $user_s3path.$user_file;
        return json_decode($this->S3->getObjectS3($keyname)['body'],true);
    }
    private function setHash($tarifas,$numdoc,$order_id,$amount){
        if(!empty($tarifas)){
            foreach($tarifas as &$t){
                $tar_id = $t['id'];
                /*$this->debug($t);
                $this->debug($tar_id);
                $this->debug($numdoc);
                $this->debug($order_id);
                $this->debug($amount);
                */
                $required = $order_id . $numdoc . $tar_id . $amount . $this->fin_establecimiento . $this->fin_key;
                //$this->debug($required);
                $hash = hash('sha256', $required);
 
                $t['hash'] = $hash;
            }
        }
        return $tarifas;
    }

    /**
     * Moves the uploaded file to the upload directory and assigns it a unique name
     * to avoid overwriting an existing uploaded file.
     *
     * @param string $directory directory to which the file is moved
     * @param UploadedFile $uploaded file uploaded file to move
     * @return string filename of moved file
     */
    private function moveUploadedFile($uploadedFile,$directory,$name)
    {
        $extension = pathinfo($uploadedFile->getClientFilename(), PATHINFO_EXTENSION);
        if(isset($name)){
            $filename = sprintf('%s.%0.8s', $name, $extension);
        }else{
            $basename = bin2hex(random_bytes(8)); // see http://php.net/manual/en/function.random-bytes.php
            $filename = sprintf('%s.%0.8s', $basename, $extension);
        }

        $uploadedFile->moveTo($directory . $filename);

        return $filename;
    }

    /**
     * Upload from file server var
     * @return array
     */
    private function uploadPostFiles($files,$path,$keyfile)
    {
        if(!empty($files)){
            $local_path  = DIRECTORY_SEPARATOR . 'tmp' . DIRECTORY_SEPARATOR;
            $i=0;
            $files_url = [];
            foreach($files as $key => $f){
                $err = true;
                if ($f->getError() === UPLOAD_ERR_OK) {
                    $name  = $keyfile."-".$key;
                    $t_file = $f->getClientMediaType();
                    $local_filename = $this->moveUploadedFile($f,$local_path,$name);
                    $local_file = $local_path . $local_filename;
                    $keyname  = $path.$local_filename;
                    $this->S3->putObject($keyname, $local_file,$t_file);
                    $files_url[]=$keyname;
                    $i++;
                    $err = false;
                }
            }
            if($err){
                $this->setCode(400);
                return [ "message" => "Bad upload" ];
            }
            return [ "files" => $files_url ];
        }
        $this->setCode(400);
        return [ "message" => "Files not found" ];
    }


    private function validate($data){
        $required_fields = ['numdoc','numdocl','nombre','apellido1','telefono','email','abono'];
        $required_fields_abono = ['tipo','envio','amount'];
        $data = array_change_key_case($data);
        foreach($required_fields as $f){
            if(!array_key_exists($f, $data)){
                return false;
            }
        }
        $abono = $data['abono'];
        $abono_data = array_change_key_case($abono);
        foreach($required_fields_abono as $af){
            if(!array_key_exists($af, $abono)){
                return false;
            }
        }

        return true;
    }



    private function updateOrder($order){
        //Update modified time
        $order['date']['modified']=date("Y-m-d h:i:s");
        $order['data']=array_change_key_case($order['data']);
        if($order['data']['femenino']=='undefined'){
            $order['data']['femenino'] = 0;
        }
        if($order['data']['parking']=='undefined'){
            $order['data']['parking'] = 0;
        }
        //Create DATA JSON
        $filename = $order['id'].'-response.json';
        $local_file = '/tmp/'.$filename;

        $this->createLocalFile($local_file,$order);
        $this->S3->putObject($order['url'], $local_file,'application/json');
        return true;
    }

    private function responseCaixaFin($data){
        $code = $data['StatusCode'];
        $post_order_id = $data['IdPedido'];
        $post_sign = $data['Sign'];
        $anum = $data['AuthNumber'];
        $ts = $data['TimeStamp'];

        $clave =$this->fin_key;

        $required = $code . $anum . $post_order_id . $clave . $ts;
        $sign = hash('sha256', $required);

        if ($post_sign == $sign) {

            //Get original order
            $keyname = $this->s3_client."/".date("Y")."/sql/orders/".$post_order_id.".json";
            $keyname = json_decode($this->S3->getObjectS3($keyname)['body'],true)['url'];

            //$keyname = $data['decodec']['Ds_MerchantData']['url'];
            $original_order = $this->S3->getObjectS3($keyname);
            $original_order = json_decode($original_order['body'],true);

            $original_order['status']=$code;
            $original_order['channel_response'][]=$data;
            $u = $this->updateOrder($original_order);

            if ($code == 'PREAUT') {
                $err = $this->AvetConfirm($original_order);
                if($err){
                    //$this->AvetCancel($original_order);
                    $this->sendemailInc($original_order,"avetconfirm");
                }else{
                    //Send Emails to club and user
                    $this->sendemail($original_order);
                    $this->createSeatLog($original_order);
                }
                return true;
            }
            if($code == 'NOAUT' || $code != 'CANCEL'){
                //CREAR INCIDENCIA
                $this->createInc($original_order);
                //ENVIAR MAIL INCIDENCIA
            }

        }
        return false;
    }

    
    private function responseRedsysTPV($data){
        $sign = $data["Ds_Signature"];
        $params = $data["Ds_MerchantParameters"];
        
        $redsysObj = $this->redsys;
        $signature = $redsysObj->createMerchantSignatureNotif($this->tpv_kc, $params);
        if ($data["Ds_Signature"] == $signature) {

            $data['decodec'] = json_decode($redsysObj->decodeMerchantParameters($params),true);
            $data['decodec']['Ds_MerchantData'] = json_decode(htmlspecialchars_decode($data['decodec']['Ds_MerchantData']), true);
            $status_raw = $data['decodec']['Ds_Response'];

            //Get original order
            $keyname = $this->s3_client."/".date("Y")."/sql/orders/".$data['decodec']['Ds_MerchantData']['id'].".json";
            $keyname = json_decode($this->S3->getObjectS3($keyname)['body'],true)['url'];

            //$keyname = $data['decodec']['Ds_MerchantData']['url'];
            $original_order = $this->S3->getObjectS3($keyname);
            $original_order = json_decode($original_order['body'],true);


            $status_code = intval($status_raw);
            if($status_code<=99) $status_code = 99;

            $status = ["99"=>"Transacción autorizada para pagos y preautizaciones",
                        "900"=>"Transacción autorizada para devoluciones y confirmaciones",
                        "400"=>"Transación autorizada para anulaciones",
                        "101"=>"Tarjeta caducada",
                        "102"=>"Tarjeta en excepción transitoria o bajo sospecha de fraude",
                        "106"=>"Intentos de PIN excedidos",
                        "125"=>"Tarjeta no efectiva",
                        "129"=>"Código de seguridad (CVV2/CVC2) incorrecto",
                        "180"=>"Tarjeta ajena al servicio",
                        "184"=>"Error en la autenticación del titular",
                        "190"=>"Denegación del emisor sin especificar motivo",
                        "191"=>"Fecha de caducidad errónea",
                        "202"=>"Tarjeta en excepción transitoria o bajo sospecha de fraude con retirada de tarjeta",
                        "904"=>"Comercio no registrado en FUC",
                        "909"=>"Error de sistema",
                        "913"=>"Pedido repetido",
                        "944"=>"Sesión Incorrecta",
                        "950"=>"Operación de devolución no permitida"];
            $original_order['status']=[$status_raw=>$status[$status_code]];
            //$original_order['channel_response']=array();
            $original_order['channel_response'][]=$data['decodec'];
            $this->updateOrder($original_order);

            if($status_code==99){
                //AVET Confirm
                $err = $this->AvetConfirm($original_order);
                if($err){
                    //$this->AvetCancel($original_order);
                    $this->sendemailInc($original_order,"avetconfirm");

                }else{
                    //Send Emails to club and user
                    $this->sendemail($original_order);
                    $this->createSeatLog($original_order);
                }
                return true;
            }else{
                $this->AvetCancel($original_order);
                return false;
            }

        }else{
            $this->createLog($data);
        }
    }

    private function createSeatLog($order){
        $order_id = $order['id'];
        $seat_id = $order['data']['block']."_".$order['data']['row']."_".$order['data']['seat'];
        $filename = $seat_id."-".$order_id.".json";

        $local_file = '/tmp/'.$filename;
        $this->createLocalFile($local_file,$order);

        $sql_path = $this->s3_client."/".date("Y")."/sql/seats/".$filename;
        $this->S3->putObject($sql_path, $local_file,'application/json');
        return true;
    }

    /**
     * Obtiene las tarifas de la calculadora de financiación de la Caixa
     * data = array("amount","numdoc","order_id");
     * data['numdoc'] // Contiene la letra
     * @param array $data datos obligatorios para hacer ste de los hashes de la tarifas
     * @return array Tarifas list
     */
    public function getFinanciacion($data,$order){
        $amount = $this->amountSet($order['data']['amount']);
        $valid_amount = $this->amountCheck($amount);

        if(!$valid_amount){
            $this->setCode(400);
            return [ "message" => "El total no es suficiente como para financiar." ];
        }
        if(!isset($data['tipodoc'])){
            $data['tipodoc'] = 1;
        }

        return [
                'formURL' => $this->fin_formURL,
                "nombre" => $data['nombre'],
                "apellido1" => $data['apellido1'],
                "tipodoc" => $data['tipodoc'],
                "numdoc" => $data['numdoc'].$data['numdocl'],
                "movil" => $data['movil'],
                "email" => $data['email'],
                "amount" => $amount,
                "order_id" => $order['id'],
                "establecimiento" => $this->fin_establecimiento
                ];
    }


    /**
     * Obtiene las tarifas de la calculadora de financiación de la Caixa
     * data = array("amount","numdoc","order_id");
     * data['numdoc'] // Contiene la letra
     * @param array $data datos obligatorios para configurar los hashes de la tarifas
     * @return array Tarifas list
     */
    public function getTarifas($data){
        $amount = $this->amountSet($data['amount']);
        /*$valid_amount = $this->amountCheck($amount);
        if(!$valid_amount){
            $this->setCode(400);
            return [ "message" => "Invalid amount" ];
        }*/
        $endpoint = $this->fin_tarsURL;
        $hash = $this->getHash($amount);

        $ch = curl_init();
        // Configure options
        $opt = [
            CURLOPT_URL => $this->fin_tarsURL,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true
        ];
        $opt[CURLOPT_POSTFIELDS]['establecimiento'] = $this->fin_establecimiento;
        $opt[CURLOPT_POSTFIELDS]['importe'] = $amount;
        $opt[CURLOPT_POSTFIELDS]['hash'] = $hash;

        curl_setopt_array($ch, $opt);

        // Execute petition
        $result = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $result = json_decode($result, true);
        $tarifas= array();
        if($code == 200){
            if(isset($result['tarifas']['tarifa'])){
                $tarifas = $result['tarifas']['tarifa'];
                $numdoc = $data['numdoc'];
                $order_id = $data['order_id'];
                $tarifas = $this->setHash($tarifas,$order_id,$numdoc,$amount);
            }
        }
        return $tarifas;
    }

    /**
     * Devuelve los inputs hidden que debe contener
     * el formulario que se envie a la pasarela de pago REDSYS
     * data = order type data
     * @param array $data datos obligatorios para configurar el post a redsys
     * @return array form input fields
     */
    public function getTPV($data){
        $redsysObj = $this->redsys;
        $order_id = $data['id'];
        $amount = $this->amountSet($data['data']['amount']);

        $valid_amount = $this->amountCheck($amount);
        if(!$valid_amount){
            $this->setCode(400);
            return [ "message" => "Invalid amount" ];
        }

        $merchant_data = ['url'=>$data['url'],'id'=>$order_id];
        $merchant_data = json_encode($merchant_data, true);

        // Se Rellenan los campos
        $redsysObj->setParameter("DS_MERCHANT_AMOUNT", $amount);
        $redsysObj->setParameter("DS_MERCHANT_ORDER", $order_id);
        $redsysObj->setParameter("DS_MERCHANT_MERCHANTCODE", $this->tpv_fuc);
        $redsysObj->setParameter("DS_MERCHANT_CURRENCY", $this->tpv_moneda);
        $redsysObj->setParameter("DS_MERCHANT_TRANSACTIONTYPE", $this->tpv_trans);
        $redsysObj->setParameter("DS_MERCHANT_TERMINAL", $this->tpv_terminal);
        $redsysObj->setParameter("DS_MERCHANT_MERCHANTURL", $this->tpv_responseURL);
        $redsysObj->setParameter("DS_MERCHANT_URLOK", $this->tpv_okURL);
        $redsysObj->setParameter("DS_MERCHANT_URLKO", $this->tpv_koURL);
        $redsysObj->setParameter("DS_MERCHANT_MERCHANTDATA", $merchant_data);


        // Se generan los parámetros de la petición
        $params = $redsysObj->createMerchantParameters();
        $signature = $redsysObj->createMerchantSignature($this->tpv_kc);
        return  [
                    'params' => $params,
                    'signature' => $signature,
                    'version' => $this->tpv_version,
                    'formURL' => $this->tpv_formURL
                    ];
    }


    public function neworder($data,$order_type){
        $valid_fields = $this->validate($data);
        $ret = array();
        if($valid_fields){
            $data = $this->cleanData($data);
            $order = $this->createOrder($data,$order_type);
            $fin = $this->getFinanciacion($data,$order);
            $tpv = $this->getTPV($order);
            // Clean order
            //unset($order['url']);

            //Response
            $ret = array("fin"=>$fin,"tpv"=>$tpv,"order"=>$order);
            return $ret;
        }else{
            $this->setCode(400);
            return [ "message" => "Not valid fields" ];

        }
    }


    public function neworderconfirm($data,$files,$type){
        $type = strtolower($type);
        $dni = $data['data']['numdoc'];
        $path = $this->getAWSPath($type,$dni,null);
        if($path){
            $data['data']['files']=[];
            //Upload DNI files if alta
            if($type=='alta'){
                $f = $this->uploadPostFiles($files['numdocfile'],$path,$dni);
                $data['data']['files']=$f['files'];
            }

            //Create DATA JSON
            $filename = $dni.'-data.json';
            $local_file = '/tmp/'.$filename;
            $this->createLocalFile($local_file,$data['data']);
            //Upload DATA JSON
            $path_file = $path.$filename;
            $this->S3->putObject($path_file, $local_file,'application/json');

            //Get Order
            $keyname = $path."orders/".$data['abono']['order_id'].".json";
            $updated_order = json_decode($this->S3->getObjectS3($keyname)['body'],true);
            //Update Order
            $data['abono']['IdMotivoEmision'] = $this->avet_renid;
            if($type=='alta'){
                $data['abono']['IdMotivoEmision'] = $this->avet_altaid;
            }

            $data['abono']['idPaymentMode'] = $this->avet_tarjid;
            if(intval($data['abono']['method'])){
                $data['abono']['idPaymentMode'] = $this->avet_finid;
            }
            
            $updated_order['data']=$data['abono'];
            $this->updateOrder($updated_order);

            return [ "message" => "Uploaded" ];
        }
        $this->setCode(400);
        return [ "message" => "Order type not found" ];
    }

    public function responseChannel($channel,$data){
        $channels = ['redsystpv','caixafin'];

        if(in_array($channel, $channels)){


            switch($channel){
                case 'redsystpv':
                    $this->responseRedsysTPV($data);
                    break;
                case 'caixafin':
                    $this->responseCaixaFin($data);
                    break;
                default:
                    break;
            }
        }

        return true;
    }



    public function sendemailinc($order,$inctype){
        /*$order = $this->S3->getObjectS3("rcde/2018/alta/46364876/orders/43322-4876.json");
        $order = json_decode($order['body'],true);*/

        if(empty($order) || !isset($inctype)) return null;

        $user = $this->getUserFromOrder($order);

        switch($inctype){
            case "avetconfirm":
                $body = $this->getEmailIncBody($user,$order);
                break;
            default:
                break;
        }
        $addr = array_values(array_filter(array_merge($this->mailer_to,$this->mailer_mmcsupport)));

        $subject = utf8_decode('ERROR DE CONFIRMACIÓN EN AVET - '.$user['numdoc']);
        $body = utf8_decode($body);
        $this->mailer->send($addr,$subject,$body);

        return true;
    }



    public function sendemail($order){
        //DEBUG
        /*$order = $this->S3->getObjectS3("rcde/2018/alta/53332941/orders/33370-2941.json");
        $order = json_decode($order['body'],true);*/

        if(empty($order)) return null;

        $user = $this->getUserFromOrder($order);

        $addr = [$this->mailer_to];
        $subject = utf8_decode('CONFIRMACIÓN EN AVET - '.$user['numdoc']);
        $body = $this->getEmailClubBody($user,$order);
        $files = $user['files'];
        $filepaths = [];
        if(!empty($files)){
            foreach($files as $keyname){
                $attm = $this->S3->getObjectS3($keyname);
                $ext = end(explode(".", $keyname));
                $filepath='/tmp/dni-'.$this->getToken(6)."-".date("Y-m-d_h:i:s").".".$ext;
                $this->createLocalImage($filepath,$attm['body']);
                if(file_exists($filepath)){
                    $filepaths[]=$filepath;
                }
            }
        }
        //Send Club Email
        $body = utf8_decode($body);
        $this->mailer->send($addr,$subject,$body,$filepaths);

        //User Email
        if($user['email'] && !empty($user['email'])){
            if($user['email']!='noemail@rcdespanyol.com'){
                $addr = [$user['email']];
                //$addr = ["altes@rcdespanyol.com"];
                $subject = utf8_decode("RCD Espanyol - Confirmación de abono");
                if($order['type']=='alta'){
                    $body = $this->getEmailUserAltaBody($user,$order);
                }else{
                    $body = $this->getEmailUserRenBody($user,$order);
                }
                $body = utf8_decode($body);
                //Send User Email
                $filepaths = array();
                $this->mailer->send($addr,$subject,$body);
            }
        }
    }

}
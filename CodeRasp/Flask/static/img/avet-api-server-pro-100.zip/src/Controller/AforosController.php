<?php

namespace App\Controller;

use App\Controller\Controller as Controller;
use App\Model\Repositories\AforosRepository as AforosRepository;

class AforosController extends Controller
{
    // MAGIC FUNCTIONS =========================================================
    /**
     * Class constructor
     * @param \SoapClient $soapclient SOAP client
     * @return void
     */
    public function __construct(\SoapClient $soapclient)
    {
        $this->Aforos =  new AforosRepository($soapclient);
    }

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Finds aforos
     * @return array Aforos list
     */
    public function find() : array
    {
        $opt = ["fxChannel" => $this->now()];
        $collection = $this->Aforos->find($opt);
        return $this->collectionToArray($collection);
    }
}

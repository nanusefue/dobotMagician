<?php

namespace App\Controller;

use App\Controller\Controller as Controller;
use App\Model\Repositories\MotivoEmisionRepository as MotivoEmisionRepository;

class MotivoEmisionController extends Controller
{
    // MAGIC FUNCTIONS =========================================================
    /**
     * Class constructor
     * @param \SoapClient $soapclient SOAP client
     * @return void
     */
    public function __construct(\SoapClient $soapclient)
    {
        $this->Motivos =  new MotivoEmisionRepository($soapclient);
    }

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Finds motivos
     * @return array MotivoEmision list
     */
    public function find() : array
    {
        $opt = ["fxChannel" => $this->now()];
        $collection = $this->Motivos->find($opt);
        return $this->collectionToArray($collection);
    }
}

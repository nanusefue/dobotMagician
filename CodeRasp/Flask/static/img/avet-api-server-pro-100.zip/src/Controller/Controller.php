<?php
/**
 * Clase madre de los controladores
 */
namespace App\Controller;

class Controller
{
    // PROTECTED VARS ==========================================================
    /**
     * HTTP response code
     *
     * @var $code int
     */
    protected $code = 200;

    // PUBLIC VARS =============================================================
    /**
     * Cliente SOAP
     *
     * @var $soapclient SoapClient
     */
    public $soapclient;

    // PROTECTED FUNCTIONS =====================================================
    /**
     * Transforms an object collection to array
     * @param array $collection Object collection
     * @return array
     */
    protected function collectionToArray(array $collection)
    {
        $array = [];
        for ($i = 0; $i < count($collection); $i++) {
            $array[] = $collection[$i]->toArray();
        }
        return $array;
    }

    /**
     * Get current datetime formatted for Avet API
     * @return string Formatted datetime
     */
    protected function now() : string
    {
        $datetime = new \DateTime();
        return $datetime->format("Y-m-d\TH:i:s");
    }

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Get code attribute
     *
     * @return int HTTP code
     */
    public function getCode() : int
    {
        return $this->code;
    }

    /**
     * Set code attribute value
     *
     * @param int $code HTTP code
     *
     * @return void
     */
    public function setCode(int $code)
    {
        $this->code = $code;
    }

    /*Beauty Debug*/
    public function debug($var){
        return highlight_string("<?php\n\$data =\n" . var_export($var, true) . ";\n?>");
    }
}

?>

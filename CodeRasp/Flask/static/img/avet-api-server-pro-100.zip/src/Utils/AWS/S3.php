<?php

namespace App\Utils\AWS;

use \Aws\S3\S3Client;
use \Aws\Exception\AwsException;
use \Aws\S3\Exception\S3Exception;
use \Aws\S3\S3MultiRegionClient;
//GuzzleHTTP
use \GuzzleHttp\Client as GuzzleHttpClient;
use \GuzzleHttp\Psr7\Request as Psr7Request;

class S3
{
    public static $S3;
    private static $AWS_KEY=null;
    private static $AWS_SECRET_KEY=null;
    private static $AWS_REGION=null;
    private static $config=null;
    private static $AWS_Keys=null;
    private static $AWS_Pem=null;
    private static $AWS_Timeout=null;

    private static $bucket = null;

    private static $guzzle = null;

    public function __construct($settings = null)
    {
        self::$bucket =  $settings['bucket'];
        /*self::$AWS_KEY = $settings['AWSAccessKeyId'];
        self::$AWS_SECRET_KEY = $settings['AWSSecretKey'];
        self::$AWS_REGION=$config;
        self::$AWS_Keys = $settings['AWSKeys'];
        self::$AWS_Pem = base64_decode($settings['AWSPem']);
        self::$AWS_Timeout =$settings['AWSS3timeout'];

        self::$S3 = S3Client::factory(
            array(
                'region'=>self::$AWS_REGION,
                'version'=>'latest',
                'debug' => false,
                'credentials'=>[
                    'key' => self::$AWS_KEY,
                    'secret' => self::$AWS_SECRET_KEY
                ]

            )
        );*/
        self::$S3 = S3Client::factory(
            array(
                'region'=>'eu-west-1',
                'version'=>'latest',
                'debug' => false
            )
        );

    }

    public function putObject($keyname, $local_file, $contenttype,$remove_original = true){
        try {
            $d = array(
                "Bucket" => self::$bucket,
                "Key" => $keyname,
                "SourceFile" => $local_file,
                'ContentType' => $contenttype,
            );
            $result = self::$S3->putObject($d);
            $metadata = $result->get('@metadata');
            $statusCode = $metadata['statusCode'];
            $res = array("statusCode"=>$statusCode,"data"=>$metadata);
            if(!$remove_original){
                if(file_exists($local_file)){
                    unlink($local_file);
                }
            }
            return $res;
        } catch (S3Exception $e) {
            header("Access-Control-Allow-Origin: *");
            return array("statusCode"=>404,"data"=>array());
        }
    }

    public function replaceObject($keyname_old, $keyname){
        try {
            $d = array(
                    // Bucket is required
                    'Bucket' => self::$bucket,
                    // CopySource is required
                    'CopySource' =>  self::$bucket.$keyname_old,
                    // Key is required
                    'Key' => $keyname,
                    'MetadataDirective' => 'REPLACE'
            );
            $result = self::$S3->copyObject($d);
            $metadata = $result->get('@metadata');
            $statusCode = $metadata['statusCode'];
            $res = array("statusCode"=>$statusCode,"data"=>$metadata);
            return $res;
        } catch (S3Exception $e) {
            header("Access-Control-Allow-Origin: *");
            return array("statusCode"=>404,"data"=>array());
        }
    }

    public function  getObjectS3($keyname)
    {
        try {
            $result = self::$S3->getObject(array(
                'Bucket' => self::$bucket,
                'Key'   => $keyname
            ));
            return array("body"=>$result['Body'],"type"=>$result['ContentType']);


        } catch (S3Exception $e) {
            header("Access-Control-Allow-Origin: *");
            return array("statusCode"=>404,"data"=>array());
        }
    }


    public function ifObjectExists($bucket, $keyname)
    {
        try {
            $response =  self::$S3->doesObjectExist($bucket, $keyname);
            return $response;
        } catch (Aws\S3\Exception\S3Exception $e) {
            $e->getResponse()->getStatusCode();
            return false;
        }
    }

    public function getObjectS3BySignature($keyname)
    {
        $expires = time() + self::$AWS_Timeout; //Time out in seconds
        $json = '{"Statement":[{"Resource":"'.$keyname.'","Condition":{"DateLessThan":{"AWS:EpochTime":'.$expires.'}}}]}';

        $key = openssl_get_privatekey(self::$AWS_Pem);

        if (!$key) {
            header("HTTP/1.1 404 Not Found");
            return;
        }

        //Sign the policy with the private key
        if (!openssl_sign($json, $signed_policy, $key, OPENSSL_ALGO_SHA1)) {
            header("HTTP/1.1 404 Not Found");
            echo '<p>Failed to sign policy: '.openssl_error_string().'</p>';
            return;
        }

        //Create url safe signed policy
        $base64_signed_policy = base64_encode($signed_policy);
        $signature = str_replace(array('+','=','/'), array('-','_','~'), $base64_signed_policy);
        //Construct the URL
        $url = $keyname.'?Expires='.$expires.'&Signature='.$signature.'&Key-Pair-Id='. self::$AWS_Keys;

        return $url;
    }


}

?>

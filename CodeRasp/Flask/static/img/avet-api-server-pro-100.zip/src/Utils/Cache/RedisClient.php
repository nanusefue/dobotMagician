<?php

namespace App\Utils\Cache;

use Predis\Client as Predis;

class RedisClient extends Predis
{
    // PUBLIC VARS =============================================================
    public $refreshTtl;
    public $tokenTtl;

    // MAGIC FUNCTIONS =========================================================
    public function __construct(array $config)
    {
        $this->tokenTtl = $config["token_ttl"];
        unset($config["token_ttl"]);
        $this->refreshTtl = $config["refresh_ttl"];
        unset($config["refresh_ttl"]);
        parent::__construct($config);
    }

    // PUBLIC FUNCTIONS ========================================================
    public function refresh(array $data) : string
    {
        $token = md5(uniqid(rand(), true));
        $jsonData = json_encode($data);
        $this->set($token, $jsonData);
        $this->expire($token, $this->tokenTtl);
        return $token;
    }

    public function token(array $data) : string
    {
        $token = md5(uniqid(rand(), true));
        $jsonData = json_encode($data);
        $this->set($token, $jsonData);
        $this->expire($token, $this->tokenTtl);
        return $token;
    }

    public function setDataPerm($key, $data, int $ttl = 0)
    {
        $this->set($key, json_encode($data));
        return $key;
    }

    public function getData(string $key)
    {
        if ($this->exists($key)){
            return $this->get($key);
        }
    }
}

?>

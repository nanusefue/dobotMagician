<?php
/**
 * Static class who formats a Throwable exception
 */
namespace App\Utils\Error;

class ErrorHandler
{
    // PUBLIC STATIC FUNCTIONS =================================================
    /**
     * Format response as error 500 with an array formatted message
     * @param \Throwable $exception Error exception
     */
    public static function setErrorMessage(\Throwable $error, \Slim\Http\Response $response)
    {
        $message = [
            "message" => $error->getMessage(),
            "file" => $error->getFile(),
            "line" => $error->getLine()
        ];
        return $response->withJson($message, 500);
    }
}

?>

<?php
/**
 * Stores any of the possible exceptions of the application and implements an unified
 * getMessage method.
 */
namespace App\Utils\Error;

class ErrorException
{
    // PUBLIC VARS =============================================================
    /**
     * Any type of exception
     * @var Exception $exception
     */
    public $exception;

    // PUBLIC FUNCTIONS ========================================================
    /**
     * Check if the error exception is initialized
     * @return bool True if param exception is initialized
     */
    public function isError() : bool
    {
        return isset($this->exception);
    }

    /**
     * Get message
     * @return array Error messages from exception
     */
    public function getMessage() : array
    {
        if (method_exists($this->exception,"getMessages")) {
            return $this->exception->getMessages();
        }

        return [
            0 => $this->exception->getMessage()
        ];
    }
}

?>

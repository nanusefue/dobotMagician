<?php

namespace App\Utils;
use \PHPMailer\PHPMailer\PHPMailer as PHPMailer;
use \PHPMailer\PHPMailer\Exception as PHPMailerException;
use Slim\Container as Container;

class Mailer
{
    /**
     * Flag que indica si se pueden enviar emails
     *
     * @var boolean $_ready
     */
    private $_ready = false;

    /**
     * Objeto PHPMailer
     *
     * @var PHPMailer $_phpmailer
     */
    private $_phpmailer;

    // CALLBACK METHODS ========================================================
    /**
     * Construct
     *
     * @param Container $slimApp Aplicacion slim
     *
     * @return void
     */
    public function __construct(Array $settings)
    {
            $this->_ready = true;

            // Init PHP Mailer
            $this->_mailer = new PHPMailer(true);
            $this->_mailer->SMTPDebug =$settings['smtpdebug'];
            $this->_mailer->isSMTP();
            $this->_mailer->Host = $settings['host'];
            $this->_mailer->Username = $settings['username'];
            $this->_mailer->Password = $settings['password'];
            $this->_mailer->SMTPSecure = $settings['smtpsecure'];
            $this->_mailer->SMTPAutoTLS = $settings['smtpautotls'];
            $this->_mailer->Port = $settings['port'];
            $this->_mailer->SetFrom($settings['from'],utf8_decode($settings['fromname']));
            /*if(isset($settings['smtpoptions'])){
                $this->_mailer->SMTPOptions = $settings['smtpoptions'];
            }*/
            $this->_mailer->SMTPAuth = $settings['smtpauth'];
            $this->_mailer->isHTML(true);
    }

    // PUBLIC FUNCTION =========================================================
    /**
     * Enviar correo
     *
     * @param array $addr Array con cuentas de correo
     * @param string $subject Subject del correo
     * @param string $body Contenido del correo en HTML
     * @param string $attachment Path al fichero para ser adjuntado
     *
     * @return void
     */
    public function send(array $addr, string $subject, string $body, array $attm = array())
    {
        // Send email si la configuracion lo ha permitido
        if ($this->_ready) {

            //Recipients
            $this->_mailer->ClearAllRecipients();
            //$this->_mailer->setFrom($this->_mailer->Username, "MMC");
            foreach ($addr as $user) {
                $this->_mailer->addAddress($user);
            }

            //Content
            $this->_mailer->Subject = $subject;
            $this->_mailer->Body = $body;

            // Attachments
            if (empty($attm)) {
                $this->_mailer->clearAttachments();
            }else{
                foreach($attm as $a){
                    $this->_mailer->addAttachment($a);
                }
            }

            // Enviar
            $this->_mailer->send();
        }
    }
}

<?php

namespace App\Utils;

use \SoapClient as SoapClient;

class SoapFactory
{
    // PUBLIC STATiC FUNCTIONS =================================================
    public static function getSubscriberOperations($config)
    {
        $uri = $config["protocol"] . $config["uri"] . ":" . $config["port"] .
        $config["subscriberPrefix"] . $config["services"]["SubscriberOperations"];
        // Crear cliente SOAP
        $opt = [
            "trace" => 1,
            "exceptions" => false
        ];

        return new SoapClient($uri, $opt);
    }

    public static function getVenueConfiguration($config)
    {
        $uri = $config["protocol"] . $config["uri"] . ":" . $config["port"] .
        $config["subscriberPrefix"] . $config["services"]["VenueConfiguration"];
        // Crear cliente SOAP
        $opt = [
            "trace" => 1,
            "exceptions" => false
        ];

        return new SoapClient($uri, $opt);
    }
}

?>

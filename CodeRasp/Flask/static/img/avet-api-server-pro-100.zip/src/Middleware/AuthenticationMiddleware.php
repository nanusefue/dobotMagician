<?php
/**
 * Middleware who controls authentication previously to the route execution
 */
use App\Utils\Cache\RedisClient as RedisClient;

class AuthenticationMiddleware
{
    // PROTECTED VARS ==========================================================
    /**
     * Redis connection
     * @var RedisClient Redis PHP client
     */
    protected $redis;

    // MAGIC FUNCTIONS =========================================================
    /**
     * Construct class
     * @param RedisClient $redisClient Redis cache client
     */
    public function __construct(RedisClient $redisClient)
    {
        $this->redis = $redisClient;
    }

    /**
     * Example middleware invokable class
     *
     * @param  \Psr\Http\Message\ServerRequestInterface $request  PSR7 request
     * @param  \Psr\Http\Message\ResponseInterface      $response PSR7 response
     * @param  callable                                 $next     Next middleware
     *
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function __invoke($request, $response, $next)
    {
        $token = $this->getBearerToken($request);
        $partnerOp = $this->redis->get($token);
        if ($partnerOp) {
            // Save partnerOperation and ttl in request attributes
            $ttl = $this->redis->ttl($token);
            $request = $request->withAttribute("partnerOp", $partnerOp)
                                ->withAttribute("ttl", $ttl);
            // Execute and return callable
            return $next($request, $response);
        }

        return $response->withStatus(403);
    }

    // PRIVATE FUNCTIONS =======================================================
    /**
     * Get bearer token
     * @param
     */
    private function getBearerToken($request) : string
    {
        $token = "";
        $header = $request->getHeader("HTTP_AUTHORIZATION");
        if (!empty($header)) {
            if (preg_match('/Bearer\s(\S+)/', $header[0], $matches)) {
                $token = $matches[1];
            }
        }
        return $token;
    }
}

?>

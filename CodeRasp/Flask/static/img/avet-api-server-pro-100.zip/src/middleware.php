<?php
/**
 * Load middleware classes
 */
require_once "Middleware/AuthenticationMiddleware.php";
require_once "Middleware/HeadersMiddleware.php";

/** Automatically generated file. DO NOT MODIFY */
package Dobot.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
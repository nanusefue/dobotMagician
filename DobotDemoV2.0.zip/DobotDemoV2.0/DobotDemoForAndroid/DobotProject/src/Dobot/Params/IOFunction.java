package Dobot.Params;

public class IOFunction {

	
	
	/**
	 * 不配置功能
	 */
	public  static  int  IOFunctionDummy=0; 
	
	
	/**
	 * PWM 输出
	 */
	public  static  int	IOFunctionPWM=1; 
	
	
    /**
     * IO 输出
     */
	public  static  int	 IOFunctionDO=2; 
	
	
	/**
     *IO 输入
     */
	public  static  int	 IOFunctionDI=3;
	
	
	/**
     *AD 输入
     */
	public  static  int	 IOFunctionADC=4 ;


}

package Dobot.Params;

public class CmdState {
	
	 public static final int Error = 0;
	 
	 public static final int Normal= 1;
	 
	 public static final int TimeOut = 2;

}

package com.example.Dobot;

import android.bluetooth.BluetoothGattCharacteristic;

public interface DataReceiveListener {
	
   //  public void OnReceive(BluetoothGattCharacteristic characteristic);	
       public void OnReceive();	
     
}
  